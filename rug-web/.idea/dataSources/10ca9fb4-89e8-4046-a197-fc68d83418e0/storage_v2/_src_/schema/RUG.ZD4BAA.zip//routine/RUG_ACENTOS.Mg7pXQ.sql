create FUNCTION         RUG_ACENTOS (peCadena   IN  VARCHAR2)
   RETURN VARCHAR2 AS


  vlCadResult      varchar2(4000);
  vlCadOrig          varchar2(4000);

 BEGIN
    vlCadResult := UPPER(TRIM(peCadena));
  --Asignacion de variables
   IF peCadena IS NOT NULL THEN
        vlCadOrig := UPPER(TRIM(peCadena));
        --VALIDA CARACTERES ESPECIALES
    --    vlCadOrig := vlCadFin;
        vlCadOrig:= REPLACE(vlCadOrig, 'A', 'A');
        vlCadOrig:= REPLACE(vlCadOrig, 'E', 'E');
        vlCadOrig:= REPLACE(vlCadOrig, 'I', 'I');
        vlCadOrig:= REPLACE(vlCadOrig, 'O', 'O');
        vlCadOrig:= REPLACE(vlCadOrig, 'U', 'U');
        vlCadOrig:= REPLACE(vlCadOrig, 'A', 'A');
        vlCadOrig:= REPLACE(vlCadOrig, 'E', 'E');
        vlCadOrig:= REPLACE(vlCadOrig, 'I', 'I');
        vlCadOrig:= REPLACE(vlCadOrig, 'O', 'O');
        vlCadOrig:= REPLACE(vlCadOrig, 'U', 'U');
        vlCadOrig:= REPLACE(vlCadOrig, 'A', 'A');
        vlCadOrig:= REPLACE(vlCadOrig, 'E', 'E');
        vlCadOrig:= REPLACE(vlCadOrig, 'I', 'I');
        vlCadOrig:= REPLACE(vlCadOrig, 'O', 'O');
        vlCadOrig:= REPLACE(vlCadOrig, 'U', 'U');

        vlCadOrig:= REPLACE(vlCadOrig, 'a', 'A');
        vlCadOrig:= REPLACE(vlCadOrig, 'e', 'E');
        vlCadOrig:= REPLACE(vlCadOrig, 'i', 'I');
        vlCadOrig:= REPLACE(vlCadOrig, 'o', 'O');
        vlCadOrig:= REPLACE(vlCadOrig, 'u', 'U');
        vlCadOrig:= REPLACE(vlCadOrig, 'a', 'A');
        vlCadOrig:= REPLACE(vlCadOrig, 'e', 'E');
        vlCadOrig:= REPLACE(vlCadOrig, 'i', 'I');
        vlCadOrig:= REPLACE(vlCadOrig, 'o', 'O');
        vlCadOrig:= REPLACE(vlCadOrig, 'u', 'U');
        vlCadOrig:= REPLACE(vlCadOrig, 'a', 'A');
        vlCadOrig:= REPLACE(vlCadOrig, 'e', 'E');
        vlCadOrig:= REPLACE(vlCadOrig, 'i', 'I');
        vlCadOrig:= REPLACE(vlCadOrig, 'o', 'O');
        vlCadOrig:= REPLACE(vlCadOrig, 'u', 'U');
        --vlCadOrig:= REPLACE(vlCadOrig, ''', '');
        vlCadOrig:= REPLACE(vlCadOrig, '`', '');

        vlCadResult := vlCadOrig;
    END IF;

    RETURN vlCadResult;

 EXCEPTION
   WHEN OTHERS THEN
    INSTITUCIONAL.pkgse_comun.sptLog('FUNVALCADENANOMBRES',SUBSTR('Error '||SQLCODE||':'||SQLERRM,1, 1000),'');
    RAISE_APPLICATION_ERROR( -20734,SQLERRM);
    RETURN vlCadResult;
END RUG_ACENTOS;
/

