create PROCEDURE         SP_LOG_JOBS_RUG 
( 
    peIdJob IN RUG_JOBS.ID_JOB%TYPE,
    peIdParam IN NUMBER,
    peValue IN VARCHAR2
)
IS
psTxResult VARCHAR2(200);
PRAGMA AUTONOMOUS_TRANSACTION;

BEGIN

    CASE
           WHEN peIdParam = 1  THEN      
            BEGIN

                IF peValue = 1 THEN

                    UPDATE RUG_JOBS SET IS_RUNNING = 'TRUE'
                    WHERE ID_JOB = peIdJob;

                ELSIF peValue = 0 THEN 

                    UPDATE RUG_JOBS SET IS_RUNNING = 'FALSE'
                    WHERE ID_JOB = peIdJob;

                END IF;
            END;
           WHEN peIdParam = 2  THEN 
            BEGIN

                UPDATE RUG_JOBS SET LAST_EXECUTION_DATE = SYSDATE
                WHERE ID_JOB = peIdJob;

            END;
            WHEN peIdParam = 3  THEN 
            BEGIN

                UPDATE RUG_JOBS SET FAILURE_COUNT = FAILURE_COUNT + 1
                WHERE ID_JOB = peIdJob;

            END;
    END CASE;        
COMMIT;                    

  EXCEPTION 
   WHEN OTHERS THEN 
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_LOG_JOBS_RUG', 'psResult', '999', 'IN');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_LOG_JOBS_RUG', 'psTxResult', psTxResult, 'IN');
      ROLLBACK;  
END SP_LOG_JOBS_RUG;
/

