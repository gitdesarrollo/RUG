create view V_USUARIO_ACREEDOR_REP as
SELECT   RUA.ID_USUARIO AS USUARIO_LOGIN,
            RUA.ID_ACREEDOR AS ID_PERSONA,
            RPP.PER_JURIDICA,
            CASE
               WHEN RPP.PER_JURIDICA IN ('PM')
               THEN
                  (SELECT   RAZON_SOCIAL
                     FROM   RUG_PERSONAS_MORALES
                    WHERE   ID_PERSONA = RUA.ID_ACREEDOR)
            END
               AS RAZON_SOCIAL,
            DECODE (
               RPP.PER_JURIDICA,
               'PF',
               (SELECT      F.NOMBRE_PERSONA
                         || ' '
                         || F.AP_PATERNO
                         || ' '
                         || F.AP_MATERNO
                  FROM   RUG_PERSONAS_FISICAS F
                 WHERE   F.ID_PERSONA = RPP.ID_PERSONA),
               'PM',
               (SELECT   M.RAZON_SOCIAL
                  FROM   RUG_PERSONAS_MORALES M
                 WHERE   M.ID_PERSONA = RPP.ID_PERSONA)
            )
               AS NOMBRE_ACREEDOR,
            CASE
               WHEN RPP.PER_JURIDICA IN ('PF')
               THEN
                  (SELECT   NOMBRE_PERSONA
                     FROM   RUG_PERSONAS_FISICAS
                    WHERE   ID_PERSONA = RUA.ID_ACREEDOR)
            END
               AS NOMBRE,
            CASE
               WHEN RPP.PER_JURIDICA IN ('PF')
               THEN
                  (SELECT   AP_PATERNO
                     FROM   RUG_PERSONAS_FISICAS
                    WHERE   ID_PERSONA = RUA.ID_ACREEDOR)
            END
               AS AP_PATERNO,
            CASE
               WHEN RPP.PER_JURIDICA IN ('PF')
               THEN
                  (SELECT   AP_MATERNO
                     FROM   RUG_PERSONAS_FISICAS
                    WHERE   ID_PERSONA = RUA.ID_ACREEDOR)
            END
               AS AP_MATERNO,
            RPP.FOLIO_MERCANTIL,
            RPP.RFC,
            DECODE (RPP.PER_JURIDICA,
                    'PF', (SELECT   CURP
                             FROM   RUG_PERSONAS_FISICAS
                            WHERE   ID_PERSONA = RUA.ID_ACREEDOR),
                    NULL)
               AS CURP,
            RPP.ID_DOMICILIO,
            VD.CALLE,
            '' CALLE_COLINDANTE_1,
            '' CALLE_COLINDANTE_2,
            VD.LOCALIDAD,
            VD.NUM_EXTERIOR,
            VD.NUM_INTERIOR,
            VD.ID_COLONIA,
            VD.NOM_COLONIA DESC_COLONIA,
            VD.ID_LOCALIDAD,
            VD.LOCALIDAD DESC_LOCALIDAD,
            VD.CVE_ESTADO,
            VD.CVE_PAIS,
            VD.CVE_DELEG_MUNICIP CVE_MUNICIP_DELEG,
            VD.CODIGO_POSTAL,
            RCN.ID_NACIONALIDAD,
            RCN.DESC_NACIONALIDAD,
            RT.CLAVE_PAIS,
            RT.TELEFONO,
            RT.EXTENSION,
            RPP.E_MAIL,
            VD.UBICA_DOMICILIO_1,
            VD.UBICA_DOMICILIO_2,
            VD.POBLACION,
            VD.ZONA_POSTAL
     FROM               REL_USU_ACREEDOR RUA
                     INNER JOIN
                        RUG_PERSONAS RPP
                     ON RPP.ID_PERSONA = RUA.ID_ACREEDOR
                  LEFT JOIN
                     RUG_CAT_NACIONALIDADES RCN
                  ON RCN.ID_NACIONALIDAD = RPP.ID_NACIONALIDAD
               LEFT JOIN
                  RUG_TELEFONOS RT
               ON RT.ID_PERSONA = RPP.ID_PERSONA
            LEFT JOIN
               V_DOMICILIOS VD
            ON RPP.ID_DOMICILIO = VD.ID_DOMICILIO
    WHERE   RUA.STATUS_REG = 'AC' AND RUA.B_FIRMADO = 'Y'
/

