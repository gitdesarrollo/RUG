create view V_DETALLE_BOLETA as
SELECT TRI.ID_TRAMITE,
          RGM.ID_GARANTIA,
          RCTT.DESCRIPCION AS TIPO_TRAMITE,
          RTG.DESC_TIPO_GARANTIA AS TIPO_GARANTIA,
          SUBSTR (TO_CHAR (HTP.FECHA_INSCR, 'DD/MM/YYYY - HH24:MI:SS'),
                  0,
                  10)
             AS FECHA_ACTO_CONVENIO,
          '$ ' || HTP.MONTO_MAXIMO_GARANTIZADO || ' ' || RCM.DESC_MONEDA
             AS MONTO_MAXIMO_GARANTIZADO,
          HTP.OTROS_TERMINOS_GARANTIA,
          Tipo_Bien_Garantia_H (RGM.ID_GARANTIA, TRI.ID_TRAMITE, 0)
             AS TIPOS_BIENES_GARANTIA,
          HTP.DESC_GARANTIA,
          CAST (HTP.VIGENCIA AS VARCHAR2 (5)) || ' meses' AS VIGENCIA,
          TRI.ID_PERSONA AS ID_USUARIO,
          (SELECT NOMBRE_PERSONA || ' ' || AP_PATERNO || ' ' || AP_MATERNO
             FROM RUG_PERSONAS_FISICAS
            WHERE ID_PERSONA = TRI.ID_PERSONA)
             AS NOMBRE_USUARIO,
          RSU.CVE_USUARIO,
          RSPU.CVE_PERFIL,
          TO_CHAR (HTT.FECHA_STATUS, 'DD/MM/YYYY - HH24:MI:SS')
             AS FECHA_CREACION
     FROM RUG_CAT_MONEDAS RCM,
                                     TRAMITES TRI
                                  INNER JOIN
                                     RUG_CAT_TIPO_TRAMITE RCTT
                                  ON TRI.ID_TIPO_TRAMITE =
                                        RCTT.ID_TIPO_TRAMITE
                               INNER JOIN
                                  RUG_REL_TRAM_GARAN RGM
                               ON TRI.ID_TRAMITE = RGM.ID_TRAMITE
                            INNER JOIN
                               RUG_GARANTIAS RGT
                            ON RGM.ID_GARANTIA = RGT.ID_GARANTIA
                         INNER JOIN
                            RUG_CAT_TIPO_GARANTIA RTG
                         ON RGT.ID_TIPO_GARANTIA = RTG.ID_TIPO_GARANTIA
                      INNER JOIN
                         RUG_BITAC_TRAMITES RBB
                      ON TRI.ID_TRAMITE_TEMP = RBB.ID_TRAMITE_TEMP
                   INNER JOIN
                      RUG_SECU_USUARIOS RSU
                   ON RSU.ID_PERSONA = TRI.ID_PERSONA
                INNER JOIN
                   RUG_SECU_PERFILES_USUARIO RSPU
                ON RSPU.CVE_USUARIO = RSU.CVE_USUARIO
             INNER JOIN
                (SELECT RGH.ID_GARANTIA,
                        RGH.ID_ULTIMO_TRAMITE,
                        RBB.FECHA_STATUS,
                        RGH.ID_MONEDA
                   FROM RUG_GARANTIAS_H RGH,
                        TRAMITES TR,
                        RUG_BITAC_TRAMITES RBB
                  WHERE     RGH.ID_ULTIMO_TRAMITE = TR.ID_TRAMITE
                        AND RBB.ID_TRAMITE_TEMP = TR.ID_TRAMITE_TEMP
                        AND TR.ID_TIPO_TRAMITE = 1
                        AND RBB.ID_STATUS = 3) HTT
             ON RGM.ID_GARANTIA = HTT.ID_GARANTIA
          INNER JOIN
             (SELECT RGH.ID_GARANTIA,
                     RGH.ID_ULTIMO_TRAMITE,
                     RGH.ID_TIPO_GARANTIA,
                     RGH.FECHA_INSCR,
                     RGH.MONTO_MAXIMO_GARANTIZADO,
                     RGH.DESC_GARANTIA,
                     RGH.OTROS_TERMINOS_GARANTIA,
                     RGH.VIGENCIA,
                     RGH.ID_MONEDA
                FROM RUG_GARANTIAS_H RGH, TRAMITES TR
               WHERE RGH.ID_ULTIMO_TRAMITE = TR.ID_TRAMITE) HTP
          ON RGM.ID_GARANTIA = HTP.ID_GARANTIA
    WHERE     RBB.ID_STATUS = 3
          AND TRI.ID_TRAMITE = HTP.ID_ULTIMO_TRAMITE
          AND RCM.ID_MONEDA = HTP.ID_MONEDA
/

