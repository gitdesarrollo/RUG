create FUNCTION           FN_PERSONA_TRAMITE (
                                                   peIdTramite NUMBER,
                                                   peIdParte  NUMBER    
                                                   )
RETURN NUMBER 

IS
 
 vlIdPersonaRet NUMBER;  

BEGIN

    IF peIdParte IN (4,5) THEN
             BEGIN
               SELECT ID_PERSONA
               INTO vlIdPersonaRet
               FROM RUG.RUG_REL_TRAM_INC_PARTES
               WHERE ID_TRAMITE_TEMP = peIdTramite
               AND ID_PARTE = peIdParte;
             EXCEPTION
             WHEN NO_DATA_FOUND THEN
               vlIdPersonaRet := 0;
             END;
    ELSIF peIdParte = 6 THEN
              BEGIN
               SELECT ID_PERSONA
               INTO vlIdPersonaRet
               FROM RUG.TRAMITES_RUG_INCOMP
               WHERE ID_TRAMITE_TEMP = peIdTramite;
             EXCEPTION
             WHEN NO_DATA_FOUND THEN
               vlIdPersonaRet := 0;
             END;     
    END IF;


    RETURN vlIdPersonaRet;


EXCEPTION
   WHEN OTHERS THEN
      RETURN NULL;
END;
/

