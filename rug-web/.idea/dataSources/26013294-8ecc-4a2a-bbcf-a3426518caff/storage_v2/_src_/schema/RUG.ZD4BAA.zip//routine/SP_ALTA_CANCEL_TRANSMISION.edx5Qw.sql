create PROCEDURE           SP_ALTA_CANCEL_TRANSMISION 
                            (
                                peIdTramiteTemp      IN  RUG_REL_TRAM_INC_GARAN.ID_TRAMITE_TEMP%TYPE,--  IDENTIFICADOR DEL TRAMITE ASOCIADO A LA GARANTIA
                                peIdGarantia         IN  NUMBER, --Id de la Garantia a Modificar 
                                peIdUsuario          IN  NUMBER,                              
                                psResult            OUT  INTEGER,   
                                psTxResult          OUT  VARCHAR2                             
                            )
IS

vlBandera                   NUMBER;
Ex_ErrParametro             EXCEPTION;
Ex_TramExistente            EXCEPTION;
vlTramiteExiste             NUMBER;


BEGIN

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCEL_TRANSMISION INICIO', 'peIdTramiteTemp', peIdTramiteTemp, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCEL_TRANSMISION', 'peIdGarantia', peIdGarantia, 'IN');

       BEGIN
             SELECT ID_TRAMITE_TEMP
             INTO vlTramiteExiste
             FROM TRAMITES_RUG_INCOMP
             WHERE ID_TRAMITE_TEMP = peIdTramiteTemp;
              EXCEPTION
               WHEN NO_DATA_FOUND THEN
                psResult := 16;
                SELECT DESC_CODIGO
                INTO psTxResult
                FROM RUG_CAT_MENSAJES_ERRORES
                WHERE ID_CODIGO = psResult;
             RAISE Ex_ErrParametro;
       END;


        SELECT FNVALIDAMODIFICAOTORGANTE(peIdGarantia, peIdTramiteTemp)
          INTO vlBandera
          FROM DUAL;

        IF(vlBandera = 0) THEN
             psResult   := 0;        
            psTxResult :='No se movio el otorgante';
        END IF;                  

        IF(vlBandera = 1) THEN
            psResult   :=1;        
            psTxResult :='Cambio el otorgante';

        END IF;



REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCEL_TRANSMISION', 'peIdTramiteTemp', peIdTramiteTemp, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCEL_TRANSMISION', 'peIdGarantia', peIdGarantia, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCEL_TRANSMISION', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCEL_TRANSMISION FIN', 'psTxResult', psTxResult, 'OUT');    


EXCEPTION
  WHEN Ex_ErrParametro  THEN
    ROLLBACK;  
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCEL_TRANSMISION', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCEL_TRANSMISION', 'psTxResult', psTxResult, 'OUT');    


   WHEN OTHERS THEN
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCEL_TRANSMISION', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCEL_TRANSMISION', 'psTxResult', psTxResult, 'OUT');    
    ROLLBACK;
END SP_ALTA_CANCEL_TRANSMISION;
/

