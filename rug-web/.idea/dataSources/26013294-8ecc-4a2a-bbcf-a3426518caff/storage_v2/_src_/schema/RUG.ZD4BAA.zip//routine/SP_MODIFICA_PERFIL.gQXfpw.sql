create PROCEDURE         SP_MODIFICA_PERFIL 
(
    peIdPersona     IN  NUMBER,
    peIdGrupo       IN  NUMBER,
    psResult       OUT  INTEGER,   
    psTxResult     OUT  VARCHAR2
) 

IS

vlIdGrupo           NUMBER;
vlCveUsuario        varchar2(500);
vlIdPerfil          NUMBER;

--Exceptions
Ex_ErrParametro    EXCEPTION;


BEGIN


REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PERFIL', 'peIdPersona', peIdPersona, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PERFIL', 'peIdGrupo', peIdGrupo, 'IN');

    IF(peIdGrupo NOT IN (1,2)) THEN
        BEGIN
            psResult:= -1;
            psTxResult := 'Error al asignar grupo, solo se puede modificar al grupo Acreedor y/o Ciudadano';
            RAISE Ex_ErrParametro;
        END;
    END IF;


    BEGIN


          SELECT ID_GRUPO, ID_PERFIL
          INTO vlIdGrupo, vlIdPerfil
          FROM V_USUARIO_SESION_RUG
         WHERE ID_PERSONA =  peIdPersona;



        EXCEPTION 
          WHEN OTHERS  THEN
            psResult:= -1;
            psTxResult := 'El usuario no existe en el sistema o no tiene asignado un grupo Acreedor o Ciudadano';
            RAISE Ex_ErrParametro;          

    END; 


 BEGIN
        SELECT CVE_USUARIO
          INTO vlCveUsuario
          FROM RUG_SECU_USUARIOS
         WHERE ID_PERSONA = peIdPersona;
         -- AND ID_GRUPO IN (1,2);

        EXCEPTION 
          WHEN OTHERS  THEN
            psResult:= -1;
            psTxResult := 'El usuario no existe en el sistema o no tiene asignado un grupo Acreedor o Ciudadano';
            RAISE Ex_ErrParametro;          

    END; 



IF  vlIdPerfil != 4 AND vlIdGrupo != 15 THEN 
    IF peIdGrupo = 1 THEN
        BEGIN    

            UPDATE RUG_SECU_USUARIOS
            SET CVE_ACREEDOR = vlCveUsuario, ID_GRUPO = 1
             WHERE CVE_USUARIO = vlCveUsuario;


            UPDATE RUG_SECU_PERFILES_USUARIO
            SET CVE_PERFIL = 'ACREEDOR'
             WHERE CVE_USUARIO = vlCveUsuario;
        END;
  END IF;


    --CAND (vlCveUsuario <> 4 OR vlCveUsuario <> 5 )) THEN
    IF peIdGrupo = 2 THEN
        BEGIN    
            UPDATE RUG_SECU_USUARIOS
            SET CVE_ACREEDOR = NULL, ID_GRUPO = 2
             WHERE CVE_USUARIO = vlCveUsuario;


            UPDATE RUG_SECU_PERFILES_USUARIO
            SET CVE_PERFIL = 'CIUDADANO'
            WHERE CVE_USUARIO = vlCveUsuario;
        END;
    END IF;

END IF;      
    psResult := 0;
    psTxResult := 'Actualizacion Exitosa';


REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PERFIL', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PERFIL', 'psTxResult', psTxResult, 'OUT');    


    COMMIT;

EXCEPTION 
  WHEN Ex_ErrParametro  THEN
      ROLLBACK;

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PERFIL', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PERFIL', 'psTxResult', psTxResult, 'OUT');    

   WHEN OTHERS THEN
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      ROLLBACK;
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PERFIL', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PERFIL', 'psTxResult', psTxResult, 'OUT');    

END SP_MODIFICA_PERFIL;
/

