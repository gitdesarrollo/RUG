create FUNCTION         SPLIT_TEM 
(
    p_list CLOB,--varchar2,
    p_del varchar2 := ','
) return rug.t_Palabras pipelined
is
    l_idx    pls_integer;
    l_list    CLOB := p_list; --varchar2(32767) := p_list;
    l_value   CLOB; -- varchar2(32767);
begin
    l_list := p_list;
    loop
        --l_idx := instr(l_list,p_del);

        l_list := REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(l_list, ',', ' '), '.', ' '), CHR(10), ' '), CHR(13), ' '),CHR(09), ' ');

        --Dbms_output.put_line(p_del); 
        --Dbms_output.put_line('FUNCION SPLIT'); 
        l_idx := instr(l_list,p_del);

        if l_idx > 0 then
            pipe row(substr(l_list,1,l_idx-1));
            l_list := substr(l_list,l_idx+length(p_del));

        else
            pipe row(l_list);
            exit;
        end if;
    end loop;
    return;
end split_tem;
/

