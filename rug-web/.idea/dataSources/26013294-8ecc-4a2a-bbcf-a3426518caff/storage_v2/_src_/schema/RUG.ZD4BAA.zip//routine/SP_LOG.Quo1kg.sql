create PROCEDURE     SP_LOG(peobjeto        INSTITUCIONAL.se_log.OBJETO%TYPE,
                 peDescLog       INSTITUCIONAL.se_log.DESC_LOG%TYPE
                ) IS

  PRAGMA AUTONOMOUS_TRANSACTION;

  vlIdError          Integer;
  vlDescError        varchar2(500);
  vlPsName           Varchar2(20);
  vlParametro        Varchar2(20);

 --Exceptions
  Ex_ErrParametro    EXCEPTION;
  Ex_ErrInsert       EXCEPTION;

 BEGIN

 --Validacion de parametros
    IF ( peDescLog IS NULL) THEN
        vlIdError   := 130;
        vlDescError :='Error: la descripcion del log es nula';
        RAISE Ex_ErrParametro;
    END IF;

    BEGIN
       INSERT INTO RUG_LOG( ID_LOG, OBJETO, DESC_LOG, FH_REGISTRO)
                  VALUES (SEQ_RUG_LOG.NEXTVAL, peobjeto, peDescLog, SYSTIMESTAMP);
       EXCEPTION WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR( -20734,vlPsName||':'||SQLCODE||':'||SQLERRM);
         ROLLBACK;
    END;

    COMMIT;

EXCEPTION
  WHEN Ex_ErrParametro THEN
      ROLLBACK;
      RAISE_APPLICATION_ERROR( -20734,vlPsName||':'||vlIdError||':'||vlDescError);

  WHEN OTHERS THEN
      ROLLBACK;
      RAISE_APPLICATION_ERROR( -20734,vlPsName||':'||SQLCODE||':'||SQLERRM);
      --Rollback;
END SP_LOG;
/

