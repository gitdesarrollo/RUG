create view V_GARANTIA_INSCRIPCION_PARTES as
SELECT   a.ID_GARANTIA_PEND,
            b.ID_PERSONA,
            b.ID_TRAMITE_TEMP,
            DECODE (c.PER_JURIDICA,
                    'PF', (SELECT   NOMBRE_PERSONA
                             FROM   RUG_PERSONAS_FISICAS
                            WHERE   ID_PERSONA = b.ID_PERSONA),
                    NULL)
               AS NOMBRE,
            DECODE (c.PER_JURIDICA,
                    'PF', (SELECT   AP_PATERNO
                             FROM   RUG_PERSONAS_FISICAS
                            WHERE   ID_PERSONA = b.ID_PERSONA),
                    NULL)
               AS APELLIDO_PATERNO,
            DECODE (c.PER_JURIDICA,
                    'PF', (SELECT   AP_MATERNO
                             FROM   RUG_PERSONAS_FISICAS
                            WHERE   ID_PERSONA = b.ID_PERSONA),
                    NULL)
               APELLIDO_MATERNO,
            DECODE (c.PER_JURIDICA,
                    'PM', (SELECT   RAZON_SOCIAL
                             FROM   RUG_PERSONAS_MORALES
                            WHERE   ID_PERSONA = b.ID_PERSONA),
                    NULL)
               AS RAZON_SOCIAL,
            d.DESC_PARTE,
            c.PER_JURIDICA,
            c.FOLIO_MERCANTIL,
            c.RFC
     FROM   RUG_REL_TRAM_INC_GARAN a,
            RUG_REL_TRAM_INC_PARTES b,
            RUG_PERSONAS c,
            RUG_PARTES d
    WHERE       a.id_tramite_temp = b.id_tramite_temp
            AND C.ID_PERSONA = B.ID_PERSONA
            AND B.ID_PARTE = D.ID_PARTE
            AND a.ID_GARANTIA_PEND NOT IN
                     (SELECT   ID_GARANTIA_PEND FROM RUG_GARANTIAS)
/

