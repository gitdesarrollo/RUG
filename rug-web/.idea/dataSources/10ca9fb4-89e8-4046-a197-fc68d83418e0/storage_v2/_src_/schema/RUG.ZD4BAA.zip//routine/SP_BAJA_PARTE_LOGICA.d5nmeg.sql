create PROCEDURE           SP_BAJA_PARTE_LOGICA 
                            (
                                peIdTramite            IN  NUMBER, --idTramite terminado al que se le borrara la parte
                                peIdPersona            IN  NUMBER, --ID DE LA PERSONA QUE SE LE BORRARA AL TRAMITE
                                peIdParte              IN  NUMBER, --ID DE PARTE DE LA PERSONA QUE SE BORRARA
                                peBTerminado           IN  CHAR,   --BANDERA QUE INDICA SI ES UN TRAMITE TERMINADO, VALORES POSIBLES V o F
                                psResult              OUT  INTEGER,   
                                psTxResult            OUT  VARCHAR2                             
                            )
IS
 
Ex_ErrParametro EXCEPTION;

BEGIN

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_PARTE_LOGICA', 'peIdTramite', peIdTramite, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_PARTE_LOGICA', 'peIdPersona', peIdPersona, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_PARTE_LOGICA', 'peIdParte', peIdParte, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_PARTE_LOGICA', 'peBTerminado', peBTerminado, 'IN');

 INSERT INTO RUG_PARAM_PLS
 VALUES(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_PARTE_LOGICA', 'peIdTramite', CAST(peIdTramite AS VARCHAR2(100)), SYSDATE, 'AC', 'IN');

 INSERT INTO RUG_PARAM_PLS
 VALUES(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_PARTE_LOGICA', 'peIdPersona', CAST(peIdPersona AS VARCHAR2(100)), SYSDATE, 'AC', 'IN');

 INSERT INTO RUG_PARAM_PLS
 VALUES(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_PARTE_LOGICA', 'peIdParte', CAST(peIdParte AS VARCHAR2(100)), SYSDATE, 'AC', 'IN');

 INSERT INTO RUG_PARAM_PLS
 VALUES(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_PARTE_LOGICA', 'peBTerminado', CAST(peBTerminado AS VARCHAR2(100)), SYSDATE, 'AC', 'IN');


  IF peBTerminado NOT IN ('V','F') THEN
     RAISE Ex_ErrParametro;
  END IF;

  IF peBTerminado = 'V' THEN

  UPDATE RUG_REL_TRAM_PARTES
  SET STATUS_REG = 'IN', FECHA_REG = SYSDATE
  WHERE ID_TRAMITE = peIdTramite AND ID_PERSONA = peIdPersona AND ID_PARTE = peIdParte;

  END IF;

  IF peBTerminado = 'F' THEN

  UPDATE RUG_REL_TRAM_INC_PARTES
  SET STATUS_REG = 'IN', FECHA_REG = SYSDATE
  WHERE ID_TRAMITE_TEMP = peIdTramite AND ID_PERSONA = peIdPersona AND ID_PARTE = peIdParte;

  END IF;

  psResult   :=0;        
  psTxResult :='Actualizacion finalizada satisfactoriamente';

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_PARTE_LOGICA', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_PARTE_LOGICA', 'psTxResult', psTxResult, 'OUT');    



EXCEPTION 
  WHEN Ex_ErrParametro  THEN         
      psTxResult:= substr(psResult,1,250);
      DBMS_OUTPUT.PUT_LINE(psTxResult);
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_PARTE_LOGICA', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_PARTE_LOGICA', 'psTxResult', psTxResult, 'OUT');    


   WHEN OTHERS THEN
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      DBMS_OUTPUT.PUT_LINE(psTxResult);
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_PARTE_LOGICA', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_PARTE_LOGICA', 'psTxResult', psTxResult, 'OUT');    


END SP_BAJA_PARTE_LOGICA;
/

