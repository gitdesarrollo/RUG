create PROCEDURE         SP_BUSCA_PALABRAS (
                                                    peIdTramite         IN  NUMBER,
                                                    pePalabra           IN  CLOB,
                                                    psResult           OUT  NUMBER,
                                                    psTxResult         OUT  VARCHAR2                                                                                                        
                                               )

is 
 
vlRegistro     RUG.T_PALABRAS;
vlParametros    RUG.T_PALABRAS;
vlCadenaAuxRegistro VARCHAR2(10000);
vlPalabraexis    varchar2(150);
vlexiste         varchar2(150);

BEGIN                                               

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Bitacora_Tramite2', 'peIdTramite', peIdTramite, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Bitacora_Tramite2', 'pePalabra', pePalabra, 'IN');


    vlRegistro:= RUG.SPLITCADENA(pePalabra,' ');

    DBMS_OUTPUT.PUT_LINE('VOY A IR A HACER SPLIT CADENA');
    DBMS_OUTPUT.PUT_LINE('LA CADENA ES  '||pePalabra);
                 FOR i IN 1..vlRegistro.COUNT LOOP

                            vlCadenaAuxRegistro:= vlRegistro(i-1);
                        dbms_output.put_line('la palabra es ' ||vlCadenaAuxRegistro );

                           -- vlParametros:= INSTITUCIONAL.PKGSE_COMUN.SPLITCADENA(vlCadenaAuxRegistro,' '); 
                       begin     
                           SELECT count(*)
                           INTO  vlPalabraexis
                           FROM RUG_CAT_BUSC_PALABRAS
                           WHERE upper(PALABRA_CLAVE) = upper(vlCadenaAuxRegistro);
                           dbms_output.put_line('el resultado es ' || vlPalabraexis);
                         IF vlPalabraexis = 0 THEN
                           SELECT COUNT(*)
                           INTO vlexiste                           
                           FROM RUG_CAT_PALABRA_EXCLUIDA
                           WHERE upper(palabra) = upper(vlCadenaAuxRegistro);
                         END IF;                   
                       end;    

                     IF  vlexiste = 0 THEN                           
                         INSERT INTO RUG_CAT_BUSC_PALABRAS
                         VALUES (peIdTramite, vlCadenaAuxRegistro);
                     END IF;       

                   commit;
                           psResult   := 0;
                           psTxResult := 'Consulta satisfactoria';



                       end loop;



END SP_BUSCA_PALABRAS;
/

