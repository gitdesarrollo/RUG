create view V_RUG_FIRMA_MASIVA as
SELECT RFM.ID_FIRMA_MASIVA,
            FNCONCATIDTRAMITE (RFM.ID_FIRMA_MASIVA, '|', 1),
            RFM.ID_ARCHIVO,
            TRUNC (RFM.FECHA_REG) FECHA_REG,
            RA.ALGORITMO_HASH,
            (SELECT ARCHIVO
               FROM RUG_ARCHIVO
              WHERE ID_ARCHIVO = RFM.ID_ARCHIVO)
               ARCHIVO,
            0 ID_TIPO_TRAMITE,
            DECODE (
               DBMS_LOB.
               SUBSTR (FNCONCATIDTRAMITE (RFM.ID_FIRMA_MASIVA, '|', 0), 2),
               'ER', 1,
               0),
            DECODE (
               DBMS_LOB.
               SUBSTR (FNCONCATIDTRAMITE (RFM.ID_FIRMA_MASIVA, '|', 0), 3),
               'ER1', 'El paquete contiene tramites firmados',
               'ER2', 'El paquete contiene tramites fuera de status')
       FROM RUG_FIRMA_MASIVA RFM, RUG_ARCHIVO RA
      WHERE     RFM.ID_ARCHIVO = RA.ID_ARCHIVO
            AND RFM.ID_ARCHIVO <> 0
            AND RFM.STATUS_REG = 'AC'
   GROUP BY RFM.ID_FIRMA_MASIVA,
            RFM.ID_ARCHIVO,
            TRUNC (RFM.FECHA_REG),
            RA.ALGORITMO_HASH
   UNION ALL
   SELECT RFM.ID_FIRMA_MASIVA,
          TO_CLOB (RFM.ID_TRAMITE_TEMP),
          RFM.ID_ARCHIVO,
          TRUNC (RFM.FECHA_REG) FECHA_REG,
          NULL ALGORITMO_HASH,
          NULL ARCHIVO,
          (SELECT ID_TIPO_TRAMITE
             FROM TRAMITES_RUG_INCOMP
            WHERE ID_TRAMITE_TEMP = RFM.ID_TRAMITE_TEMP)
          + 200,
          DECODE ( (SELECT ID_STATUS_TRAM
                      FROM TRAMITES_RUG_INCOMP
                     WHERE ID_TRAMITE_TEMP = RFM.ID_TRAMITE_TEMP),
                  3, 1),
          DECODE ( (SELECT ID_STATUS_TRAM
                      FROM TRAMITES_RUG_INCOMP
                     WHERE ID_TRAMITE_TEMP = RFM.ID_TRAMITE_TEMP),
                  3, 'El tramite ya ha sido terminado')
     FROM RUG_FIRMA_MASIVA RFM
    WHERE RFM.ID_ARCHIVO = 0 AND RFM.STATUS_REG = 'AC'
/

