create PROCEDURE         SP_BAJA_GRUPO 
( 
    peIdPersonaPadre    IN    NUMBER,
    peIdUsuario         IN    NUMBER,
    peIdGrupo           IN    NUMBER,
    psResult           OUT    INTEGER,   
    psTxResult         OUT    VARCHAR2
 )
IS

vlCount         NUMBER;
Ex_ErrParametro EXCEPTION;
i               Number;


BEGIN

Dbms_output.put_line(1000); 

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_GRUPO', 'peIdPersonaPadre', peIdPersonaPadre, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_GRUPO', 'peIdUsuario', peIdUsuario, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_GRUPO', 'peIdGrupo', peIdGrupo, 'IN');

Dbms_output.put_line(0); 

       SELECT   COUNT ( * )
          INTO   vlCount
          FROM   RUG_GRUPOS
         WHERE   ID_GRUPO = peIdGrupo 
           AND   ID_ACREEDOR = peIdPersonaPadre;

        IF(vlCount < 1) THEN

            psResult:= -1;
            psTxResult := 'El grupo que desea borrar no existe';
            RAISE Ex_ErrParametro;

        END IF;


        UPDATE RUG_GRUPOS
           SET SIT_GRUPO = 'IN', 
               ID_USUARIO_BAJA = peIdUsuario, 
               FH_BAJA = SYSDATE
         WHERE ID_GRUPO = peIdGrupo;


        UPDATE RUG_REL_GRUPO_PRIVILEGIO
           SET SIT_RELACION = 'IN'
         WHERE ID_GRUPO = peIdGrupo;

         For i In(
                    Select ID_SUB_USUARIO 
                    From RUG_REL_GRUPO_ACREEDOR
                    Where id_grupo = peIdGrupo
                 ) Loop

            UPDATE REL_USU_ACREEDOR
               SET STATUS_REG = 'IN',
                   B_FIRMADO = 'N'
             WHERE ID_USUARIO = i.ID_SUB_USUARIO
               AND ID_ACREEDOR = peIdPersonaPadre;

            UPDATE RUG_REL_TRAM_INC_PARTES
            SET
                STATUS_REG = 'IN'
            WHERE ID_TRAMITE_TEMP IN(Select tra.id_tramite_temp
                                From RUG_REL_GRUPO_ACREEDOR gacrd, TRAMITES_RUG_INCOMP tra, 
                                     (Select id_tramite_temp, id_persona id_acreedor From RUG_REL_TRAM_INC_PARTES Where id_parte = 4 ) acrd,
                                     (Select id_tramite_temp, id_persona id_sub_usuario From RUG_REL_TRAM_INC_PARTES Where id_parte = 5 ) suser
                                Where 1=1
                                  and gacrd.id_acreedor = acrd.id_acreedor  
                                  and gacrd.id_sub_usuario = suser.id_sub_usuario
                                  and suser.id_tramite_temp = acrd.id_tramite_temp
                                  and tra.id_tramite_temp = acrd.id_tramite_temp
                                  and tra.id_tramite_temp = suser.id_tramite_temp
                                  and tra.id_tipo_tramite = 14
                                  and gacrd.id_grupo = peIdGrupo
                                  and acrd.id_acreedor = peIdPersonaPadre
                                  and suser.id_sub_usuario =i.ID_SUB_USUARIO);

         End Loop;




        UPDATE RUG_REL_GRUPO_ACREEDOR
           SET STATUS_REG = 'IN'
         WHERE ID_GRUPO = peIdGrupo;


        UPDATE RUG_SECU_USUARIOS
           SET ID_GRUPO = 2
         WHERE ID_GRUPO = peIdGrupo;


        SP_TRAMITES_REASIGNADOS(peIdPersonaPadre, NULL, peIdGrupo, NULL, NULL, 3, psResult, psTxResult);


        psResult := 0;
        psTxResult:= 'Baja de grupo exito';

        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_GRUPO', 'psResult', psResult, 'OUT');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_GRUPO', 'psTxResult', psTxResult, 'OUT');

    COMMIT;


EXCEPTION 
  WHEN Ex_ErrParametro  THEN
      ROLLBACK;
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_GRUPO', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_GRUPO', 'psTxResult', psTxResult, 'OUT');    

   WHEN OTHERS THEN
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      ROLLBACK;
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_GRUPO', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_GRUPO', 'psTxResult', psTxResult, 'OUT');    



END;
/

