create PROCEDURE         SP_ALTA_AVISO_PREVENTIVO 
                            (
                                peIdTramite          IN  NUMBER,
                                peDescBienes         IN  CLOB,
                                peIdUsuario          IN  NUMBER,
                                psResult            OUT  INTEGER,   
                                psTxResult          OUT  VARCHAR2                             
                            )
IS
                        

vlIdRegistro  NUMBER;
vlIPersona    NUMBER;
Ex_ErrParametro EXCEPTION;

BEGIN

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_AVISO_PREVENTIVO', 'peIdTramite', peIdTramite, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_AVISO_PREVENTIVO', 'peIdUsuario', peIdUsuario, 'IN');


        Begin
           SELECT ID_PERSONA
             INTO vlIPersona
             FROM RUG_REL_TRAM_INC_PARTES
            WHERE ID_TRAMITE_TEMP = peIdTramite 
              AND ID_PARTE = 1
              AND STATUS_REG = 'AC';
        Exception
            When NO_DATA_FOUND Then
                psResult := 69;
                Raise Ex_ErrParametro;
        End;

        vlIdRegistro := SEQ_ANOTACIONES.NEXTVAL;        

        INSERT INTO AVISOS_PREV
        VALUES(peIdTramite, vlIPersona, peDescBienes, peIdUsuario, vlIdRegistro);

        COMMIT;



  psResult   :=0;        
  psTxResult :='Insercion finalizada satisfactoriamente';

  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_AVISO_PREVENTIVO', 'psResult', psResult, 'OUT');
  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_AVISO_PREVENTIVO', 'psTxResult', psTxResult, 'OUT');    


EXCEPTION 
  WHEN Ex_ErrParametro  THEN         
--      psTxResult:= substr(psResult,1,250);
      psTxResult:= RUG.FN_MENSAJE_ERROR(psResult);
      ROLLBACK;
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_AVISO_PREVENTIVO', 'psResult', psResult, 'OUT');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_AVISO_PREVENTIVO', 'psTxResult', psTxResult, 'OUT');    

   WHEN OTHERS THEN
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      ROLLBACK;
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_AVISO_PREVENTIVO', 'psResult', psResult, 'OUT');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_AVISO_PREVENTIVO', 'psTxResult', psTxResult, 'OUT');    

END SP_ALTA_AVISO_PREVENTIVO;
/

