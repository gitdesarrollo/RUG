create PROCEDURE     MODIFICAR_USUARIO_MIGRADO (pIdPersonaMigrado IN NUMBER, pCausa IN VARCHAR2, pUsuario IN NUMBER) IS
	v_documento_id VARCHAR2(900);
	v_nit VARCHAR2(20);
	v_documento_id_fisicas VARCHAR2(500);
BEGIN
	SELECT rfc, curp_doc
	INTO v_nit, v_documento_id
	FROM rug_personas
	WHERE id_persona = pIdPersonaMigrado;

	SELECT curp
	INTO v_documento_id_fisicas
	FROM rug_personas_fisicas
	WHERE id_persona = pIdPersonaMigrado;

	IF (v_documento_id IS NULL) THEN
		v_documento_id := v_documento_id_fisicas;
	END IF;

	-- insertar en bitacora de operaciones
	INSERT INTO RUG.MODIFICACION_MIGRADO(MODIFICACION_ID, ID_PERSONA, FECHA, DOCUMENTO_ID, NIT, USUARIO_ID, CAUSA)
	VALUES(SEQ_MODIFICACION_MIGRADO.NEXTVAL, pIdPersonaMigrado, SYSDATE, v_documento_id, v_nit, pUsuario, pCausa);

	-- actualizar persona
	UPDATE RUG.RUG_PERSONAS SET RFC=RFC||'_MOD', CURP_DOC=CURP_DOC||'_MOD' WHERE ID_PERSONA = pIdPersonaMigrado;

	UPDATE RUG.RUG_PERSONAS_FISICAS SET CURP=CURP||'_MOD' WHERE ID_PERSONA = pIdPersonaMigrado;

	COMMIT;	
END;
/

