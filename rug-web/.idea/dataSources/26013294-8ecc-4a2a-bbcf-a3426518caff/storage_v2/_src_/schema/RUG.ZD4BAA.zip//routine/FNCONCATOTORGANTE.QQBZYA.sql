create FUNCTION         FNCONCATOTORGANTE (
                      peIdTramite      NUMBER,
                      peOpcion         NUMBER     --- 1 PARA NOMBRE DE OTORGANTE, 2 PARA FOLIO  MERCANTIL DEL OTORGANTE
                                                  --- 3 PARA NOMBRE DE OTORGANTE INCOMPLETO
                                                  --- 5 PARA CURP		--FR
                      )
RETURN VARCHAR2 

IS  
    vlNombreOtorgante       VARCHAR2(1000);
    vlNombreOtorganteAux    VARCHAR2(2000);    

    vlNombreOtorganteT       VARCHAR2(1000);
    vlNombreOtorganteAuxT    VARCHAR2(2000);    


    vlFolioOtorgante       VARCHAR2(1000);
    vlFolioOtorganteAux    VARCHAR2(2000);  

    vlFolioOtorganteT       VARCHAR2(1000);
    vlFolioOtorganteAuxT    VARCHAR2(2000);

    vlCurpOtorganteT       VARCHAR2(1000);					--FR
    vlCurpOtorganteAuxT    VARCHAR2(2000);					--FR

    vlSeparador             VARCHAR(10);


    CURSOR cursConcatenaOtorgante(cpeIdTramite IN NUMBER) IS
    SELECT DECODE (
                   RRTP.PER_JURIDICA,
                   'PF',
                   (SELECT      RUG_ACENTOS (UPPER (TRIM (NOMBRE_PERSONA)))
                             || ' '
                             || RUG_ACENTOS (UPPER (TRIM (AP_PATERNO)))
                             || ' '
                             || RUG_ACENTOS (UPPER (TRIM (AP_MATERNO)))
                      FROM   RUG_PERSONAS_H
                     WHERE   ID_PERSONA = RRTP.ID_PERSONA
                       AND RRTP.ID_TRAMITE = ID_TRAMITE
                     AND ID_PARTE = 1),
                   'PM',
                   (SELECT   RUG_ACENTOS (UPPER (TRIM (RAZON_SOCIAL)))
                      FROM   RUG_PERSONAS_H
                     WHERE   ID_PERSONA = RRTP.ID_PERSONA
                       AND RRTP.ID_TRAMITE = ID_TRAMITE
                     AND ID_PARTE = 1)
                )
                   NOMBRE
      FROM RUG_REL_TRAM_PARTES RRTP  
     WHERE ID_TRAMITE = cpeIdTramite
       AND ID_PARTE = 1
       AND STATUS_REG = 'AC'
     ORDER BY RRTP.ID_PERSONA ASC;

       CURSOR cursConcatenaOtorganteTemp(cpeIdTramite IN NUMBER) IS       
        SELECT DECODE (
                       RRTP.PER_JURIDICA,
                       'PF',
                       (SELECT      RUG_ACENTOS (UPPER (TRIM (NOMBRE_PERSONA)))
                                 || ' '
                                 || RUG_ACENTOS (UPPER (TRIM (AP_PATERNO)))
                                 || ' '
                                 || RUG_ACENTOS (UPPER (TRIM (AP_MATERNO)))
                          FROM   RUG_PERSONAS_FISICAS
                         WHERE   ID_PERSONA = RRTP.ID_PERSONA),
                       'PM',
                       (SELECT   RUG_ACENTOS (UPPER (TRIM (RAZON_SOCIAL)))
                          FROM   RUG_PERSONAS_MORALES
                         WHERE   ID_PERSONA = RRTP.ID_PERSONA)
                    ) NOMBRE
          FROM RUG_REL_TRAM_INC_PARTES RRTP  
         WHERE ID_TRAMITE_TEMP = cpeIdTramite
           AND ID_PARTE = 1
           AND STATUS_REG = 'AC'
         ORDER BY RRTP.ID_PERSONA ASC;


    CURSOR cursConcatenaFolioMercantil(cpeIdTramite IN NUMBER) IS
    SELECT RUG_ACENTOS (UPPER (TRIM (RP.FOLIO_MERCANTIL)))
      FROM RUG_REL_TRAM_PARTES RRTP, RUG_PERSONAS_H RP  
     WHERE RP.ID_TRAMITE = cpeIdTramite
       AND RRTP.ID_TRAMITE = RP.ID_TRAMITE
       AND RP.ID_PERSONA = RRTP.ID_PERSONA 
       AND RRTP.ID_PARTE = 1
       AND RRTP.ID_PARTE = RP.ID_PARTE
       AND RRTP.STATUS_REG = 'AC'
     ORDER BY RRTP.ID_PERSONA ASC; 

    CURSOR cursConcatenaFolioMercantilT(cpeIdTramite IN NUMBER) IS    
    SELECT RUG_ACENTOS (UPPER (TRIM (RP.FOLIO_MERCANTIL)))
      FROM RUG_REL_TRAM_INC_PARTES RRTP, RUG_PERSONAS RP  
     WHERE ID_TRAMITE_TEMP = cpeIdTramite
       AND RP.ID_PERSONA = RRTP.ID_PERSONA 
       AND ID_PARTE = 1       
       AND STATUS_REG = 'AC'
     ORDER BY RRTP.ID_PERSONA ASC; 

     CURSOR cursConcatenaCurp(cpeIdTramite IN NUMBER) IS			--FR
    SELECT RUG_ACENTOS (UPPER (TRIM (RP.CURP)))					
      FROM RUG_REL_TRAM_PARTES RRTP, RUG_PERSONAS_H RP  
     WHERE RP.ID_TRAMITE = cpeIdTramite
       AND RRTP.ID_TRAMITE = RP.ID_TRAMITE
       AND RP.ID_PERSONA = RRTP.ID_PERSONA 
       AND RRTP.ID_PARTE = 1
       AND RRTP.ID_PARTE = RP.ID_PARTE
       AND RRTP.STATUS_REG = 'AC'
     ORDER BY RRTP.ID_PERSONA ASC;      					--/FR


BEGIN


--   REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'FNCONCATOTORGANTE', 'peIdTramite', peIdTramite, 'IN');
--   REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'FNCONCATOTORGANTE', 'peOpcion', peOpcion, 'IN');


    vlSeparador := '<br>';



    IF (peOpcion = 1) THEN
        BEGIN
            OPEN cursConcatenaOtorgante(peIdTramite);
                LOOP
                    FETCH cursConcatenaOtorgante INTO vlNombreOtorgante;
                    EXIT WHEN cursConcatenaOtorgante%NOTFOUND;

                    vlNombreOtorganteAux := CONCAT(vlNombreOtorganteAux, vlNombreOtorgante || vlSeparador);                    

                END LOOP;
            CLOSE cursConcatenaOtorgante;
        END;
    END IF;    

    IF(peOpcion = 2) THEN
        BEGIN    
            OPEN cursConcatenaFolioMercantil(peIdTramite);
                LOOP
                    FETCH cursConcatenaFolioMercantil INTO vlFolioOtorgante;
                    EXIT WHEN cursConcatenaFolioMercantil%NOTFOUND;                    
                    vlFolioOtorganteAux := CONCAT(vlFolioOtorganteAux, vlFolioOtorgante || vlSeparador);

                END LOOP;
            CLOSE cursConcatenaFolioMercantil;

            vlNombreOtorganteAux := vlFolioOtorganteAux;

        END;    
    END IF;


     IF (peOpcion = 3) THEN
        BEGIN
            OPEN cursConcatenaOtorganteTemp(peIdTramite);
                LOOP
                    FETCH cursConcatenaOtorganteTemp INTO vlNombreOtorganteT;
                    EXIT WHEN cursConcatenaOtorganteTemp%NOTFOUND;

                    vlNombreOtorganteAuxT := CONCAT(vlNombreOtorganteAuxT, vlNombreOtorganteT || vlSeparador);                    

                END LOOP;
            CLOSE cursConcatenaOtorganteTemp;

            vlNombreOtorganteAux := vlNombreOtorganteAuxT;                     

        END;
    END IF;    


     IF(peOpcion = 4) THEN
        BEGIN    
            OPEN cursConcatenaFolioMercantilT(peIdTramite);
                LOOP
                    FETCH cursConcatenaFolioMercantilT INTO vlFolioOtorganteT;
                    EXIT WHEN cursConcatenaFolioMercantilT%NOTFOUND;                    
                    vlFolioOtorganteAuxT := CONCAT(vlFolioOtorganteAuxT, vlFolioOtorganteT || vlSeparador);

                END LOOP;
            CLOSE cursConcatenaFolioMercantilT;

            vlNombreOtorganteAux := vlFolioOtorganteAuxT;

        END;    
    END IF;

     IF (peOpcion = 5) THEN							--FR
        BEGIN
            OPEN cursConcatenaCurp(peIdTramite);
                LOOP
                    FETCH cursConcatenaCurp INTO vlCurpOtorganteT;
                    EXIT WHEN cursConcatenaCurp%NOTFOUND;
                    vlCurpOtorganteAuxT := CONCAT(vlCurpOtorganteAuxT, vlCurpOtorganteT || vlSeparador);                                            
                END LOOP;
            CLOSE cursConcatenaCurp;            
            vlNombreOtorganteAux := vlCurpOtorganteAuxT;                     
        END;
    END IF;									--/FR


    RETURN SUBSTR(vlNombreOtorganteAux, 0, LENGTH(vlNombreOtorganteAux) - LENGTH(vlSeparador));

END;
/

