create view V_SE_CAT_LOCALIDADES_RUG as
SELECT   ID_LOCALIDAD,
              CVE_PAIS,
              CVE_ESTADO,
              CVE_MUNICIP_DELEG,
              CVE_LOCALIDAD,
              INITCAP (DESC_LOCALIDAD) AS DESC_LOCALIDAD,
              CODIGO_POSTAL,
              INITCAP (DESC_LOCALIDAD) || ' ' || CODIGO_POSTAL
                 DESC_LOCALIDAD_CP,
              F_INICIO_VIGENCIA,
              F_FIN_VIGENCIA,
              TIPO_ASENTAMIENTO,
              TIPO_ASENTAMIENTO_CD,
              CVE_TEMP,
              SIT_LOCALIDAD
       FROM   INSTITUCIONAL.SE_CAT_LOCALIDADES
      WHERE   UPPER (DESC_LOCALIDAD) NOT LIKE UPPER ('Otra No Especificada%')
              AND F_FIN_VIGENCIA > SYSDATE
   ORDER BY   CVE_ESTADO,
              CVE_MUNICIP_DELEG,
              DESC_LOCALIDAD,
              CODIGO_POSTAL
/

