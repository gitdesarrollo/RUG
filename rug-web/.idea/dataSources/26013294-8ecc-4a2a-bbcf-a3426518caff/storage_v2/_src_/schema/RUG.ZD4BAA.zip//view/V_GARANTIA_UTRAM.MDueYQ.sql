create view V_GARANTIA_UTRAM as
SELECT   HTT.ID_GARANTIA,
            HTP.FECHA_CREACION AS FECHA_INSCRIPCION,
            HTT.ID_ULTIMO_TRAMITE AS ID_TRAMITE,
            HTT.ID_TIPO_TRAMITE,
            RCT.DESCRIPCION,
            HTT.FECHA_CREACION,
            HPP.FECHA_CREACION AS FECHA_ULTIMO
     FROM            (SELECT   RGH.ID_GARANTIA,
                               RGH.ID_ULTIMO_TRAMITE,
                               TR.ID_TIPO_TRAMITE,
                               TR.FECHA_CREACION
                        FROM   RUG_GARANTIAS_H RGH, TRAMITES TR
                       WHERE   RGH.ID_ULTIMO_TRAMITE = TR.ID_TRAMITE) HTT
                  INNER JOIN
                     (SELECT   RGH.ID_GARANTIA,
                               RGH.ID_ULTIMO_TRAMITE,
                               TR.FECHA_CREACION,
                               RGH.OTROS_TERMINOS_GARANTIA,
                               RGH.DESC_GARANTIA
                        FROM   RUG_GARANTIAS_H RGH, TRAMITES TR
                       WHERE   RGH.ID_ULTIMO_TRAMITE = TR.ID_TRAMITE
                               AND TR.ID_TIPO_TRAMITE in (1,31)) HTP
                  ON HTT.ID_GARANTIA = HTP.ID_GARANTIA
               INNER JOIN
                  (SELECT   RG.ID_GARANTIA,
                            RG.ID_ULTIMO_TRAMITE,
                            TR.FECHA_CREACION
                     FROM      RUG_GARANTIAS RG
                            INNER JOIN
                               TRAMITES TR
                            ON RG.ID_ULTIMO_TRAMITE = TR.ID_TRAMITE) HPP
               ON HTT.ID_GARANTIA = HPP.ID_GARANTIA
            INNER JOIN
               RUG_CAT_TIPO_TRAMITE RCT
            ON HTT.ID_TIPO_TRAMITE = RCT.ID_TIPO_TRAMITE
/

