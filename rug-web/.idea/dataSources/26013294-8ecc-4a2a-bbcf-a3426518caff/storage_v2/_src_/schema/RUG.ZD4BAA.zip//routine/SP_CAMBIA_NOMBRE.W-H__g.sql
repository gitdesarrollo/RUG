create PROCEDURE     SP_CAMBIA_NOMBRE 
(
    P_FOLIO         IN RUG.RUG_PERSONAS.FOLIO_MERCANTIL%TYPE,
    P_NOMBRE_RAZON  IN RUG.RUG_PERSONAS_FISICAS.NOMBRE_PERSONA%TYPE,
    P_AP_PATERNO    IN RUG.RUG_PERSONAS_FISICAS.AP_PATERNO%TYPE,
    P_AP_MATERNO    IN RUG.RUG_PERSONAS_FISICAS.AP_MATERNO%TYPE,
    psResult        OUT  INTEGER,   
    psTxResult      OUT  VARCHAR2
)
IS
    V_COUNT             NUMBER;
    V_ID_PERSONA        RUG_PERSONAS_FISICAS.ID_PERSONA%TYPE;
    V_PERS_JUR          RUG_PERSONAS.PER_JURIDICA%TYPE;

    EXC_GARANT_VIG     EXCEPTION;


    PRAGMA AUTONOMOUS_TRANSACTION;

BEGIN 

    REG_PARAM_PLS2('SP_CAMBIA_NOMBRE', 'P_FOLIO', P_FOLIO, 'IN');
    REG_PARAM_PLS2('SP_CAMBIA_NOMBRE', 'P_NOMBRE_RAZON', P_NOMBRE_RAZON, 'IN');
    REG_PARAM_PLS2('SP_CAMBIA_NOMBRE', 'P_AP_PATERNO', P_AP_PATERNO, 'IN');
    REG_PARAM_PLS2('SP_CAMBIA_NOMBRE', 'P_AP_MATERNO', P_AP_MATERNO, 'IN');



    SELECT DISTINCT PER_JURIDICA
      INTO V_PERS_JUR
      FROM RUG_PERSONAS P
     WHERE P.FOLIO_MERCANTIL = P_FOLIO;    

    SELECT NVL((
                SELECT COUNT(*)
                  FROM RUG_PERSONAS
                 WHERE FOLIO_MERCANTIL = P_FOLIO)
              , 0
              ) 
      INTO V_ID_PERSONA
      FROM DUAL;

    IF V_ID_PERSONA > 0 THEN

        SELECT NVL(
                    (SELECT COUNT(*) 
                       FROM RUG.RUG_GARANTIAS G
                      INNER JOIN RUG.TRAMITES T
                         ON T.ID_TRAMITE = G.ID_ULTIMO_TRAMITE
                      INNER JOIN RUG_REL_TRAM_PARTES TP
                         ON TP.ID_TRAMITE = G.ID_ULTIMO_TRAMITE
                      WHERE G.GARANTIA_STATUS = 'AC'
                        AND TP.ID_PERSONA IN (SELECT P.ID_PERSONA
                                                FROM RUG_PERSONAS P
                                               WHERE FOLIO_MERCANTIL = P_FOLIO)
                    )
                  , 
                    0
                  )
          INTO V_COUNT
          FROM DUAL;

        IF V_COUNT > 0 THEN

            RAISE EXC_GARANT_VIG;

        END IF;

        IF V_PERS_JUR = 'PF' THEN

            UPDATE RUG.RUG_PERSONAS_FISICAS 
               SET NOMBRE_PERSONA = P_NOMBRE_RAZON
                 , AP_PATERNO = P_AP_PATERNO
                 , AP_MATERNO = P_AP_MATERNO
             WHERE ID_PERSONA IN (SELECT ID_PERSONA
                                    FROM RUG_PERSONAS
                                   WHERE FOLIO_MERCANTIL = P_FOLIO);      

        ELSE
            IF V_PERS_JUR = 'PM' THEN

            UPDATE RUG.RUG_PERSONAS_MORALES 
               SET RAZON_SOCIAL = P_NOMBRE_RAZON
             WHERE ID_PERSONA  IN (SELECT ID_PERSONA
                                     FROM RUG_PERSONAS
                                    WHERE FOLIO_MERCANTIL = P_FOLIO);

            END IF;

        END IF;

        COMMIT;

    END IF;   

    psResult := 0;

    REG_PARAM_PLS2('SP_CAMBIA_NOMBRE', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS2('SP_CAMBIA_NOMBRE', 'psTxResult', RUG.FN_MENSAJE_ERROR(psResult), 'OUT');

EXCEPTION
    WHEN EXC_GARANT_VIG THEN
        psResult := 133;
        psTxResult:= RUG.FN_MENSAJE_ERROR(psResult);
        ROLLBACK;
        REG_PARAM_PLS2('SP_CAMBIA_NOMBRE', 'psResult', psResult, 'OUT');
        REG_PARAM_PLS2('SP_CAMBIA_NOMBRE', 'psTxResult', psTxResult, 'OUT');    

    WHEN OTHERS THEN
        psResult  := 999;   
        psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
        ROLLBACK;
        REG_PARAM_PLS2('SP_CAMBIA_NOMBRE', 'psResult', psResult, 'OUT');
        REG_PARAM_PLS2('SP_CAMBIA_NOMBRE', 'psTxResult', psTxResult, 'OUT');    

END;
/

