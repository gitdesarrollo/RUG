create FUNCTION           FNVALIDAFECHAS (peIdGarantia     NUMBER,
                                              peIdTramiteTemp  NUMBER                           
                                             )
RETURN NUMBER

IS

--vlFechaGarantia     DATE;
--vlFechaTramite      DATE;

vlTramiteTemGar     NUMBER;
vlTramiteTem        NUMBER;
vlResultado         NUMBER;


BEGIN

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'FNValidaModificaOtorgante', 'peIdGarantia', peIdGarantia, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'FNValidaModificaOtorgante', 'peIdTramiteTemp', peIdTramiteTemp, 'IN');

   BEGIN


        Select ID_TRAMITE_TEMP
          INTO vlTramiteTem
          from RUG_BITAC_TRAMITES
        Where ID_TRAMITE_TEMP = peIdTramiteTemp
        AND STATUS_REG = 'AC';


        SELECT   ID_TRAMITE_TEMP
          INTO   vlTramiteTemGar
          FROM   (  SELECT   ID_TRAMITE_TEMP
                      FROM   V_TRAMITES_TERMINADOS
                     WHERE   ID_GARANTIA = peIdGarantia
                  ORDER BY   1 DESC)
         WHERE   ROWNUM = 1;

        IF(vlTramiteTem <= vlTramiteTemGar)THEN
            vlResultado := 0;
        ELSE
            vlResultado := 1;
        END IF;


   END;

   RETURN vlResultado;

END;
/

