create PROCEDURE         SP_BAJA_ACREEDOR_REP 
                            (
                                peIdUsuario         IN   NUMBER,
                                peIdAcreedorRep     IN   NUMBER,                               
                                psResult            OUT  INTEGER,   
                                psTxResult          OUT  VARCHAR2                             
                            )
IS

vlCount NUMBER;
vlBandera NUMBER;
vlsalida number;
vlTxsalida varchar2(500);

Ex_ErrParametro EXCEPTION;



CURSOR cursPersonas(cpeIdUsuario IN NUMBER) IS
    Select ID_PERSONA from RUG_SECU_USUARIOS
    Where CVE_ACREEDOR IN(
        Select CVE_ACREEDOR 
          from RUG_SECU_USUARIOS
         Where ID_PERSONA = cpeIdUsuario);
     cursPers_Rec cursPersonas%ROWTYPE;



BEGIN


REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_ACREEDOR_REP', 'peIdUsuario', peIdUsuario, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_ACREEDOR_REP', 'peIdAcreedorRep', peIdAcreedorRep, 'IN');



        UPDATE RUG_REL_MODIFICA_ACREEDOR
           SET STATUS_REG = 'IN'
         WHERE ID_ACREEDOR_NUEVO = peIdAcreedorRep
           AND ID_USUARIO_MODIFICA = peIdUsuario
           AND STATUS_REG = 'AC';


        UPDATE REL_USU_ACREEDOR
        SET STATUS_REG = 'IN', FECHA_REG = SYSDATE
        WHERE ID_USUARIO = peIdUsuario AND ID_ACREEDOR = peIdAcreedorRep;



        COMMIT;

        Select COUNT(*)
          INTO vlCount 
        from REL_USU_ACREEDOR
        WHERE ID_USUARIO = peIdUsuario
          AND STATUS_REG = 'AC';

        IF(vlCount = 0) THEN
            SP_MODIFICA_PERFIL(peIdUsuario, 2, vlsalida, vlTxsalida);        


            SELECT DECODE(CVE_USUARIO,CVE_ACREEDOR, 0, 1) 
              INTO vlBandera 
              FROM RUG_SECU_USUARIOS
            WHERE ID_PERSONA = peIdUsuario;

            IF (vlBandera = 0) THEN -- PADRE

             FOR cursPers_Rec IN cursPersonas(peIdUsuario)                
                    LOOP
                         DELETE RUG_REL_GRUPO_ACREEDOR
                          WHERE ID_ACREEDOR = peIdAcreedorRep
                            AND ID_SUB_USUARIO = cursPers_Rec.ID_PERSONA;
                    END LOOP;                

            END IF;

            IF(vlBandera = 1) THEN -- HIJO

                DELETE RUG_REL_GRUPO_ACREEDOR
                 WHERE ID_ACREEDOR = peIdAcreedorRep
                   AND ID_SUB_USUARIO = peIdUsuario;


            END IF;


            IF(vlsalida != 0) THEN
                psResult   :=31;        
                psTxResult := RUG.FN_MENSAJE_ERROR(psResult);    
                RAISE Ex_ErrParametro;
            END IF;            

        END IF;



        COMMIT;

  psResult   :=0;        
  psTxResult :='Actualizacion finalizada satisfactoriamente';

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_ACREEDOR_REP', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_ACREEDOR_REP', 'psTxResult', psTxResult, 'OUT');    


EXCEPTION 
  WHEN Ex_ErrParametro  THEN         
      psTxResult:= substr(psResult,1,250);
      ROLLBACK;
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_ACREEDOR_REP', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_ACREEDOR_REP', 'psTxResult', psTxResult, 'OUT');  

   WHEN OTHERS THEN
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      ROLLBACK;
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_ACREEDOR_REP', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_ACREEDOR_REP', 'psTxResult', psTxResult, 'OUT');

END;
/

