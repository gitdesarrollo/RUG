create PROCEDURE         SP_BAJA_TRAMITE_INCOMP 
                            (
                                peIdTramiteTemp      IN  RUG_REL_TRAM_INC_GARAN.ID_TRAMITE_TEMP%TYPE,--  IDENTIFICADOR DEL TRAMITE ASOCIADO A LA GARANTIA                               
                                psResult            OUT  INTEGER,   
                                psTxResult          OUT  VARCHAR2                             
                            )
IS

Ex_ErrParametro EXCEPTION;

vlCant    INT;

BEGIN

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_TRAMITE_INCOMP', 'peIdTramiteTemp', peIdTramiteTemp, 'IN');

    SELECT COUNT(*)
      INTO vlCant
      FROM TRAMITES_RUG_INCOMP
     WHERE ID_TRAMITE_TEMP = peIdTramiteTemp
       AND ID_STATUS_TRAM IN (3,6,7,8,9,10,11);

IF (vlCant = 0) THEN
    BEGIN

      vlCant := 0;

      UPDATE TRAMITES_RUG_INCOMP
      SET STATUS_REG = 'IN', FECHA_STATUS = (SYSDATE)       
      WHERE ID_TRAMITE_TEMP =  peIdTramiteTemp;

      UPDATE RUG_REL_TRAM_INC_PARTES 
      SET STATUS_REG = 'IN', FECHA_REG = (SYSDATE)
      WHERE ID_TRAMITE_TEMP =  peIdTramiteTemp;

      UPDATE RUG_REL_TRAM_INC_GARAN
      SET STATUS_REG = 'IN', FECHA_REG = (SYSDATE)
      WHERE ID_TRAMITE_TEMP =  peIdTramiteTemp;

      UPDATE RUG_FIRMA_MASIVA
         SET STATUS_REG = 'IN'
      WHERE ID_FIRMA_MASIVA = peIdTramiteTemp;


      SELECT COUNT(*) 
        INTO vlCant
        FROM TRAMITES_RUG_INCOMP
       WHERE ID_TRAMITE_TEMP = peIdTramiteTemp;


       UPDATE RUG_BITAC_TRAMITES
          SET STATUS_REG = 'IN'
        WHERE ID_TRAMITE_TEMP = peIdTramiteTemp;


       IF(vlCant > 0)THEN

          DELETE RUG.RUG_TRAMITE_RASTREO
           WHERE ID_TRAMITE_TEMP IN (SELECT ID_TRAMITE_TEMP 
                                       FROM RUG_FIRMA_MASIVA
                                      WHERE ID_FIRMA_MASIVA = peIdTramiteTemp);

       END IF;


       /** GGR 23/04/13 SE AGREGA LA ELIMINACI? DE TRAMITES DE ANOTACI? SIN GARANT? **/
       --SP_ANOTAC_CG_SG_DEL( peIdTramiteTemp , psResult, psTxResult);  

      COMMIT;

      psResult   :=0;        
      psTxResult :='Baja finalizada satisfactoriamente';

    END;

ELSE 

    psResult := 66;   
    psTxResult:= RUG.FN_MENSAJE_ERROR(psResult);

END IF;

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_TRAMITE_INCOMP', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_TRAMITE_INCOMP', 'psTxResult', psTxResult, 'OUT');    



EXCEPTION 
  WHEN Ex_ErrParametro  THEN         
      psTxResult:= substr(psResult,1,250);

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_TRAMITE_INCOMP', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_TRAMITE_INCOMP', 'psTxResult', psTxResult, 'OUT');    


   WHEN OTHERS THEN
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_TRAMITE_INCOMP', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_TRAMITE_INCOMP', 'psTxResult', psTxResult, 'OUT');    


END SP_BAJA_TRAMITE_INCOMP;
/

