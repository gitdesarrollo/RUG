create view V_TRAM_TEMP_ACREEDOR_REP as
SELECT   RRTIP.ID_TRAMITE_TEMP,
            RRTIP.ID_PERSONA,
            RP.PER_JURIDICA,
            DECODE (
               RP.PER_JURIDICA,
               'PF',
               (SELECT      NOMBRE_PERSONA
                         || ' '
                         || AP_PATERNO
                         || ' '
                         || AP_MATERNO
                  FROM   RUG_PERSONAS_FISICAS
                 WHERE   ID_PERSONA = RP.ID_PERSONA),
               'PM',
               (SELECT   RAZON_SOCIAL
                  FROM   RUG_PERSONAS_MORALES
                 WHERE   ID_PERSONA = RP.ID_PERSONA)
            )
               AS NOMBRE_ACREEDOR
     FROM   RUG_REL_TRAM_INC_PARTES RRTIP, RUG_PERSONAS RP
    WHERE   RRTIP.ID_PERSONA = RP.ID_PERSONA AND RRTIP.ID_PARTE = 4
/

