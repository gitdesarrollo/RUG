create PROCEDURE         SP_BAJA_PARTE_LOGICA_MASIVA 
                            (
                                peIdTramiteTemp        IN  NUMBER, --idTramite terminado al que se le borrara la parte
                                peIdPersona            IN  NUMBER, --ID DE LA PERSONA QUE SE LE BORRARA AL TRAMITE
                                peIdParte              IN  NUMBER, --ID DE PARTE DE LA PERSONA QUE SE BORRARA
                                psResult              OUT  INTEGER,   
                                psTxResult            OUT  VARCHAR2                             
                            )
IS

 CURSOR cursPartes(cpeIdTramiteTemp in NUMBER,cpeIdParte IN NUMBER) IS   --BUSCAMOS LAS PERSONAS POR TRAMITE Y PARTE
   SELECT ID_PERSONA,ID_PARTE,ID_TRAMITE_TEMP FROM RUG_REL_TRAM_INC_PARTES WHERE ID_TRAMITE_TEMP = cpeIdTramiteTemp AND ID_PARTE=cpeIdParte;
   cursPartes_Rec cursPartes%ROWTYPE;

BEGIN
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_PARTE_LOGICA_MASIVA', 'peIdTramite', peIdTramiteTemp, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_PARTE_LOGICA_MASIVA', 'peIdPersona', peIdPersona, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_PARTE_LOGICA_MASIVA', 'peIdParte', peIdParte, 'IN');

BEGIN
  FOR cursPartes_Rec IN cursPartes(peIdTramiteTemp,peIdParte)
     LOOP

        DELETE RUG_REL_TRAM_INC_PARTES
        --SET STATUS_REG = 'IN', FECHA_REG = SYSDATE
        WHERE ID_TRAMITE_TEMP = cursPartes_Rec.ID_TRAMITE_TEMP AND ID_PERSONA = cursPartes_Rec.ID_PERSONA AND ID_PARTE = cursPartes_Rec.ID_PARTE;

     END LOOP;
   END;


  COMMIT;

  psResult   :=0;        
  psTxResult :='Actualizacion finalizada satisfactoriamente';

  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_PARTE_LOGICA_MASIVA', 'psResult', psResult, 'OUT');
  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_PARTE_LOGICA_MASIVA', 'psTxResult', psTxResult, 'OUT');    



EXCEPTION 
   WHEN OTHERS THEN
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      DBMS_OUTPUT.PUT_LINE(psTxResult);
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_PARTE_LOGICA_MASIVA', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_PARTE_LOGICA_MASIVA', 'psTxResult', psTxResult, 'OUT');    


END SP_BAJA_PARTE_LOGICA_MASIVA;
/

