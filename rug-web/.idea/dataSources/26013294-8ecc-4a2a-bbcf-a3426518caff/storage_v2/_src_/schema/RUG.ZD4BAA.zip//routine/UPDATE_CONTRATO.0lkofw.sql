create procedure update_contrato(terminos in varchar, contrato in int) as
begin
    UPDATE RUG_CONTRATO SET OTROS_TERMINOS_CONTRATO = terminos WHERE ID_CONTRATO = contrato;
    commit;
end;
/

