create PROCEDURE SP_ALTA_TRAMITE_EMBARGO(peIdGarantia         IN  NUMBER)
IS
peIdPersona NUMBER;
peIdTipoTramite  NUMBER;
peIdTramiteIncompleto NUMBER;
psResult INTEGER;
psTxResult VARCHAR2(500);
begin

select id_persona
into peIdPersona
from rug_garantias
where id_garantia = peIdGarantia;

peIdTipoTramite := 13;

SP_ALTA_TRAMITE_INCOMPLETO (peIdPersona,peIdTipoTramite,peIdTramiteIncompleto,psResult,psTxResult);

end;
/

