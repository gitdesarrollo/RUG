create view V_USUARIO_FIRMA as
SELECT   TRI.ID_TRAMITE_TEMP,
            TRI.ID_PERSONA AS USUARIO_LOGIN,
            RSU.CVE_USUARIO AS CVE_USUARIO_LOGIN,
            RPF.NOMBRE_PERSONA AS NOMBRE_USUARIO_LOGIN,
            RPF.AP_PATERNO AS AP_PATERNO_LOGIN,
            RPF.AP_MATERNO AS AP_MATERNO_LOGIN,
            RRI.ID_PERSONA,
            DECODE (RRI.PER_JURIDICA,
                    'PF', (SELECT   NOMBRE_PERSONA
                             FROM   RUG_PERSONAS_FISICAS
                            WHERE   ID_PERSONA = RRI.ID_PERSONA),
                    NULL)
               AS NOMBRE_SUBUSUARIO,
            DECODE (RRI.PER_JURIDICA,
                    'PF', (SELECT   AP_PATERNO
                             FROM   RUG_PERSONAS_FISICAS
                            WHERE   ID_PERSONA = RRI.ID_PERSONA),
                    NULL)
               AS APELLIDO_PATERNO_SUBUSUARIO,
            DECODE (RRI.PER_JURIDICA,
                    'PF', (SELECT   AP_MATERNO
                             FROM   RUG_PERSONAS_FISICAS
                            WHERE   ID_PERSONA = RRI.ID_PERSONA),
                    NULL)
               AS APELLIDO_MATERNO_SUBUSUARIO,
            DECODE (
               RRI.PER_JURIDICA,
               'PF',
               (SELECT   RCN.DESC_NACIONALIDAD
                  FROM   RUG_PERSONAS RPP, RUG_CAT_NACIONALIDADES RCN
                 WHERE   RPP.ID_NACIONALIDAD = RCN.ID_NACIONALIDAD
                         AND RPP.ID_PERSONA = RRI.ID_PERSONA),
               NULL
            )
               AS NACIONALIDAD,
            DECODE (
               RRI.PER_JURIDICA,
               'PF',
               (SELECT   RSU.CVE_USUARIO
                  FROM   RUG_PERSONAS RPP, RUG_SECU_USUARIOS RSU
                 WHERE   RPP.ID_PERSONA = RSU.ID_PERSONA
                         AND RPP.ID_PERSONA = RRI.ID_PERSONA),
               NULL
            )
               AS CVE_USUARIO_SUB,
            DECODE (
               RRI.PER_JURIDICA,
               'PF',
               (SELECT   RGU.DESC_GRUPO
                  FROM   RUG_PERSONAS RPP,
                         RUG_SECU_USUARIOS RSU,
                         RUG_GRUPOS RGU
                 WHERE       RPP.ID_PERSONA = RSU.ID_PERSONA
                         AND RSU.ID_GRUPO = RGU.ID_GRUPO
                         AND RPP.ID_PERSONA = RRI.ID_PERSONA),
               NULL
            )
               AS GRUPO_USUARIO_SUB
     FROM   TRAMITES_RUG_INCOMP TRI,
            RUG_SECU_USUARIOS RSU,
            RUG_PERSONAS_FISICAS RPF,
            RUG_REL_TRAM_INC_PARTES RRI
    WHERE       TRI.ID_PERSONA = RPF.ID_PERSONA
            AND TRI.ID_PERSONA = RSU.ID_PERSONA
            AND TRI.ID_TRAMITE_TEMP = RRI.ID_TRAMITE_TEMP
            AND TRI.ID_TIPO_TRAMITE = 14
            AND TRI.ID_STATUS_TRAM = 5
/

