create PROCEDURE         SP_ALTA_GARANTIA 
(
    peIdPerson              IN RUG_PERSONAS.ID_PERSONA%TYPE, -- 1   IDENTIFICADOR DE LA PERSONA QUE  HACE LA INSCRIPCION
    peIdTramite             IN RUG_REL_TRAM_INC_GARAN.ID_TRAMITE_TEMP%TYPE,  -- 2  IDENTIFICADOR DEL TRAMITE ASOCIADO A LA GARANTIA
    peIdTipoGaran           IN RUG_GARANTIAS_PENDIENTES.ID_TIPO_GARANTIA  %TYPE, -- 3 IDENTIFICADOR DE TIPO DE GARANTIA
    peFechaCelebra          IN RUG_GARANTIAS_PENDIENTES.FECHA_INSCR%TYPE, -- 4  FECHA EN QUE SE REALIZA LA INSCRIPCION DE LA GARANTIA
    peMontoMaxGar           IN VARCHAR,-- 5 RUG_GARANTIAS_PENDIENTES.MONTO_MAXIMO_GARANTIZADO%TYPE,
    peTipoBien              IN VARCHAR2, -- 6
    peDescGarantia          IN CLOB,-- 7 RUG_GARANTIAS_PENDIENTES.DESC_GARANTIA%TYPE, -- DESCRIPCION DE LA GARANTIA
    peTerminosCondg         IN CLOB,-- 8 IN RUG_GARANTIAS_PENDIENTES.OTROS_TERMINOS_GARANTIA%TYPE, --  OTROS TERMINOS DEL CONTRATO
    peCambiosBienesMonto    IN RUG_GARANTIAS_PENDIENTES.CAMBIOS_BIENES_MONTO%TYPE, -- 9 CAMBIOS EN LOS BIENES O EN EL MONTO

    penNoGarantiaPreviaOt   IN RUG_GARANTIAS_PENDIENTES.NO_GARANTIA_PREVIA_OT%TYPE, -- 10 NO GARANTIAS PREVIAS PARA EL OTORGANTE

    peInstrumentoPub        IN RUG_GARANTIAS_PENDIENTES.INSTRUMENTO_PUBLICO%TYPE, -- 11 DATOS DESL INSTRUMENTO PUBLICO
    peTipoContrato          IN RUG_CONTRATO.TIPO_CONTRATO%TYPE, -- 12 TIPO DE CONTRATO
    peFechaIniOblig         IN RUG_CONTRATO.FECHA_INICIO%TYPE,  -- 13 FECHA DE INICIO DEL CONTRATO
    peFechaFinOblig         IN RUG_CONTRATO.FECHA_FIN%TYPE,   --  14 FECHA DE FIN DEL CONTRATO
    peOtrosTermC            IN CLOB, -- 15 IN RUG_CONTRATO.OTROS_TERMINOS_CONTRATO %TYPE, --  DESCRIPCION DE LOS OTROS TERMINOS DEL CONTRATO
    peIdMoneda              IN RUG_CAT_MONEDAS.ID_MONEDA%TYPE, --16
    peGarantiaPrioritaria   IN RUG_GARANTIAS_PENDIENTES.ES_PRIORITARIA%TYPE, --17
    peOtrosRegistros        IN RUG_GARANTIAS_PENDIENTES.OTROS_REGISTROS%TYPE,--18
    peTxtRegistos           IN RUG_GARANTIAS_PENDIENTES.TXT_REGISTROS%TYPE,--19
    peIdGarantia           OUT RUG_GARANTIAS_PENDIENTES.ID_GARANTIA_PEND%TYPE, --20
    psResult               OUT INTEGER,  -- 21
    psTxResult             OUT VARCHAR2  -- 22
)
IS

vIdTram                 RUG_REL_TRAM_INC_GARAN.ID_TRAMITE_TEMP%TYPE;
vIdGarantia             RUG_GARANTIAS_PENDIENTES.ID_GARANTIA_PEND%TYPE;
vIdContrato             RUG_CONTRATO.ID_CONTRATO%TYPE;
vIdRegistro             RUG_GARANTIAS_H.ID_REGISTRO%TYPE;
vIdRelacion             RUG_GARANTIAS_PENDIENTES.ID_RELACION%TYPE;
vIdPersona              RUG_GARANTIAS_PENDIENTES.ID_PERSONA%TYPE;
vlRelacion              NUMBER;
vlContrato              NUMBER;
vlIdTipoBien            NUMBER;
vlCountTipoGar          NUMBER;
vlCountMonedas          NUMBER;
vlCantidadTipobien      NUMBER;



fk_exception  EXCEPTION;
PRAGMA EXCEPTION_INIT (fk_exception, -02291);

fk_exception_bien  EXCEPTION;
PRAGMA EXCEPTION_INIT (fk_exception_bien, -00001);

Ex_Error  EXCEPTION;

vlTipoBien  INSTITUCIONAL.PKGSE_COMUN.T_PALABRAS;


BEGIN

      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GARANTIA', 'peIdPerson', CAST(peIdPerson AS VARCHAR2), 'IN');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GARANTIA', 'peIdTramite', CAST(peIdTramite AS VARCHAR2), 'IN');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GARANTIA', 'peIdTipoGaran', CAST(peIdTipoGaran AS VARCHAR2), 'IN');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GARANTIA', 'peFechaCelebra', CAST(peFechaCelebra AS VARCHAR2), 'IN');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GARANTIA', 'peMontoMaxGar', peMontoMaxGar , 'IN');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GARANTIA', 'peTipoBien', peTipoBien , 'IN');
      --REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GARANTIA', 'peDescGarantia', peDescGarantia, 'IN');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GARANTIA', 'peCambiosBienesMonto', peCambiosBienesMonto, 'IN');

      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GARANTIA', 'penNoGarantiaPreviaOt', penNoGarantiaPreviaOt, 'IN');

      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GARANTIA', 'peInstrumentoPub', peInstrumentoPub, 'IN');
      --REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GARANTIA', 'peTerminosCondg', peTerminosCondg, 'IN');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GARANTIA', 'peTipoContrato', peTipoContrato, 'IN');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GARANTIA', 'peFechaIniOblig', CAST(peFechaIniOblig AS VARCHAR2), 'IN');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GARANTIA', 'peFechaFinOblig', CAST(peFechaFinOblig AS VARCHAR2), 'IN');
      --REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GARANTIA', 'peOtrosTermC', peOtrosTermC, 'IN');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GARANTIA', 'peIdMoneda', peIdMoneda, 'IN');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GARANTIA', 'peGarantiaPrioritaria', peGarantiaPrioritaria, 'IN');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GARANTIA', 'peOtrosRegistros', peOtrosRegistros, 'IN');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GARANTIA', 'peTxtRegistos', peTxtRegistos, 'IN');


      BEGIN
        SELECT ID_TRAMITE_TEMP
        INTO vIdTram
        FROM TRAMITES_RUG_INCOMP
        WHERE ID_TRAMITE_TEMP = peIdTramite
        AND ID_TIPO_TRAMITE in (1,31)
        AND ID_STATUS_TRAM <> 3;
       Exception
         WHEN NO_DATA_FOUND THEN
            psResult := 16;
            RAISE Ex_Error;
      END;

      IF peIdTipoGaran >= 0 THEN

        SELECT COUNT(*)
        INTO vlCountTipoGar
        FROM RUG_CAT_TIPO_GARANTIA
        WHERE ID_TIPO_GARANTIA = peIdTipoGaran;

        IF vlCountTipoGar = 0 THEN
            psResult := 21;
            RAISE Ex_Error;

        END IF;

      ELSE
        psResult := 21;
        RAISE Ex_Error;

      END IF;

        IF peIdMoneda >= 0 THEN

        SELECT COUNT(*)
        INTO vlCountMonedas
        FROM RUG_CAT_MONEDAS
        WHERE ID_MONEDA = peIdMoneda;

        IF vlCountMonedas = 0 THEN
            psResult := 22;
            RAISE Ex_Error;

        END IF;

      ELSE
        psResult := 22;
        RAISE Ex_Error;

      END IF;


      IF vIdTram IS NOT NULL THEN

        vlCantidadTipobien := 0;

        vlRelacion := RUG.SEQ_BIENES.NEXTVAL;
        vIdGarantia := SEQ_GARANTIAS_TEMP.nextval;
        vlTipoBien := INSTITUCIONAL.PKGSE_COMUN.SPLITCADENA(peTipoBien,'|');
        vIdRegistro := SEQ_REG_GARANTIA_H.nextval;
        vlContrato := SEQ_CONTRATO.NEXTVAL;


        INSERT INTO RUG_GARANTIAS_PENDIENTES (ID_GARANTIA_PEND, ID_TIPO_GARANTIA, DESC_GARANTIA, ID_PERSONA, RELACION_BIEN,
                                   OTROS_TERMINOS_GARANTIA,FECHA_INSCR,MONTO_MAXIMO_GARANTIZADO, ID_ULTIMO_TRAMITE, GARANTIA_STATUS,
                                   CAMBIOS_BIENES_MONTO, INSTRUMENTO_PUBLICO, ID_MONEDA, ID_GARANTIA_MODIFICAR,NO_GARANTIA_PREVIA_OT,
                                   ES_PRIORITARIA,OTROS_REGISTROS,TXT_REGISTROS)
        VALUES (vIdGarantia, peIdTipoGaran, peDescGarantia, peIdPerson, vlRelacion, peTerminosCondg, peFechaCelebra, peMontoMaxGar, peIdTramite, 'AC',
                peCambiosBienesMonto, peInstrumentoPub,peIdMoneda, 0, penNoGarantiaPreviaOt, peGarantiaPrioritaria, peOtrosRegistros, peTxtRegistos);

--        for i in 1..vlTipoBien.count loop
--          BEGIN
--            vlIdTipoBien := vlTipoBien(i-1);
--
--            IF vlIdTipoBien IS NOT NULL THEN

                INSERT INTO RUG_REL_GAR_TIPO_BIEN
               VALUES(vIdGarantia, vlIdTipoBien, vlRelacion);
--
--            END IF;
--
--          EXCEPTION
--            WHEN fk_exception_bien THEN
--                BEGIN
--                    psResult := 81;
--                    RAISE Ex_Error;
--                END;
--             WHEN fk_exception THEN
--                BEGIN
--                    psResult := 61;
--                    RAISE Ex_Error;
--                END;
--
--          END;

--        END LOOP;
--

        FOR I IN (
                          SELECT  COLUMN_VALUE VALOR
                            FROM TABLE(
                                       SELECT SPLIT_TEM(peTipoBien,'|')
                                         FROM DUAL)
                           )
                    LOOP

                        BEGIN
                        --vlIdTipoBien := vlTipoBien(i-1);

                        IF I.VALOR IS NOT NULL THEN

                            INSERT INTO RUG_REL_GAR_TIPO_BIEN
                            VALUES(vIdGarantia, I.VALOR, vlRelacion);

                        END IF;

                      EXCEPTION
                        WHEN fk_exception_bien THEN
                            BEGIN
                                psResult := 81;
                                RAISE Ex_Error;
                            END;
                         WHEN fk_exception THEN
                            BEGIN
                                psResult := 61;
                                RAISE Ex_Error;
                            END;

                      END;

                    END LOOP;



        INSERT INTO RUG_REL_TRAM_INC_GARAN VALUES (vIdGarantia,peIdTramite, 'AC', SYSDATE);


        INSERT INTO RUG_CONTRATO (ID_CONTRATO, ID_GARANTIA_pend, CONTRATO_NUM, FECHA_INICIO, FECHA_FIN, OTROS_TERMINOS_CONTRATO,
                                  MONTO_LIMITE, OBSERVACIONES, TIPO_CONTRATO, ID_TRAMITE_TEMP, FECHA_REG, STATUS_REG, ID_USUARIO, CLASIF_CONTRATO)
        VALUES (vlContrato, vIdGarantia, NULL, peFechaIniOblig, peFechaFinOblig, peOtrosTermC, NULL, NULL, peTipoContrato, peIdTramite, SYSDATE,
                'AC', peIdPerson, 'OB');


        peIdGarantia := vIdGarantia;

        psResult := 0;

        psTxResult := 'ALTA EXITOSA';

        COMMIT;

        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GARANTIA', 'peIdGarantia', peIdGarantia, 'OUT');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GARANTIA', 'psResult', psResult, 'OUT');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GARANTIA', 'psTxResult', psTxResult, 'OUT');

      END IF;
EXCEPTION
WHEN Ex_Error THEN
      psTxResult := RUG.FN_MENSAJE_ERROR(psResult);
      ROLLBACK;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GARANTIA', 'peIdGarantia', peIdGarantia, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GARANTIA', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GARANTIA', 'psTxResult', psTxResult, 'OUT');

WHEN OTHERS THEN
      psResult  := 999;
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      ROLLBACK;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GARANTIA', 'peIdGarantia', peIdGarantia, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GARANTIA', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GARANTIA', 'psTxResult', psTxResult, 'OUT');
END SP_ALTA_GARANTIA;
/

