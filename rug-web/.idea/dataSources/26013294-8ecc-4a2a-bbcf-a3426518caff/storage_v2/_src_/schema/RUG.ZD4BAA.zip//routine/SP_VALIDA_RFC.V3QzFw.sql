create PROCEDURE         SP_VALIDA_RFC 
( 
    P_ID_NACIONALIDAD   IN RUG.RUG_PERSONAS.ID_NACIONALIDAD%TYPE,
    peRFC               IN VARCHAR,
    pePerJuridica       IN CHAR,
    psResult            OUT  INTEGER,   
    psTxResult          OUT  VARCHAR2       
)
IS
                                            
vlRegExprRFCPerFisica       VARCHAR(500) := '^[A-Z]{4}[0-9]{6}[A-Z0-9]{3}$';
vlRegExprRFCPerMoral        VARCHAR(500) := '^[A-Z]{3}[0-9]{6}[A-Z0-9]{3}$';
vlCountPerFisica            NUMBER;
vlCountPerMoral             NUMBER;
vlFecha                     DATE;

Ex_Error       EXCEPTION;

BEGIN
    psResult := 0;
    psTxResult := 'Validacion de RFC correcta';

    IF P_ID_NACIONALIDAD = 1 THEN


        IF pePerJuridica NOT IN ('PF', 'PM') THEN 
            psResult := 33;
            RAISE Ex_Error;
        END IF;

        IF  pePerJuridica = 'PF' THEN 
          SELECT REGEXP_COUNT(UPPER(peRFC), vlRegExprRFCPerFisica)
          INTO vlCountPerFisica
          FROM DUAL;

          IF vlCountPerFisica = 0 THEN
            psResult := 23;
            RAISE Ex_Error;
          END IF;

        ELSIF pePerJuridica = 'PM' THEN
          SELECT REGEXP_COUNT(UPPER(peRFC), vlRegExprRFCPerMoral)
          INTO vlCountPerFisica
          FROM DUAL;

          IF vlCountPerFisica = 0 THEN
            psResult := 24;
            RAISE Ex_Error;
          END IF;

        END IF;

    END IF;

EXCEPTION 
  WHEN Ex_Error THEN
      psTxResult := RUG.FN_MENSAJE_ERROR(psResult);

  WHEN OTHERS THEN
      psResult := 999; 
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
END SP_VALIDA_RFC;
/

