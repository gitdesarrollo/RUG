create PROCEDURE     REG_PARAM_PLS
( 
    peIdRegistro      IN   RUG_PARAM_PLS.ID_REGISTRO%TYPE,
    peObjeto          IN   RUG_PARAM_PLS.OBJETO%TYPE,
    peNomParametro    IN   RUG_PARAM_PLS.NOM_PARAMETRO%TYPE,
    peValor           IN   RUG_PARAM_PLS.VALOR%TYPE,
    peTipoParametro   IN   RUG_PARAM_PLS.TIPO_PARAMETRO%TYPE
)
IS
psTxResult VARCHAR2(2500);
PRAGMA AUTONOMOUS_TRANSACTION;

BEGIN

INSERT INTO RUG_PARAM_PLS
VALUES(peIdRegistro, peObjeto, peNomParametro, peValor, SYSDATE, 'AC', peTipoParametro);     

COMMIT;


  EXCEPTION 
   WHEN OTHERS THEN 
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      ROLLBACK;  
  ------dbms_output.put_line(psTxResult);
END REG_PARAM_PLS;
/

