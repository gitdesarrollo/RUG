create FUNCTION           FNVALIDAMODIFICAOTORGANTE (peIdGarantia     NUMBER,
                                                        peIdTramiteTemp  NUMBER                           
                          )
RETURN NUMBER

IS

vlParteGarantia     NUMBER;
vlParteTramite      NUMBER;
vlResultado         NUMBER;


BEGIN

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'FNValidaModificaOtorgante', 'peIdGarantia', peIdGarantia, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'FNValidaModificaOtorgante', 'peIdTramiteTemp', peIdTramiteTemp, 'IN');

   BEGIN

             /* 
        SELECT   DISTINCT ID_PERSONA
          INTO   vlParteGarantia        
          FROM   RUG_REL_GARANTIA_PARTES
         WHERE   ID_GARANTIA = peIdGarantia 
           AND   ID_PARTE = 1
           AND   STATUS_REG = 'AC';
           */
        SELECT   RPP.ID_PERSONA
          INTO   vlParteGarantia
          FROM         RUG_REL_GARANTIA_PARTES RPP
                    INNER JOIN
                       RUG_GARANTIAS RGG
                    ON RPP.ID_RELACION = RGG.ID_RELACION
                 INNER JOIN
                    RUG_PERSONAS REP
                 ON RPP.ID_PERSONA = REP.ID_PERSONA
         WHERE   RPP.ID_GARANTIA = peIdGarantia 
           AND   RPP.ID_PARTE = 1
           AND   RPP.STATUS_REG = 'AC';   


        SELECT   DISTINCT ID_PERSONA
          INTO   vlParteTramite
          FROM   RUG_REL_TRAM_INC_PARTES
         WHERE   ID_TRAMITE_TEMP = peIdTramiteTemp 
           AND   ID_PARTE = 1 
           AND   STATUS_REG = 'AC';


        IF(vlParteGarantia = vlParteTramite)THEN
            vlResultado := 0;
        ELSE
            vlResultado := 1;
        END IF;



   END;

   RETURN vlResultado;

END;
/

