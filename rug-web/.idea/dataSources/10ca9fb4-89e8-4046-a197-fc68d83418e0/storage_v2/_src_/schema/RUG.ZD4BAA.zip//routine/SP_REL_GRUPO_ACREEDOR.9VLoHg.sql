create PROCEDURE         SP_REL_GRUPO_ACREEDOR 
                            (
    peIdUsuarioHijo      IN NUMBER,
    peIdAcreedor         IN NUMBER,
    peIdUsuarioPadre     IN NUMBER,
    peIdGrupo            IN NUMBER,
    psResult            OUT INTEGER,
    psTxResult          OUT VARCHAR2
                            )
IS

vlIdTramiteIncomp NUMBER;
vlResult          NUMBER;
vlTxtResult       VARCHAR2(500);
vlContador        NUMBER;
vlGrupo           NUMBER;
vlIdPerfil        NUMBER;
vlCountGrupoAcr   NUMBER;

Ex_ErrParametro   EXCEPTION;

BEGIN

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_GRUPO_ACREEDOR', 'peIdUsuarioHijo', peIdUsuarioHijo, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_GRUPO_ACREEDOR', 'peIdAcreedor', peIdAcreedor, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_GRUPO_ACREEDOR', 'peIdUsuarioPadre', peIdUsuarioPadre, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_GRUPO_ACREEDOR', 'peIdGrupo', peIdGrupo, 'IN');


    IF peIdUsuarioHijo IS NULL OR peIdAcreedor IS NULL OR peIdUsuarioPadre IS NULL OR peIdGrupo IS NULL THEN
    psResult   :=19;               
    psTxResult:= 'No es posible insertar si algun valor es nulo, verifique';
    RAISE Ex_ErrParametro;
    END IF;


    SELECT ID_GRUPO, ID_PERFIL
      INTO vlGrupo, vlIdPerfil
      FROM V_USUARIO_SESION_RUG
     WHERE ID_PERSONA =  peIdUsuarioHijo;


    IF(vlIdPerfil != 4) THEN
        vlGrupo := peIdGrupo;                        
    END IF;


    SP_ALTA_TRAMITE_INCOMPLETO(peIdUsuarioPadre, 14, vlIdTramiteIncomp, vlResult, vlTxtResult);

    INSERT INTO RUG_REL_TRAM_INC_PARTES
    VALUES (vlIdTramiteIncomp, peIdAcreedor, 4, 'PF', 'AC', SYSDATE);

    INSERT INTO RUG_REL_TRAM_INC_PARTES
    VALUES (vlIdTramiteIncomp, peIdUsuarioHijo, 5, 'PF', 'AC', SYSDATE);

    SELECT COUNT(*) 
      INTO vlCountGrupoAcr
      FROM RUG_REL_GRUPO_ACREEDOR RRGA,
           REL_USU_ACREEDOR RUA
     WHERE RRGA.ID_ACREEDOR = RUA.ID_ACREEDOR
       AND RRGA.ID_SUB_USUARIO = RUA.ID_USUARIO
       AND RUA.ID_ACREEDOR = peIdAcreedor
       AND RUA.ID_USUARIO = peIdUsuarioHijo
       AND RRGA.ID_USUARIO = peIdUsuarioPadre; --- USUARIO DE SESION

    IF vlCountGrupoAcr = 1 THEN

        UPDATE RUG_REL_GRUPO_ACREEDOR
        SET STATUS_REG = 'AC',  ID_GRUPO = vlGrupo
        WHERE ID_ACREEDOR = peIdAcreedor 
          AND ID_SUB_USUARIO = peIdUsuarioHijo
          AND ID_USUARIO = peIdUsuarioPadre;

        UPDATE REL_USU_ACREEDOR
        SET STATUS_REG = 'AC'
        WHERE ID_USUARIO = peIdUsuarioHijo AND ID_ACREEDOR = peIdAcreedor;

        SELECT COUNT(*)
          INTO vlContador
          FROM RUG_SECU_USUARIOS
         WHERE ID_PERSONA = peIdUsuarioHijo
           AND ID_GRUPO = 2;

        IF vlContador = 0 THEN 

            UPDATE RUG_SECU_PERFILES_USUARIO
               SET CVE_PERFIL = 'ACREEDOR'
             WHERE ID_PERSONA = peIdUsuarioHijo;

        END IF;


    ELSIF vlCountGrupoAcr = 0 THEN

        INSERT INTO RUG_REL_GRUPO_ACREEDOR
        VALUES(SEQ_RUG_REL_PRIVILEGIO_ACREEDO.NEXTVAL, peIdAcreedor, 
               peIdUsuarioHijo, peIdUsuarioPadre, 'AC', SYSDATE, vlGrupo);


        SELECT COUNT(*) 
          INTO vlContador
          FROM REL_USU_ACREEDOR
         WHERE ID_USUARIO = peIdUsuarioHijo
           AND ID_ACREEDOR = peIdAcreedor;

        IF (vlContador = 0) THEN

            INSERT INTO REL_USU_ACREEDOR
            VALUES(peIdUsuarioHijo, peIdAcreedor, 'N', SYSDATE, 'AC');

        ELSE

            UPDATE REL_USU_ACREEDOR
               SET STATUS_REG = 'AC'
             WHERE ID_USUARIO = peIdUsuarioHijo
               AND ID_ACREEDOR = peIdAcreedor;


        END IF;

        SELECT COUNT(*)
          INTO vlContador
          FROM RUG_SECU_USUARIOS
         WHERE ID_PERSONA = peIdUsuarioHijo
           AND ID_GRUPO = 2;

        IF vlContador = 0 THEN 

            UPDATE RUG_SECU_PERFILES_USUARIO
               SET CVE_PERFIL = 'ACREEDOR'
             WHERE ID_PERSONA = peIdUsuarioHijo;

        END IF;


    END IF;


    SP_ALTA_BITACORA_TRAMITE2(vlIdTramiteIncomp, 5, 0, NULL, 'V', vlResult, vlTxtResult); 


    psResult   :=0;
    psTxResult :='Alta exitosa';


    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_GRUPO_ACREEDOR', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_GRUPO_ACREEDOR', 'psTxResult', psTxResult, 'OUT');

    EXCEPTION
  WHEN Ex_ErrParametro  THEN
      ROLLBACK;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_GRUPO_ACREEDOR', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_GRUPO_ACREEDOR', 'psTxResult', psTxResult, 'OUT');
      DBMS_OUTPUT.PUT_LINE(psTxResult);

   WHEN OTHERS THEN
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      ROLLBACK;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_GRUPO_ACREEDOR', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_GRUPO_ACREEDOR', 'psTxResult', psTxResult, 'OUT');
      DBMS_OUTPUT.PUT_LINE(psTxResult);

END;
/

