create PROCEDURE         SP_FIRMA_MASIVA 
                            (
                                peIdUsuario          IN  NUMBER,
                                peTramitesTemp       IN  CLOB,
                                peIdArchivo          IN  NUMBER,
                                peIdAcreedor         IN  NUMBER,
                                psIdTramFirmaMas    OUT  NUMBER,                               
                                psResult            OUT  INTEGER,   
                                psTxResult          OUT  VARCHAR2                             
                            )
IS

vlIdFirmaMasiva     NUMBER;
vlCantidad          NUMBER;
vlTramiteT          NUMBER;
vlIntResultado      NUMBER;
vlVarResultado      VARCHAR2(500);
vlResult            VARCHAR2(500);
vlIdTramiteTemp     NUMBER;
vlIdAux             NUMBER:=0;
vlPerJuridica       CHAR(2);

Ex_ErrParametro EXCEPTION;



CURSOR cursTramties(cpeTramties IN CLOB)  IS
    SELECT   COLUMN_VALUE AS tramite_temp
      FROM   TABLE (SPLIT_TEM (cpeTramties, '|'));


BEGIN

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FIRMA_MASIVA', 'peIdUsuario', peIdUsuario, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FIRMA_MASIVA', 'peIdArchivo', peIdArchivo, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FIRMA_MASIVA', 'peIdAcreedor', peIdAcreedor, 'IN');


    BEGIN
        vlCantidad := 0;

        SELECT COUNT(*)
          INTO vlCantidad
          FROM RUG_ARCHIVO
         WHERE ID_ARCHIVO = peIdArchivo;

        IF vlCantidad < 1 THEN
            vlIntResultado := 30;            
            RAISE Ex_ErrParametro;
        END IF;

    END;


    IF peTramitesTemp IS NULL OR peTramitesTemp = '' THEN

        vlIntResultado := 78;            
        RAISE Ex_ErrParametro;

    END IF;


    BEGIN

        vlCantidad := 0;

        SELECT COUNT(*)
          INTO vlCantidad
          FROM RUG_SECU_USUARIOS
         WHERE ID_PERSONA =  peIdUsuario
           AND SIT_USUARIO = 'AC';     

        IF vlCantidad < 1 THEN
            vlIntResultado := 2;
            RAISE Ex_ErrParametro;
        END IF;

    END;  


    SP_ALTA_TRAMITE_INCOMPLETO(peIdUsuario, 18, vlTramiteT, vlIntResultado, vlVarResultado);

    INSERT INTO RUG_PARAM_FIRMA(ID_TRAMITE_TEMP, CADENA_ORIGINAL_NO_FIRMADA, FECHA_REG)
    VALUES(vlTramiteT, peTramitesTemp, SYSDATE);
    COMMIT;


    IF(vlIntResultado = 0) THEN

        BEGIN


            BEGIN

                vlCantidad := 0;

                SELECT COUNT(*)
                  INTO vlCantidad
                  FROM TRAMITES_RUG_INCOMP
                 WHERE ID_TRAMITE_TEMP = vlTramiteT
                   AND ID_TIPO_TRAMITE = 18;

                SELECT PER_JURIDICA
                INTO vlPerJuridica
                FROM RUG.RUG_PERSONAS
                WHERE ID_PERSONA = peIdAcreedor;       

                INSERT INTO RUG.RUG_REL_TRAM_INC_PARTES
                VALUES(vlTramiteT, peIdAcreedor, 4, vlPerJuridica, 'AC', SYSDATE);

                IF vlCantidad < 1 THEN
                    vlIntResultado := 16;
                    RAISE Ex_ErrParametro;
                END IF;

            END;      


            OPEN cursTramties(peTramitesTemp); 

                   LOOP
                    FETCH  cursTramties INTO vlIdTramiteTemp; 
                     EXIT WHEN  cursTramties%NOTFOUND;   
                        IF(vlIdTramiteTemp <> vlIdAux) THEN                  

                            BEGIN
                                vlCantidad := 0;
                                SELECT COUNT(*)
                                  INTO vlCantidad
                                  FROM TRAMITES_RUG_INCOMP
                                 WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;

                                IF vlCantidad = 0 THEN
                                    vlIntResultado := 16;
                                    RAISE Ex_ErrParametro;
                                END IF;


                                vlCantidad := 0;

                                SELECT COUNT(*)
                                  INTO vlCantidad
                                  FROM RUG_FIRMA_MASIVA
                                 WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;

                                IF vlCantidad > 0 THEN


                                    ROLLBACK;


                                    DELETE RUG_BITAC_TRAMITES
                                    WHERE ID_TRAMITE_TEMP = vlTramiteT;

                                    DELETE TRAMITES_RUG_INCOMP
                                    WHERE ID_TRAMITE_TEMP = vlTramiteT;

                                    COMMIT;

                                    vlIntResultado := 71;
                                    RAISE Ex_ErrParametro;


                                END IF;


                            END;                            


                            INSERT INTO RUG_FIRMA_MASIVA(ID_FIRMA_MASIVA, ID_TRAMITE_TEMP, ID_ARCHIVO, FECHA_REG, STATUS_REG)
                            VALUES(vlTramiteT, vlIdTramiteTemp, peIdArchivo, SYSDATE, 'AC');

                            UPDATE TRAMITES_RUG_INCOMP
                               SET B_CARGA_MASIVA = 1
                             WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;

                            SP_ALTA_BITACORA_TRAMITE2(vlIdTramiteTemp, 5, 0, SYSDATE, 'V', vlIntResultado, vlVarResultado);

                        END IF;
                        vlIdAux := vlIdTramiteTemp;
                END LOOP;

            CLOSE cursTramties;                


            SP_ALTA_BITACORA_TRAMITE2(vlTramiteT, 5, 0, SYSDATE, 'V', vlIntResultado, vlVarResultado);

            IF (vlIntResultado != 0) THEN                
                RAISE Ex_ErrParametro;            
            END IF;

            psIdTramFirmaMas := vlTramiteT;
            psResult   :=0;        
            psTxResult :=RUG.FN_MENSAJE_ERROR(psResult);

             REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FIRMA_MASIVA', 'psIdTramFirmaMas', psIdTramFirmaMas, 'OUT');
             REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FIRMA_MASIVA', 'psResult', psResult, 'OUT');
             REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FIRMA_MASIVA', 'psTxResult', psTxResult, 'OUT');

             COMMIT;

        END;

    ELSE 
        psIdTramFirmaMas := 0;
        psResult := vlIntResultado;
        psTxResult := vlVarResultado; 
        RAISE Ex_ErrParametro;
    END IF;


    ROLLBACK;


EXCEPTION 
    WHEN Ex_ErrParametro  THEN
          psIdTramFirmaMas := 0;    
          psResult  := vlIntResultado;     
          psTxResult := RUG.FN_MENSAJE_ERROR(psResult);
          ROLLBACK;

        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FIRMA_MASIVA', 'psIdTramFirmaMas', psIdTramFirmaMas, 'OUT');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FIRMA_MASIVA', 'psResult', psResult, 'OUT');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FIRMA_MASIVA', 'psTxResult', psTxResult, 'OUT');    


    WHEN OTHERS THEN
        psResult  := 999;   
        psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
        ROLLBACK;
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FIRMA_MASIVA', 'psResult', psResult, 'OUT');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FIRMA_MASIVA', 'psTxResult', psTxResult, 'OUT');    


END SP_FIRMA_MASIVA;
/

