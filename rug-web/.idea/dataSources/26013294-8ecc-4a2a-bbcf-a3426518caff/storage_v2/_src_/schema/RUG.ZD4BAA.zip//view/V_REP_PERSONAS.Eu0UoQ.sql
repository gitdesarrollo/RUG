create view V_REP_PERSONAS as
SELECT  /*+index(f)*/ id_persona,
            nombre_persona || ' ' || ap_paterno || ' ' || ap_materno
               nombre_persona
        ,   NUM_SERIE        -- GGR 26.04.2013 MMESCN2013-80
     FROM   RUG.RUG_PERSONAS_FISICAS f
   UNION ALL
   SELECT  /*+index(m)*/ id_persona, razon_social nombre_persona
        ,   NULL -- GGR 26.04.2013 MMESCN2013-80
     FROM   RUG.RUG_PERSONAS_morales m
/

