create PROCEDURE         SP_CAMBIA_PASSWORD 
                        (                             
                             peNombre               IN VARCHAR2,
                             peApPaterno            IN VARCHAR2,
                             peApMaterno            IN VARCHAR2,
                             peCveUsuario           IN V_USUARIO_LOGIN_RUG.CVE_USUARIO%TYPE,
                             pePassAnterior         IN RUG_SECU_USUARIOS.PASSWORD%TYPE,                             
                             peNuevoPass            IN RUG_SECU_USUARIOS.PASSWORD%TYPE,
                             peRFC                  IN VARCHAR2,
                             P_NUM_SERIE            IN RUG_PERSONAS_FISICAS.NUM_SERIE%TYPE := NULL,
                             psResult              OUT NUMBER,
                             psTxResult            OUT VARCHAR2
                        )


AS

vlCount         NUMBER;
vlUltimaModif   NUMBER;
vlIdPersona_h   NUMBER;
vlIdDomicilio_h NUMBER; 
vlCantidad          NUMBER;
vlPassAnterior      VARCHAR(200);
vlIdError           NUMBER;
vlDescError         VARCHAR2 (255);
vlIdPersona         NUMBER;


--VARIABLES VALIDACION RFC
vlPsResultValRFC    NUMBER;
vlPsTxtResultValRFC VARCHAR(4000);
Ex_ErrRFC EXCEPTION;


Ex_ErrorProceso EXCEPTION;

BEGIN

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CAMBIA_PASSWORD', 'peCveUsuario', peCveUsuario, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CAMBIA_PASSWORD', 'pePassAnterior', pePassAnterior, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CAMBIA_PASSWORD', 'peNuevoPass', peNuevoPass, 'IN');

    vlIdError  := 99;
    vlDescError := 'Error en el proceso';

    SELECT COUNT(*)
      INTO vlCantidad
      FROM RUG_SECU_USUARIOS
     WHERE lower(CVE_USUARIO) = lower(peCveUsuario)
       AND SIT_USUARIO = 'AC';

    IF(vlCantidad <> 1) THEN
        vlIdError   := -1;
        vlDescError := 'El usuario no existe o esta inactivo';        
        RAISE Ex_ErrorProceso;
    END IF; 

     BEGIN
           RUG.SP_VALIDA_RFC(1, peRFC, 'PF', vlPsResultValRFC, vlPsTxtResultValRFC);
           IF vlPsResultValRFC <> 0 THEN
            RAISE Ex_ErrRFC;
           END IF;
        END;

    SELECT  PASSWORD, ID_PERSONA
      INTO  vlPassAnterior, vlIdPersona
      FROM  RUG_SECU_USUARIOS
     WHERE lower(CVE_USUARIO) = lower(peCveUsuario)
       AND SIT_USUARIO = 'AC';


    SELECT ID_DOMICILIO 
      INTO vlIdDomicilio_h
      FROM RUG_PERSONAS
     WHERE ID_PERSONA = vlIdPersona;


     SELECT COUNT(*) + 1
       INTO vlUltimaModif 
     FROM RUG_PERSONAS_H
     WHERE ID_PERSONA = vlIdPersona;


    dbms_output.put_line('Consulta de Pass en base: ' || vlPassAnterior || ' - ' || 'Consulta del pass nuev encriptado: ' || fndPswEncrypt(pePassAnterior));

    IF (pePassAnterior IS NOT NULL AND  peNuevoPass IS NOT NULL) THEN

        dbms_output.put_line('Los parametros de pass anterior y nuevo no son nulos');

        dbms_output.put_line('vlPassAnterior:  ' || vlPassAnterior);
        dbms_output.put_line('pePassAnterior param entrada: ' || fndPswEncrypt(pePassAnterior));


        IF(vlPassAnterior = LOWER(fndPswEncrypt(pePassAnterior))) THEN

        dbms_output.put_line('La contrase?a existente y la segun anterior  son iguales');
        dbms_output.put_line('vlPassAnterior:  ' || vlPassAnterior);
        dbms_output.put_line('pePassAnterior param entrada: ' || fndPswEncrypt(pePassAnterior));

            UPDATE RUG_SECU_USUARIOS
               SET PASSWORD = LOWER (fndPswEncrypt(peNuevoPass))
             WHERE lower(CVE_USUARIO) = lower(peCveUsuario)
               AND SIT_USUARIO = 'AC';


        ELSE
            dbms_output.put_line('La contrase?a existente y la segun anterior no son iguales');

            vlIdError:= -1;     
            vlDescError := 'Contrase?a anterior no valida';
            RAISE Ex_ErrorProceso;

            dbms_output.put_line('vlPassAnterior:  ' || vlPassAnterior);
            dbms_output.put_line('pePassAnterior param entrada: ' || fndPswEncrypt(pePassAnterior));

        END IF;

    END IF;



        UPDATE RUG_PERSONAS
           SET RFC = NVL(peRFC, RFC)
         WHERE ID_PERSONA = vlIdPersona;


        UPDATE RUG_PERSONAS_FISICAS
           SET NOMBRE_PERSONA = NVL( peNombre, NOMBRE_PERSONA), 
               AP_PATERNO = NVL( peApPaterno, AP_PATERNO), 
               AP_MATERNO = NVL( peApMaterno, AP_MATERNO)
             , NUM_SERIE = NVL( P_NUM_SERIE, NUM_SERIE)
         WHERE ID_PERSONA = vlIdPersona;


        IF P_NUM_SERIE IS NOT NULL THEN

            SP_REGISTRO_HIST_NUM_SERIE(vlIdPersona, P_NUM_SERIE, psResult, psTxResult);

        END IF;          

        psResult:= 0;     
        psTxResult := 'Actualizaci?xitosa';

        COMMIT;      



    dbms_output.put_line(peNuevoPass || ' - ' || fndPswEncrypt(peNuevoPass)); 


    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CAMBIA_PASSWORD', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CAMBIA_PASSWORD', 'psTxResult', psTxResult, 'OUT');    


EXCEPTION
WHEN  Ex_ErrRFC  THEN
      psResult := vlPsResultValRFC;
      psTxResult := vlPsTxtResultValRFC;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CAMBIA_PASSWORD', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CAMBIA_PASSWORD', 'psTxResult', psTxResult, 'OUT');
      ROLLBACK;
WHEN  Ex_ErrorProceso THEN    
      psResult:= vlIdError;     
      psTxResult := vlDescError; 
      rollback;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CAMBIA_PASSWORD', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CAMBIA_PASSWORD', 'psTxResult', psTxResult, 'OUT');    

END;
/

