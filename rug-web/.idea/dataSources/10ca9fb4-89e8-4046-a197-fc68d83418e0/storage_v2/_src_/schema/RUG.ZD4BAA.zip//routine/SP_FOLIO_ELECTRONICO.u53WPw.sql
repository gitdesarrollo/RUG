create PROCEDURE         SP_FOLIO_ELECTRONICO (
                            perIdPersona         IN NUMBER,
                            peFolioElectronico  OUT  VARCHAR2,
                            psResult            OUT  INTEGER,
                            psTxResult          OUT  VARCHAR2 
)
IS  

  V_CONTADOR            NUMBER;
  V_FOLIO               VARCHAR(15);

  EXCEP_GENERA_FOLIO    EXCEPTION;
  EXCEP_FIN_FOLIO       EXCEPTION;

  PRAGMA AUTONOMOUS_TRANSACTION;

BEGIN

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FOLIO_ELECTRONICO', 'perIdPersona', perIdPersona, 'IN');


    RUG.SP_GENERA_FOLIO_ELECTRONICO(V_FOLIO, psResult, psTxResult);

    IF psResult > 0 THEN

        RAISE EXCEP_GENERA_FOLIO;

    END IF;     

    SELECT COUNT(*)
      INTO V_CONTADOR
      FROM RUG.RUG_PERSONAS_FISICAS PF
     INNER JOIN RUG.RUG_PERSONAS P
        ON P.ID_PERSONA = PF.ID_PERSONA
     WHERE P.FOLIO_MERCANTIL = V_FOLIO;

    IF V_CONTADOR > 0 THEN

        RAISE EXCEP_FIN_FOLIO;
    END IF;

    dbms_output.put_line('peFolioElectronico ' || V_FOLIO);




    UPDATE RUG_PERSONAS 
       SET FOLIO_MERCANTIL = V_FOLIO 
     WHERE ID_PERSONA = perIdPersona;   


    COMMIT;

    peFolioElectronico := V_FOLIO;

    psResult:= 0;
    psTxResult := RUG.FN_MENSAJE_ERROR(psResult);


EXCEPTION
    WHEN EXCEP_GENERA_FOLIO THEN
        psResult  := 62;   
        psTxResult:= FN_MENSAJE_ERROR(62) || ' - ' || psTxResult;
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FOLIO_ELECTRONICO', 'peFolioElectronico', peFolioElectronico, 'OUT');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FOLIO_ELECTRONICO', 'psResult', psResult, 'OUT');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FOLIO_ELECTRONICO', 'psTxResult', psTxResult, 'OUT');

    WHEN EXCEP_FIN_FOLIO THEN
        psResult  := 128;   
        psTxResult:= REPLACE(FN_MENSAJE_ERROR(128), '@folio', V_FOLIO);
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FOLIO_ELECTRONICO', 'peFolioElectronico', peFolioElectronico, 'OUT');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FOLIO_ELECTRONICO', 'psResult', psResult, 'OUT');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FOLIO_ELECTRONICO', 'psTxResult', psTxResult, 'OUT');

    WHEN OTHERS THEN
        psResult  := 999;   
        psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);

        IF SQLCODE = -8177 THEN

            psResult  := 8177;

        END IF;

        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FOLIO_ELECTRONICO', 'peFolioElectronico', peFolioElectronico, 'OUT');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FOLIO_ELECTRONICO', 'psResult', psResult, 'OUT');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FOLIO_ELECTRONICO', 'psTxResult', psTxResult, 'OUT');
        ROLLBACK;
END;
/

