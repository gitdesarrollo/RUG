create PROCEDURE           SP_BAJAPARTE (peIdPersona                IN RUG_SECU_USUARIOS.ID_PERSONA%TYPE,         --PESONA K SeLOGUEA
                                             peIdTipoPersona            IN RUG_PARTES.ID_PARTE%TYPE,                           --ACREEDOR,DEUDOR,OTORGANTE
                                             peIdTramite                IN TRAMITES_RUG_INCOMP.ID_TIPO_TRAMITE%TYPE,--INSCRIPCION , ALTA ACREEDORES, AVISO PREVENTIVO
                                             psResult                   OUT INTEGER,   
                                             psTxResult                 OUT VARCHAR2)
IS

vlContadorPersona  NUMBER;
vlTipoPersonaJuridica VARCHAR2(5);

BEGIN

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BajaParte', 'peIdPersona', peIdPersona, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BajaParte', 'peIdTipoPersona', peIdTipoPersona, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BajaParte', 'peIdTramite', peIdTramite, 'IN');

    SELECT COUNT(*) 
    INTO vlContadorPersona
    FROM RUG_PERSONAS
    WHERE ID_PERSONA = peIdPersona;

    IF (vlContadorPersona > 0)THEN

        SELECT PER_JURIDICA 
        INTO vlTipoPersonaJuridica
        FROM RUG_PERSONAS
        WHERE ID_PERSONA = peIdPersona;


        IF (vlTipoPersonaJuridica = 'PF') THEN

            DELETE RUG_PERSONAS_FISICAS
            WHERE ID_PERSONA = peIdPersona;

        END IF;

         IF (vlTipoPersonaJuridica = 'PM') THEN

            DELETE RUG_PERSONAS_MORALES
            WHERE ID_PERSONA = peIdPersona;

        END IF;


        DELETE RUG_PERSONAS
        WHERE ID_PERSONA = peIdPersona;


        DELETE RUG_REL_TRAM_INC_PARTES
        WHERE ID_TRAMITE_TEMP = peIdTramite
        AND ID_PERSONA = peIdPersona
        AND ID_PARTE = peIdTipoPersona;


     COMMIT;
      psResult:=0;   
      psTxResult:= 'BAJA EXITOSA';--pkg_infz_inst_fenx.FunObtMsgErr(psResult);


    ELSE

      psResult:=1;   
      psTxResult:= 'NO SE ENCONTRO LA PERSONA A ELIMINAR';

    END IF;

   REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BajaParte', 'psResult', psResult, 'OUT');
   REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BajaParte', 'psTxResult', psTxResult, 'OUT');    


END;
/

