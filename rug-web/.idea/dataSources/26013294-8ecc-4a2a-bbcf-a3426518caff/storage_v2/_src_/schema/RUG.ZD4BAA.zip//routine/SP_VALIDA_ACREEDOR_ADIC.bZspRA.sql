create PROCEDURE           SP_VALIDA_ACREEDOR_ADIC 
                            (
                                peIdTramiteTemp        IN  NUMBER,
                                peIdGarantia           IN  NUMBER,
                                psResult            OUT  INTEGER,
                                psTxResult          OUT  VARCHAR2
                            )
IS


CURSOR cursPartesOri(cpeIdGarantia IN NUMBER) IS
SELECT RRG.ID_GARANTIA, RRG.ID_PERSONA, RRG.ID_PARTE
  FROM RUG_REL_GARANTIA_PARTES RRG,
       RUG_GARANTIAS RGA
  WHERE RRG.ID_RELACION = RGA.ID_RELACION
  AND RRG.ID_PARTE = 3
  AND RRG.ID_GARANTIA = cpeIdGarantia
  AND RRG.STATUS_REG = 'AC'
  ORDER BY RRG.ID_PERSONA;
cursPartes_RecOri cursPartesOri%ROWTYPE;

CURSOR cursPartesTemp(cpeIdTramiteTemp IN NUMBER) IS
SELECT TIP.ID_PERSONA, TIP.ID_PARTE, TIP.ID_TRAMITE_TEMP
FROM RUG_REL_TRAM_INC_PARTES TIP
WHERE TIP.ID_TRAMITE_TEMP = cpeIdTramiteTemp
AND TIP.ID_PARTE = 3
AND TIP.STATUS_REG = 'AC'
ORDER BY TIP.ID_PERSONA;
cursPartes_RecTemp cursPartesTemp%ROWTYPE;

Ex_PartesDiferentes  EXCEPTION;
vlPartesOriginal     NUMBER;
vlPartesTramite      NUMBER;


BEGIN

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_VALIDA_ACREEDOR_ADIC',
      'peIdTramiteTemp', peIdTramiteTemp, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_VALIDA_ACREEDOR_ADIC',
      'peIdGarantia', peIdGarantia, 'IN');


SELECT COUNT(*)
INTO vlPartesOriginal
FROM (SELECT RRG.ID_GARANTIA, RRG.ID_PERSONA, RRG.ID_PARTE
  FROM RUG_REL_GARANTIA_PARTES RRG,
       RUG_GARANTIAS RGA
  WHERE RRG.ID_RELACION = RGA.ID_RELACION
  AND RRG.ID_PARTE = 3
  AND RRG.ID_GARANTIA = peIdGarantia
  AND RRG.STATUS_REG = 'AC'
  ORDER BY RRG.ID_PERSONA);

SELECT COUNT(*)
INTO vlPartesTramite
FROM (SELECT TIP.ID_PERSONA, TIP.ID_PARTE, TIP.ID_TRAMITE_TEMP
FROM RUG_REL_TRAM_INC_PARTES TIP
WHERE TIP.ID_TRAMITE_TEMP = peIdTramiteTemp
AND TIP.ID_PARTE = 3
AND TIP.STATUS_REG = 'AC'
ORDER BY TIP.ID_PERSONA);


 BEGIN

    IF vlPartesOriginal = 0 AND vlPartesTramite = 0 THEN

       psResult   :=0;
       psTxResult :='Los acreedores adicionales NO han cambiado';

    ELSE

            OPEN cursPartesOri(peIdGarantia); OPEN cursPartesTemp(
      peIdTramiteTemp);
     IF vlPartesOriginal =  vlPartesTramite THEN
            LOOP
                FETCH cursPartesOri INTO cursPartes_RecOri;
                    LOOP
                        FETCH cursPartesTemp INTO cursPartes_RecTemp;
                        IF cursPartes_RecOri.ID_PERSONA = cursPartes_RecTemp.
      ID_PERSONA
      THEN

                            FETCH cursPartesOri INTO cursPartes_RecOri;

                        ELSE

                            RAISE Ex_PartesDiferentes;

                        END IF;
                        EXIT WHEN cursPartesTemp%NOTFOUND;
                    END LOOP;
               EXIT WHEN cursPartesOri%NOTFOUND;
            END LOOP;
        psResult   :=0;
        psTxResult :='Los acreedores adicionales NO han cambiado';
        DBMS_OUTPUT.PUT_LINE(psResult||psTxResult);
     ELSE

        psResult   :=1;
        psTxResult :='Los acreedores adicionales han cambiado';
        DBMS_OUTPUT.PUT_LINE(psResult||psTxResult);
     END IF;
     CLOSE cursPartesOri; CLOSE cursPartesTemp;

    END IF;

  END;

  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_VALIDA_ACREEDOR_ADIC',
      'psResult', psResult, 'OUT');
  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_VALIDA_ACREEDOR_ADIC',
      'psTxResult', psTxResult, 'OUT');


EXCEPTION
   WHEN Ex_PartesDiferentes THEN
     psResult   :=1;
     psTxResult :='Los acreedores adicionales han cambiado';
     REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_VALIDA_ACREEDOR_ADIC',
      'psResult', psResult, 'OUT');
     REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_VALIDA_ACREEDOR_ADIC',
      'psTxResult', psTxResult, 'OUT');
     DBMS_OUTPUT.PUT_LINE(psResult||psTxResult);
   WHEN OTHERS THEN
      psResult  := 999;
      psTxResult:= SUBSTR(SQLCODE||':'||SQLERRM,1,250);
      ROLLBACK;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_VALIDA_ACREEDOR_ADIC',
      'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_VALIDA_ACREEDOR_ADIC',
      'psTxResult', psTxResult, 'OUT');
      DBMS_OUTPUT.PUT_LINE(psTxResult);
END SP_VALIDA_ACREEDOR_ADIC;
/

