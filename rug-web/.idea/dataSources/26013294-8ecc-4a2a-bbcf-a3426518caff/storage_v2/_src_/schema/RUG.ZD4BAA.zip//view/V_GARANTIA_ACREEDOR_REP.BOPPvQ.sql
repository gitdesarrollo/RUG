create view V_GARANTIA_ACREEDOR_REP as
SELECT   A.ID_GARANTIA,
            a.ID_PERSONA,
            DECODE (
               b.PER_JURIDICA,
               'PF',
               (SELECT      NOMBRE_PERSONA
                         || ' '
                         || AP_PATERNO
                         || ' '
                         || AP_MATERNO
                  FROM   RUG_PERSONAS_FISICAS
                 WHERE   ID_PERSONA = a.ID_PERSONA),
               'PM',
               (SELECT   RAZON_SOCIAL
                  FROM   RUG_PERSONAS_MORALES
                 WHERE   ID_PERSONA = a.ID_PERSONA)
            )
               AS NOMBRE_ACREEDOR,
            b.PER_JURIDICA PERSONA_JURIDICA
     FROM   RUG_REL_GARANTIA_PARTES a, RUG_PERSONAS B, rug_garantias c
    WHERE       a.ID_PERSONA = b.ID_PERSONA
            AND C.ID_GARANTIA = A.ID_GARANTIA
            AND C.ID_RELACION = A.ID_RELACION
            AND a.id_parte = 4
            AND A.STATUS_REG = 'AC'
/

