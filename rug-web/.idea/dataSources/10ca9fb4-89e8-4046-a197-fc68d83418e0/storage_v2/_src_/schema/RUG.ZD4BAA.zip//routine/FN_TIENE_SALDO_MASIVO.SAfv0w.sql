create FUNCTION             FN_TIENE_SALDO_MASIVO (pUserId IN VARCHAR2, 
                                                              pTipoTramite IN NUMBER, 
                                                              pIdTramite IN NUMBER, 
                                                              pCantidad IN NUMBER) -- 0 NO_TIENE 1 TIENE
  RETURN NUMBER IS
  l_saldo       NUMBER;
  l_arancel     NUMBER;
  l_facturas    NUMBER;
  l_vehiculos   NUMBER;
  l_precio      NUMBER;  
  l_tipo_tramite_masivo NUMBER;
  v_usuario_maestro NUMBER;

  l_fecha_creacion TRAMITES.FECHA_CREACION%TYPE;
  vlDescMensajeError  VARCHAR(4000);
BEGIN

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'FN_TIENE_SALDO_MASIVO', 'pUserId', pUserId, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'FN_TIENE_SALDO_MASIVO', 'pTipoTramite', pTipoTramite, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'FN_TIENE_SALDO_MASIVO', 'pIdTramite', pIdTramite, 'IN');   
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'FN_TIENE_SALDO_MASIVO', 'pCantidad', pCantidad, 'IN');   

    BEGIN
        SELECT ID_TIPO_TRAMITE
        INTO l_tipo_tramite_masivo
        FROM TRAMITES_RUG_INCOMP
        WHERE ID_TRAMITE_TEMP = (
            SELECT ID_TRAMITE_TEMP
            FROM RUG_FIRMA_MASIVA
            WHERE ID_FIRMA_MASIVA = pIdTramite
            AND ROWNUM = 1);
    END;

    SELECT id_persona 
	INTO v_usuario_maestro
	FROM rug_secu_usuarios 
	WHERE cve_usuario = (
		SELECT NVL(cve_usuario_padre, cve_usuario) AS cve_usuario_padre 
		FROM rug_secu_usuarios 
		WHERE id_persona = pUserId
	);

    SELECT NVL(SUM(CREDITOS) - SUM(DEBITOS),0) AS SALDO
    INTO l_saldo
    FROM (
    	SELECT SUM(PRECIO) DEBITOS, 0 as CREDITOS 
		FROM RUG.V_TRAMITES_PAGADOS  
        WHERE ID_PERSONA_LOGIN IN (
			SELECT id_persona
			FROM rug_secu_usuarios 
			WHERE id_persona = pUserId
			UNION 
			SELECT id_persona
			FROM rug_secu_usuarios 
			WHERE cve_usuario_padre = ( 
				SELECT cve_usuario_padre 
				FROM rug_secu_usuarios 
				WHERE id_persona = pUserId 
			)
			UNION 
			SELECT id_persona 
			FROM rug_secu_usuarios 
			WHERE cve_usuario = ( 
				SELECT cve_usuario_padre 
				FROM rug_secu_usuarios 
				WHERE id_persona = pUserId
			)	
			UNION
			SELECT id_persona
			FROM rug_secu_usuarios
			WHERE cve_usuario_padre = (
				SELECT cve_usuario
				FROM rug_secu_usuarios  
				WHERE id_persona = pUserId
			)
		) 
        UNION
        SELECT 0 as DEBITOS, SUM(MONTO) CREDITOS 
        FROM RUG_UTIL.BOLETA
        WHERE IDENTIFICADOR = v_usuario_maestro AND USADA = 1
        GROUP BY IDENTIFICADOR
    ) M;

	-- traslados con pago (es tramite temporales)
        l_fecha_creacion := SYSDATE;

        -- validamos vigencia
        BEGIN
            SELECT
                precio
            INTO l_precio
            FROM RUG_CAT_TIPO_TRAM_PAGO
            WHERE id_tipo_tramite = l_tipo_tramite_masivo
            AND VIGENCIA_PRECIO > TO_TIMESTAMP(l_fecha_creacion);

            EXCEPTION WHEN no_data_found THEN
            BEGIN
                SELECT
                    precio
                INTO l_precio
                FROM RUG_CAT_TIPO_TRAM_PAGO
                WHERE id_tipo_tramite = l_tipo_tramite_masivo
                AND VIGENCIA_PRECIO IS NULL;

                EXCEPTION WHEN no_data_found THEN
                BEGIN
                    SELECT
                       PRECIO
                    INTO   l_precio
                    FROM
                           RUG_CAT_TIPO_TRAMITE
                    WHERE
                           ID_TIPO_TRAMITE = l_tipo_tramite_masivo
                    ;
                END;
            END;
        END;

    IF l_tipo_tramite_masivo = 1 THEN

        SELECT COUNT(*) AS FACTURAS
        INTO l_facturas
        FROM RUG_GARANTIAS_BIENES_PEND
        WHERE ID_TRAMITE_TEMP IN (
            SELECT ID_TRAMITE_TEMP
            FROM RUG_FIRMA_MASIVA
            WHERE ID_FIRMA_MASIVA = pIdTramite
        )
        AND TIPO_BIEN_ESPECIAL = 2;

        l_arancel := 20*l_facturas;

        IF(NVL(l_arancel,0) = 0) THEN
           l_arancel := l_precio;
        END IF;

    ELSE 
        l_arancel := l_precio;
    END IF;

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'FN_TIENE_SALDO_MASIVO', 'saldo', l_saldo - l_arancel, 'OUT');  

    IF (l_saldo - l_arancel) >=0 THEN
        RETURN 1;
    END IF;

    RETURN 0;
END;
/

