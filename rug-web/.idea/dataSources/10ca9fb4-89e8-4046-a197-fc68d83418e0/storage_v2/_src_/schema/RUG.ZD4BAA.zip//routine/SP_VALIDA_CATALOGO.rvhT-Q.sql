create PROCEDURE         SP_VALIDA_CATALOGO (
                                                    peIdCatalogo       IN    NUMBER,
                                                    peIdValor          IN    NUMBER,
                                                    psResult          OUT    NUMBER,   
                                                    psTxResult        OUT    VARCHAR2
                                              )
IS

vlCantidad      NUMBER;



BEGIN


    psResult := 0;


    IF peIdCatalogo = 5 THEN

        SELECT COUNT(*)
          INTO vlCantidad 
          FROM RUG_CAT_MONEDAS
         WHERE ID_MONEDA = peIdValor;

        IF  vlCantidad = 0 THEN 

            psResult := 22;

        END IF;

    ELSIF peIdCatalogo = 6 THEN

        SELECT COUNT(*)
          INTO vlCantidad
          FROM RUG_CAT_NACIONALIDADES
         WHERE ID_NACIONALIDAD = peIdValor;


        IF  vlCantidad = 0 THEN 

            psResult := 19;        

        END IF; 

    ELSIF peIdCatalogo = 10 THEN

        SELECT COUNT(*)
          INTO vlCantidad
          FROM RUG_CAT_TIPO_BIEN
         WHERE ID_TIPO_BIEN = peIdValor;

        IF  vlCantidad = 0 THEN 

            psResult := 61;

        END IF; 

    END IF;    

    psTxResult := RUG.FN_MENSAJE_ERROR(psResult);

END;
/

