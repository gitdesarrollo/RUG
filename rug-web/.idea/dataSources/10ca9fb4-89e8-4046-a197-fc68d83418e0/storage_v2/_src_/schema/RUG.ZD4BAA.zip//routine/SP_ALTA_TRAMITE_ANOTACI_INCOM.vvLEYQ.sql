create PROCEDURE         SP_ALTA_TRAMITE_ANOTACI_INCOM (
                                                           peIdPersona            IN     NUMBER, -- IDENTIFICADOR DE LA PESONA K SeLOGUEA
                                                           peIdTipoTramite        IN     NUMBER, --INSCRIPCION , ALTA ACREEDORES, AVISO PREVENTIVO
                                                           P_ID_TRAMITE_PADRE     IN     NUMBER, -- ANOTACION PADRE DEL TRAMITE        
                                                           peIdTramiteIncompleto  OUT    NUMBER, --IDENTIFICADOR UNICO DEL REGISTRO
                                                           psResult               OUT    INTEGER,   
                                                           psTxResult             OUT    VARCHAR2)
IS

    vlIdTramiteRugIncom  NUMBER;
    COPIA_INFO_EXC       EXCEPTION;

BEGIN

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Tramite_Anotaci_Incom', 'peIdPersona', CAST(peIdPersona AS VARCHAR2), 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Tramite_Anotaci_Incom', 'peIdTipoTramite', CAST(peIdTipoTramite AS VARCHAR2), 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Tramite_Anotaci_Incom', 'P_ID_TRAMITE_PADRE', CAST(P_ID_TRAMITE_PADRE AS VARCHAR2), 'IN');


    vlIdTramiteRugIncom:= SEQ_TRAM_INCOMP.NEXTVAL;


    INSERT INTO TRAMITES_RUG_INCOMP VALUES(vlIdTramiteRugIncom,peIdPersona,peIdTipoTramite,SYSDATE,NULL,'AC', 0, 0, SYSDATE,0);

    INSERT INTO RUG.RUG_REL_TRAM_INC_PARTES
    SELECT vlIdTramiteRugIncom
         , P.ID_PERSONA
         , P.ID_PARTE
         , P.PER_JURIDICA
         , P.STATUS_REG
         , P.FECHA_REG
      FROM RUG_REL_TRAM_PARTES P
     WHERE P.ID_TRAMITE = P_ID_TRAMITE_PADRE
       AND P.STATUS_REG = 'AC';


    INSERT INTO RUG_BITAC_TRAMITES VALUES(vlIdTramiteRugIncom, 0, SYSDATE, 0, peIdTipoTramite, SYSDATE, 'AC');

    SP_COPIA_INFO_ULTIM_ANOTACION(vlIdTramiteRugIncom, P_ID_TRAMITE_PADRE, psResult, psTxResult);

    IF psResult  > 0 THEN

        RAISE COPIA_INFO_EXC;

    END IF;

    COMMIT;

    peIdTramiteIncompleto:=vlIdTramiteRugIncom;
    psResult := 0;
    psTxResult := RUG.FN_MENSAJE_ERROR(psResult);


    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Tramite_Anotaci_Incom', 'peIdTramiteIncompleto', CAST(peIdTramiteIncompleto AS VARCHAR2), 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Tramite_Anotaci_Incom', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Tramite_Anotaci_Incom', 'psTxResult', psTxResult, 'OUT');    


    psResult:=0;   
    psTxResult:= 'ALTA EXITOSA';--pkg_infz_inst_fenx.FunObtMsgErr(psResult);

EXCEPTION
    WHEN COPIA_INFO_EXC THEN
        ROLLBACK;                
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Tramite_Anotaci_Incom', 'peIdTramiteIncompleto', CAST(peIdTramiteIncompleto AS VARCHAR2), 'OUT');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Tramite_Anotaci_Incom', 'psResult', psResult, 'OUT');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Tramite_Anotaci_Incom', 'psTxResult', psTxResult, 'OUT');

    WHEN OTHERS THEN
        psResult:=-1;   
        psTxResult:= 'ocurrio un error';
        dbms_output.put_line(psTxResult);
        psResult  := 999;   
        psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);  
        ROLLBACK;                
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Tramite_Anotaci_Incom', 'peIdTramiteIncompleto', CAST(peIdTramiteIncompleto AS VARCHAR2), 'OUT');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Tramite_Anotaci_Incom', 'psResult', psResult, 'OUT');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Tramite_Anotaci_Incom', 'psTxResult', psTxResult, 'OUT');    


END;
/

