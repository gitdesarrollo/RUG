create FUNCTION         SPLITCADENA (peCADENA IN VARCHAR2,
                      peCaracter IN varchar2)
 RETURN t_Palabras
 IS
  vlCadena     VARCHAR2(4000);
  vlPosEspacio integer;
  vlIndice     integer;
  vlPalabras   t_Palabras;
 BEGIN
    vlIndice     := 0;
    vlCadena     := peCADENA;
    vlPalabras(0):= vlCadena;
    vlPosEspacio:=INSTR(vlCadena, peCaracter);
    WHILE vlPosEspacio!= 0 LOOP
          vlPalabras(vlIndice) := TRIM(SUBSTR(vlCadena, 1, vlPosEspacio - 1));
          vlCadena := SUBSTR(vlCadena,  vlPosEspacio + 1);
          vlIndice := vlIndice + 1;
          vlPosEspacio := INSTR(vlCadena, peCaracter);
          IF (vlPosEspacio= 0) AND (LENGTH(vlCadena)<> 0) THEN
              vlPosEspacio:=LENGTH(vlCadena)+1;
          END IF;
    END LOOP;

    RETURN  vlPalabras;
 END SPLITCadena;
/

