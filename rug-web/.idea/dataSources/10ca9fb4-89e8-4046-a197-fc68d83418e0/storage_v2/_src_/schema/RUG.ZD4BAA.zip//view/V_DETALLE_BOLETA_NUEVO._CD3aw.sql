create view V_DETALLE_BOLETA_NUEVO
            (ID_TRAMITE, ID_GARANTIA, ID_TIPO_TRAMITE, TIPO_TRAMITE, TIPO_GARANTIA, FECHA_ACTO_CONVENIO,
             MONTO_MAXIMO_GARANTIZADO, OTROS_TERMINOS_GARANTIA, TIPOS_BIENES_GARANTIA, DESC_GARANTIA, VIGENCIA,
             ID_USUARIO, NOMBRE_USUARIO, CVE_USUARIO, CVE_PERFIL, FECHA_CREACION, CAMBIOS_BIENES_MONTO,
             INSTRUMENTO_PUBLICO, TIPO_CONTRATO, FECHA_INICIO_CONTRATO, FECHA_FIN_CONTRATO, OTROS_TERMINOS_CONTRATO,
             ANOTACION_JUEZ, TIPO_CONTRATO_FU, FECHA_INICIO_CONTRATO_FU, FECHA_FIN_CONTRATO_FU,
             OTROS_TERMINOS_CONTRATO_FU, CONTENIDO_RESOL, FOLIO_OTORGANTE, ID_TIPO_GARANTIA, NO_GARANTIA_PREVIA_OT,
             OBSERVACIONES)
as
SELECT   TRI.ID_TRAMITE,
            RGM.ID_GARANTIA,
            TRI.ID_TIPO_TRAMITE,
            RCTT.DESCRIPCION AS TIPO_TRAMITE,
            RTG.DESC_TIPO_GARANTIA AS TIPO_GARANTIA,
            TO_CHAR (HTP.FECHA_INSCR, 'DD/MM/YYYY') AS FECHA_ACTO_CONVENIO,
            '$ ' || HTP.MONTO_MAXIMO_GARANTIZADO || ' ' || RCM.DESC_MONEDA
               AS MONTO_MAXIMO_GARANTIZADO,
            HTP.OTROS_TERMINOS_GARANTIA,
            Tipo_Bien_Garantia_H (RGM.ID_GARANTIA, TRI.ID_TRAMITE, 0)
               AS TIPOS_BIENES_GARANTIA,
            HTP.DESC_GARANTIA,
            CAST (HTP.VIGENCIA AS VARCHAR2 (5)) AS VIGENCIA,
            USU.ID_USUARIO_FIRMO ID_USUARIO,
            USU.NOMBRE_USUARIO,
            USU.CVE_USUARIO,
            USU.CVE_PERFIL,
            TO_CHAR (HTT.FECHA_STATUS, 'DD/MM/YYYY - HH24:MI:SS')
            || DECODE ( (SELECT   COUNT ( * )
                           FROM   V_FIRMA_DOCTOS
                          WHERE   ID_TRAMITE_TEMP = TRI.ID_TRAMITE_TEMP),
                       1, ' * ZULU GMT / UTC',
                       ' * Hora central Mexico, D.F.')
               AS FECHA_CREACION,
            DECODE (
               (SELECT   CAMBIOS_BIENES_MONTO
                  FROM   RUG_GARANTIAS_H
                 WHERE   ID_GARANTIA = RGM.ID_GARANTIA
                         AND ID_ULTIMO_TRAMITE = TRI.ID_TRAMITE),
               'V',
               'Si',
               'No'
            ),           --DECODE (RGT.CAMBIOS_BIENES_MONTO, 'V', 'Si', 'No'),

            RGT.INSTRUMENTO_PUBLICO,
            RGC.TIPO_CONTRATO,
            TO_CHAR (RGC.FECHA_INICIO, 'DD/MM/YYYY') AS FECHA_INICIO_CONTRATO,
            TO_CHAR (RGC.FECHA_FIN, 'DD/MM/YYYY') AS FECHA_FIN_CONTRATO,
            RGC.OTROS_TERMINOS_CONTRATO,
            DECODE (TRI.ID_TIPO_TRAMITE,
                    2, (SELECT   AUTORIDAD_AUTORIZA
                          FROM   RUG_ANOTACIONES
                         WHERE   ID_TRAMITE_TEMP = TRI.ID_TRAMITE_TEMP),
                    NVL (RUA.ANOTACION_JUEZ, 'N/A'))
               AS ANOTACION_JUEZ,
            RZX.TIPO_CONTRATO AS TIPO_CONTRATO_FU,
            TO_CHAR (RZX.FECHA_INICIO, 'DD/MM/YYYY')
               AS FECHA_INICIO_CONTRATO_FU,
            TO_CHAR (RZX.FECHA_FIN, 'DD/MM/YYYY') AS FECHA_FIN_CONTRATO_FU,
            RZX.OTROS_TERMINOS_CONTRATO AS OTROS_TERMINOS_CONTRATO_FU,
            DECODE (TRI.ID_TIPO_TRAMITE,
                    2, (SELECT   ANOTACION
                          FROM   RUG_ANOTACIONES
                         WHERE   ID_TRAMITE_TEMP = TRI.ID_TRAMITE_TEMP),
                    'N/A'),
            REPLACE (FNCONCATOTORGANTE (TRI.ID_TRAMITE, 2), '<br>', ', ')
               FOLIO_OTORGANTE,
               RTG.ID_TIPO_GARANTIA,
               DECODE (
               (SELECT   RGT.NO_GARANTIA_PREVIA_OT
                  FROM   RUG_GARANTIAS_H
                 WHERE   ID_GARANTIA = RGM.ID_GARANTIA
                         AND ID_ULTIMO_TRAMITE = TRI.ID_TRAMITE),
               'V',
               'Si',
               'No'
            ),          --DECODE (RGT.NO_GARANTIA_PREVIA_OT, 'V', 'Si', 'No'),
            RGC.OBSERVACIONES
     FROM   RUG_CAT_MONEDAS RCM,
                                             TRAMITES TRI
                                          INNER JOIN
                                             RUG_CAT_TIPO_TRAMITE RCTT
                                          ON TRI.ID_TIPO_TRAMITE =
                                                RCTT.ID_TIPO_TRAMITE
                                       INNER JOIN
                                          RUG_REL_TRAM_GARAN RGM
                                       ON TRI.ID_TRAMITE = RGM.ID_TRAMITE
                                    INNER JOIN
                                       RUG_GARANTIAS RGT
                                    ON RGM.ID_GARANTIA = RGT.ID_GARANTIA
                                 INNER JOIN
                                    RUG_BITAC_TRAMITES RBB
                                 ON TRI.ID_TRAMITE_TEMP = RBB.ID_TRAMITE_TEMP
                              INNER JOIN
                                 (SELECT   B.ID_TRAMITE,
                                           A.ID_USUARIO_FIRMO,
                                           C.CVE_USUARIO,
                                           C.CVE_PERFIL,
                                           (   D.NOMBRE_PERSONA
                                            || ' '
                                            || D.AP_PATERNO
                                            || ' '
                                            || D.AP_MATERNO)
                                              AS NOMBRE_USUARIO
                                    FROM   V_FIRMA_DOCTOS A,
                                           TRAMITES B,
                                           RUG_SECU_PERFILES_USUARIO C,
                                           RUG_PERSONAS_FISICAS D
                                   WHERE   A.ID_TRAMITE_TEMP =
                                              B.ID_TRAMITE_TEMP
                                           AND B.ID_STATUS_TRAM = 3
                                           AND C.ID_PERSONA =
                                                 A.ID_USUARIO_FIRMO
                                           AND D.ID_PERSONA =
                                                 A.ID_USUARIO_FIRMO
                                  UNION ALL
                                  SELECT   B.ID_TRAMITE,
                                           NVL (A.ID_USUARIO_FIRMO,
                                                B.ID_PERSONA)
                                              ID_USUARIO_FIRMO,
                                           C.CVE_USUARIO,
                                           C.CVE_PERFIL,
                                           (   D.NOMBRE_PERSONA
                                            || ' '
                                            || D.AP_PATERNO
                                            || ' '
                                            || D.AP_MATERNO)
                                              AS NOMBRE_USUARIO
                                    FROM   DOCTOS_TRAM_FIRMADOS_RUG A,
                                           TRAMITES B,
                                           RUG_SECU_PERFILES_USUARIO C,
                                           RUG_PERSONAS_FISICAS D
                                   WHERE   A.ID_TRAMITE_TEMP =
                                              B.ID_TRAMITE_TEMP
                                           AND B.ID_STATUS_TRAM = 3
                                           AND D.ID_PERSONA =
                                                 NVL (A.ID_USUARIO_FIRMO,
                                                      B.ID_PERSONA)
                                           AND D.ID_PERSONA = C.ID_PERSONA)
                                 USU
                              ON TRI.ID_TRAMITE = USU.ID_TRAMITE
                           INNER JOIN
                              (SELECT   RGH.ID_GARANTIA,
                                        RGH.ID_ULTIMO_TRAMITE,
                                        RBB.FECHA_STATUS,
                                        RGH.ID_MONEDA
                                 FROM   RUG_GARANTIAS_H RGH,
                                        TRAMITES TR,
                                        RUG_BITAC_TRAMITES RBB
                                WHERE   RGH.ID_ULTIMO_TRAMITE = TR.ID_TRAMITE
                                        AND RBB.ID_TRAMITE_TEMP =
                                              TR.ID_TRAMITE_TEMP
                                        AND RBB.ID_STATUS = 3
                                        AND RBB.STATUS_REG = 'AC') HTT
                           ON RGM.ID_GARANTIA = HTT.ID_GARANTIA
                        INNER JOIN
                           (SELECT   RGH.ID_GARANTIA,
                                     RGH.ID_ULTIMO_TRAMITE,
                                     RGH.ID_TIPO_GARANTIA,
                                     RGH.FECHA_INSCR,
                                     RGH.MONTO_MAXIMO_GARANTIZADO,
                                     RGH.DESC_GARANTIA,
                                     RGH.OTROS_TERMINOS_GARANTIA,
                                     RGH.VIGENCIA,
                                     RGH.ID_MONEDA
                              FROM   RUG_GARANTIAS_H RGH, TRAMITES TR
                             WHERE   RGH.ID_ULTIMO_TRAMITE = TR.ID_TRAMITE
                                     AND TR.ID_TIPO_TRAMITE != 2
                            UNION ALL
                            SELECT   RGH.ID_GARANTIA,
                                     RGH.ID_ULTIMO_TRAMITE,
                                     RGH.ID_TIPO_GARANTIA,
                                     RGH.FECHA_INSCR,
                                     RGH.MONTO_MAXIMO_GARANTIZADO,
                                     RGH.DESC_GARANTIA,
                                     RGH.OTROS_TERMINOS_GARANTIA,
                                     RA.VIGENCIA_ANOTACION VIGENCIA,
                                     RGH.ID_MONEDA
                              FROM   RUG_GARANTIAS_H RGH,
                                     TRAMITES TR,
                                     RUG_ANOTACIONES RA
                             WHERE   RGH.ID_ULTIMO_TRAMITE = TR.ID_TRAMITE
                                     AND RA.ID_TRAMITE_TEMP =
                                           TR.ID_TRAMITE_TEMP
                                     AND RA.ID_GARANTIA = RGH.ID_GARANTIA
                                     AND TR.ID_TIPO_TRAMITE IN (2)) HTP
                        ON RGM.ID_GARANTIA = HTP.ID_GARANTIA
                     INNER JOIN
                        RUG_CAT_TIPO_GARANTIA RTG
                     ON HTP.ID_TIPO_GARANTIA = RTG.ID_TIPO_GARANTIA
                  LEFT JOIN
                     (SELECT   ID_TRAMITE_TEMP,
                               TIPO_CONTRATO,
                               FECHA_INICIO,
                               FECHA_FIN,
                               OTROS_TERMINOS_CONTRATO,
                               OBSERVACIONES
                        FROM   RUG_CONTRATO
                       WHERE   CLASIF_CONTRATO = 'OB') RGC
                  ON TRI.ID_TRAMITE_TEMP = RGC.ID_TRAMITE_TEMP
               LEFT JOIN
                  RUG_AUTORIDAD RUA
               ON TRI.ID_TRAMITE_TEMP = RUA.ID_TRAMITE_TEMP
            LEFT JOIN
               (SELECT   ID_TRAMITE_TEMP,
                         TIPO_CONTRATO,
                         FECHA_INICIO,
                         FECHA_FIN,
                         OTROS_TERMINOS_CONTRATO,
                         OBSERVACIONES
                  FROM   RUG_CONTRATO
                 WHERE   CLASIF_CONTRATO = 'FU') RZX
            ON TRI.ID_TRAMITE_TEMP = RZX.ID_TRAMITE_TEMP
    WHERE       RBB.ID_STATUS = 3
            AND RBB.STATUS_REG = 'AC'
            AND TRI.ID_TRAMITE = HTP.ID_ULTIMO_TRAMITE
            AND TRI.ID_TRAMITE = HTT.ID_ULTIMO_TRAMITE
            AND RCM.ID_MONEDA = HTP.ID_MONEDA
/

