create view V_USUARIO_ACREEDOR_REP2 as
SELECT   RUA.ID_USUARIO AS USUARIO_LOGIN,
            RUA.ID_ACREEDOR AS ID_PERSONA,
            RPP.PER_JURIDICA,
            DECODE (RPP.PER_JURIDICA,
                    'PF', (SELECT   NOMBRE_PERSONA
                             FROM   RUG_PERSONAS_FISICAS
                            WHERE   ID_PERSONA = RUA.ID_ACREEDOR),
                    NULL)
               AS NOMBRE_ACREEDOR,
            DECODE (RPP.PER_JURIDICA,
                    'PF', (SELECT   AP_PATERNO
                             FROM   RUG_PERSONAS_FISICAS
                            WHERE   ID_PERSONA = RUA.ID_ACREEDOR),
                    NULL)
               AS AP_PATERNO_ACREEDOR,
            DECODE (RPP.PER_JURIDICA,
                    'PF', (SELECT   AP_MATERNO
                             FROM   RUG_PERSONAS_FISICAS
                            WHERE   ID_PERSONA = RUA.ID_ACREEDOR),
                    NULL)
               AS AP_MATERNO_ACREEDOR,
            DECODE (RPP.PER_JURIDICA,
                    'PM', (SELECT   RAZON_SOCIAL
                             FROM   RUG_PERSONAS_MORALES
                            WHERE   ID_PERSONA = RUA.ID_ACREEDOR),
                    NULL)
               AS RAZON_SOCIAL_ACREEDOR,
            RPP.FOLIO_MERCANTIL,
            RPP.RFC,
            DECODE (RPP.PER_JURIDICA,
                    'PF', (SELECT   CURP
                             FROM   RUG_PERSONAS_FISICAS
                            WHERE   ID_PERSONA = RUA.ID_ACREEDOR),
                    NULL)
               AS CURP,
            RPP.ID_DOMICILIO,
            RDM.CALLE,
            '' CALLE_COLINDANTE_1,
            '' CALLE_COLINDANTE_2,
            RDM.LOCALIDAD,
            RDM.NUM_EXTERIOR,
            RDM.NUM_INTERIOR,
            RDM.ID_COLONIA,
            RDM.NOM_COLONIA DESC_COLONIA,
            RDM.ID_LOCALIDAD,
            RDM.LOCALIDAD DESC_LOCALIDAD,
            RDM.CVE_ESTADO,
            RDM.CVE_PAIS,
            RDM.CVE_DELEG_MUNICIP CVE_MUNICIP_DELEG,
            RDM.CODIGO_POSTAL
     FROM         REL_USU_ACREEDOR RUA
               INNER JOIN
                  RUG_PERSONAS RPP
               ON RPP.ID_PERSONA = RUA.ID_ACREEDOR
            LEFT JOIN
               V_DOMICILIOS RDM
            ON RPP.ID_DOMICILIO = RDM.ID_DOMICILIO
    WHERE   RUA.STATUS_REG = 'AC'
/

