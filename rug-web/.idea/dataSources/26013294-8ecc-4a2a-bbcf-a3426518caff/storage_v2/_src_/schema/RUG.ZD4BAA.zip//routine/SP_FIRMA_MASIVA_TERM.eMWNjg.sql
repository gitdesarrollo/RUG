create PROCEDURE         SP_FIRMA_MASIVA_TERM (
    peIdTramiteTemp             IN     DOCTOS_TRAM_FIRMADOS_RUG.ID_TRAMITE_TEMP%TYPE,
    --peCadenaOriginalNoFirmada   IN     DOCTOS_TRAM_FIRMADOS_RUG.CADENA_ORIG_NO_FIRMADA%TYPE,
    --peCadenaOriginalFirmada     IN     DOCTOS_TRAM_FIRMADOS_RUG.CADENA_ORIG_FIRMADA%TYPE,
    --peCadenaOrigFirmadaSE       IN     DOCTOS_TRAM_FIRMADOS_RUG.CADENA_ORIG_FIRMADA_SE%TYPE,
    --peTimeStampSE               IN     DOCTOS_TRAM_FIRMADOS_RUG.TIMESTAMP_SE%TYPE,
    peFechaCreacion             IN     VARCHAR2,
    peUsuarioFirmo              IN     DOCTOS_TRAM_FIRMADOS_RUG.ID_USUARIO_FIRMO%TYPE,
    peBcommit                   IN     VARCHAR2,
    psResult                   OUT     INTEGER,
    psTxResult                 OUT     VARCHAR2
)
IS

    vlResult  INTEGER;
    vlCountTramites  NUMBER;        
    vlTramiteFirmar  NUMBER;       
    vlTxResult VARCHAR2(4000);
    vlDestinatario VARCHAR2(500);

    Ex_Err_FirmaTramites  EXCEPTION;

BEGIN

   REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FIRMA_MASIVA_TERM', 'peIdTramiteTemp', peIdTramiteTemp, 'OUT');
   REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FIRMA_MASIVA_TERM', 'peFechaCreacion', peFechaCreacion, 'OUT');


  SELECT COUNT(*)
  INTO vlCountTramites
  FROM RUG.TRAMITES_RUG_INCOMP
  WHERE ID_TRAMITE_TEMP = peIdTramiteTemp
  AND ID_TIPO_TRAMITE = 18;

  IF vlCountTramites = 1 THEN

    UPDATE RUG.TRAMITES_RUG_INCOMP
    SET ID_STATUS_TRAM = 8
    WHERE ID_TRAMITE_TEMP = peIdTramiteTemp;

    UPDATE RUG.RUG_BITAC_TRAMITES
    SET STATUS_REG = 'IN'
    WHERE ID_TRAMITE_TEMP = peIdTramiteTemp;

    INSERT INTO RUG.RUG_BITAC_TRAMITES
    VALUES(peIdTramiteTemp, 8,  TO_DATE (peFechaCreacion, 'YYYY-MM-DD HH24:MI:SS'), 0, 18, SYSDATE, 'AC');

    /*

    INSERT INTO RUG.DOCTOS_TRAM_FIRMADOS_RUG    
    VALUES(peIdTramiteTemp, 
           peCadenaOriginalFirmada, 
           SYSDATE,  
           NULL, 
           peCadenaOriginalNoFirmada, 
           peCadenaOrigFirmadaSE, 
           peTimeStampSE, 
           'N',
           peUsuarioFirmo);
    */     
            SELECT DECODE(CVE_USUARIO,'jmedellin@verasfot.mx', 'fcampos@verasoft.mx', CVE_USUARIO)
            INTO vlDestinatario
            FROM RUG_SECU_USUARIOS
            WHERE ID_PERSONA = peUsuarioFirmo;


        --ENVIO DE CORREO DE CORREO DE COMIENZO
        --FALTA PARAMETRIZAR EL MENSAJE Y EL ASUNTO DEL MAIL

        INSERT INTO RUG_MAIL_POOL(ID_MAIL, ID_TIPO_CORREO, ID_MAIL_ACCOUNT, DESTINATARIO, ASUNTO, MENSAJE, ID_STATUS_MAIL)
        VALUES(SEQ_RUG_MAIL_POOL.NEXTVAL, 2, 2, vlDestinatario, 'Notificaci?UG: Tramites de Carga Masiva', 
        'Estimado: ' || vlDestinatario || ', Sus Tramites de Firma Masiva Con Tramite Temporal: ' || peIdTramiteTemp||' estan siendo firmados por nuestro sistema, recibir?n mail de confirmaci?uando estos se encuentren listos.', 1);           

  ELSIF vlCountTramites = 0 THEN

    RAISE Ex_Err_FirmaTramites;

  END IF;

   COMMIT;
   psResult := 0;
   psTxResult := 'Firma Masiva Registrada';

EXCEPTION
  WHEN Ex_Err_FirmaTramites  THEN

      psResult   :=2;               
      psTxResult:= 'El tramite no existe o no es de tipo firma masiva';
      ROLLBACK;
      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FIRMA_MASIVA_TERM', 'psResult', psResult, 'OUT');

      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FIRMA_MASIVA_TERM', 'psTxResult', psTxResult, 'OUT');

   WHEN OTHERS THEN

      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);

      ROLLBACK;

      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FIRMA_MASIVA_TERM', 'psResult', psResult, 'OUT');

      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FIRMA_MASIVA_TERM', 'psTxResult', psTxResult, 'OUT');

END;
/

