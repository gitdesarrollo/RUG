create view V_GARANTIA_PARTES_FIRMA as
SELECT   TTR.ID_TRAMITE_TEMP,
            RRF.NOMBRE_PERSONA AS NOMBRE,
            RRF.AP_PATERNO AS APELLIDO_PATERNO,
            RRF.AP_MATERNO AS APELLIDO_MATERNO,
            RRM.RAZON_SOCIAL,
            RGP.DESC_PARTE,
            RRP.PER_JURIDICA,
            RRP.FOLIO_MERCANTIL,
            RRP.RFC,
            RRF.CURP,
            RDM.CALLE,
            RDM.NUM_EXTERIOR,
            RDM.NUM_INTERIOR,
            VDM.DESC_COLONIA,
            VDM.NACIONALIDAD,
            VDM.LOCALIDAD,
            VDM.CODIGO_POSTAL,
            VDM.DESC_ESTADO,
            VDM.DESC_PAIS,
            VDM.DESC_MUNICIP_DELEG,
            VDM.ID_PAIS_RESIDENCIA,
            (SELECT   DESC_NACIONALIDAD
               FROM   RUG_CAT_NACIONALIDADES
              WHERE   ID_NACIONALIDAD = VDM.ID_PAIS_RESIDENCIA)
               PAIS_RESIDENCIA,
            VDM.UBICA_DOMICILIO_1,
            VDM.UBICA_DOMICILIO_2,
            VDM.POBLACION,
            VDM.ZONA_POSTAL
     FROM                        TRAMITES_RUG_INCOMP TTR
                              LEFT JOIN
                                 RUG_REL_TRAM_INC_PARTES RRI
                              ON TTR.ID_TRAMITE_TEMP = RRI.ID_TRAMITE_TEMP
                           INNER JOIN
                              RUG_PARTES RGP
                           ON RRI.ID_PARTE = RGP.ID_PARTE
                        LEFT JOIN
                           RUG_PERSONAS RRP
                        ON RRI.ID_PERSONA = RRP.ID_PERSONA
                     LEFT JOIN
                        RUG_PERSONAS_FISICAS RRF
                     ON RRI.ID_PERSONA = RRF.ID_PERSONA
                  LEFT JOIN
                     RUG_PERSONAS_MORALES RRM
                  ON RRI.ID_PERSONA = RRM.ID_PERSONA
               LEFT OUTER JOIN
                  RUG_DOMICILIOS RDM
               ON RRP.ID_DOMICILIO = RDM.ID_DOMICILIO
            LEFT OUTER JOIN
               V_DOMICILIO_PARTES VDM
            ON RRI.ID_PERSONA = VDM.ID_PERSONA
    WHERE   RRI.STATUS_REG = 'AC'
            AND TTR.ID_TRAMITE_TEMP NOT IN
                     (SELECT   ID_TRAMITE_TEMP
                        FROM   TRAMITES
                       WHERE   ID_TRAMITE_TEMP IS NOT NULL)
            AND TTR.ID_STATUS_TRAM = 5
/

