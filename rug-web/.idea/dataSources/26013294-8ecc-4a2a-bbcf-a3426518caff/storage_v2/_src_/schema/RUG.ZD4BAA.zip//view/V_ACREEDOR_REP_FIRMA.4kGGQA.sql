create view V_ACREEDOR_REP_FIRMA as
SELECT   TRI.ID_TRAMITE_TEMP,
            TRI.ID_PERSONA AS USUARIO_LOGIN,
            RSU.CVE_USUARIO AS CVE_USUARIO_LOGIN,
            RPF.NOMBRE_PERSONA AS NOMBRE_USUARIO_LOGIN,
            RPF.AP_PATERNO AS AP_PATERNO_LOGIN,
            RPF.AP_MATERNO AS AP_MATERNO_LOGIN,
            RRT.ID_PERSONA,
            RRT.PER_JURIDICA,
            DECODE (RRT.PER_JURIDICA,
                    'PF', (SELECT   NOMBRE_PERSONA
                             FROM   RUG_PERSONAS_FISICAS
                            WHERE   ID_PERSONA = RRT.ID_PERSONA),
                    NULL)
               AS NOMBRE_ACREEDOR,
            DECODE (RRT.PER_JURIDICA,
                    'PF', (SELECT   AP_PATERNO
                             FROM   RUG_PERSONAS_FISICAS
                            WHERE   ID_PERSONA = RRT.ID_PERSONA),
                    NULL)
               AS APELLIDO_PATERNO_ACREEDOR,
            DECODE (RRT.PER_JURIDICA,
                    'PF', (SELECT   AP_MATERNO
                             FROM   RUG_PERSONAS_FISICAS
                            WHERE   ID_PERSONA = RRT.ID_PERSONA),
                    NULL)
               AS APELLIDO_MATERNO_ACREEDOR,
            DECODE (RRT.PER_JURIDICA,
                    'PM', (SELECT   RAZON_SOCIAL
                             FROM   RUG_PERSONAS_MORALES
                            WHERE   ID_PERSONA = RRT.ID_PERSONA),
                    NULL)
               AS RAZON_SOCIAL_ACREEDOR,
            RPP.FOLIO_MERCANTIL,
            RPP.RFC,
            DECODE (RRT.PER_JURIDICA,
                    'PF', (SELECT   CURP
                             FROM   RUG_PERSONAS_FISICAS
                            WHERE   ID_PERSONA = RRT.ID_PERSONA),
                    NULL)
               AS CURP,
            VDM.ID_DOMICILIO,
            VDM.CALLE,
            '' CALLE_COLINDANTE_1,
            '' CALLE_COLINDANTE_2,
            '' AS LOCALIDAD,
            VDM.NUM_EXTERIOR,
            VDM.NUM_INTERIOR,
            VDM.ID_COLONIA,
            VDM.NOM_COLONIA AS DESC_COLONIA,
            VDM.ID_LOCALIDAD,
            VDM.LOCALIDAD AS DESC_LOCALIDAD,
            VDM.CVE_ESTADO,
            VDM.CVE_PAIS,
            VDM.CVE_DELEG_MUNICIP,
            VDM.CODIGO_POSTAL,
            RCC.ID_CONTRATO,
            RCC.FECHA_INICIO,
            RCC.FECHA_FIN,
            RCC.OTROS_TERMINOS_CONTRATO,
            RCC.TIPO_CONTRATO,
            '' AS FIRMADO,
            VDM.NOM_ESTADO AS DESC_ESTADO,
            VDM.NOM_PAIS AS DESC_PAIS,
            VDM.NOM_DELEG_MUNICIP AS DESC_MUNICIP_DELEG,
            VDM.ID_PAIS_RESIDENCIA,
            (SELECT   DESC_NACIONALIDAD
               FROM   RUG_CAT_NACIONALIDADES
              WHERE   ID_NACIONALIDAD = VDM.ID_PAIS_RESIDENCIA)
               PAIS_RESIDENCIA,
            VDM.UBICA_DOMICILIO_1,
            VDM.UBICA_DOMICILIO_2,
            VDM.POBLACION,
            VDM.ZONA_POSTAL,
            DECODE (TRI.ID_TIPO_TRAMITE,
                    12,
                    'V',
                    19,
                    'F')
               B_NUEVO
     FROM   TRAMITES_RUG_INCOMP TRI,
            RUG_PERSONAS_FISICAS RPF,
            RUG_SECU_USUARIOS RSU,
            RUG_REL_TRAM_INC_PARTES RRT,
            RUG_PERSONAS RPP,
            RUG_CONTRATO RCC,
            V_DOMICILIOS VDM
    WHERE       RPF.ID_PERSONA = TRI.ID_PERSONA
            AND TRI.ID_PERSONA = RSU.ID_PERSONA
            AND TRI.ID_TRAMITE_TEMP = RRT.ID_TRAMITE_TEMP
            AND RRT.ID_PERSONA = RPP.ID_PERSONA
            AND RPP.ID_DOMICILIO = VDM.ID_DOMICILIO
            AND TRI.ID_TRAMITE_TEMP = RCC.ID_TRAMITE_TEMP
            AND RPP.ID_DOMICILIO = VDM.ID_DOMICILIO
            AND TRI.ID_STATUS_TRAM = 5
            AND TRI.ID_TIPO_TRAMITE IN (12, 19)
/

