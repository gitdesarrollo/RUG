create view V_AVISO_PREVENTIVO_FIRMA as
SELECT   TRI.ID_TRAMITE_TEMP,
            AP.ID_PERSONA,
            DECODE (RPP.PER_JURIDICA,
                    'PF', (SELECT   NOMBRE_PERSONA
                             FROM   RUG_PERSONAS_FISICAS
                            WHERE   ID_PERSONA = AP.ID_PERSONA),
                    NULL)
               AS NOMBRE,
            DECODE (RPP.PER_JURIDICA,
                    'PF', (SELECT   AP_PATERNO
                             FROM   RUG_PERSONAS_FISICAS
                            WHERE   ID_PERSONA = AP.ID_PERSONA),
                    NULL)
               AS APELLIDO_PATERNO,
            DECODE (RPP.PER_JURIDICA,
                    'PF', (SELECT   AP_MATERNO
                             FROM   RUG_PERSONAS_FISICAS
                            WHERE   ID_PERSONA = AP.ID_PERSONA),
                    NULL)
               AS APELLIDO_MATERNO,
            DECODE (RPP.PER_JURIDICA,
                    'PM', (SELECT   RAZON_SOCIAL
                             FROM   RUG_PERSONAS_MORALES
                            WHERE   ID_PERSONA = AP.ID_PERSONA),
                    NULL)
               AS RAZON_SOCIAL,
            RCN.DESC_NACIONALIDAD AS NACIONALIDAD,
            RPP.PER_JURIDICA,
            RPP.FOLIO_MERCANTIL,
            RPP.RFC,
            DECODE (RPP.PER_JURIDICA,
                    'PF', (SELECT   CURP
                             FROM   RUG_PERSONAS_FISICAS
                            WHERE   ID_PERSONA = AP.ID_PERSONA),
                    NULL)
               AS CURP,
            AP.DESC_BIENES
     FROM   AVISOS_PREV AP,
            TRAMITES_RUG_INCOMP TRI,
            RUG_PERSONAS RPP,
            RUG_CAT_NACIONALIDADES RCN
    WHERE       TRI.ID_TRAMITE_TEMP = AP.ID_TRAMITE_TEMP
            AND RPP.ID_PERSONA = AP.ID_PERSONA
            AND RPP.ID_NACIONALIDAD = RCN.ID_NACIONALIDAD
            AND TRI.ID_STATUS_TRAM = 5
            AND TRI.ID_TRAMITE_TEMP NOT IN
                     (SELECT   ID_TRAMITE_TEMP FROM TRAMITES)
/

