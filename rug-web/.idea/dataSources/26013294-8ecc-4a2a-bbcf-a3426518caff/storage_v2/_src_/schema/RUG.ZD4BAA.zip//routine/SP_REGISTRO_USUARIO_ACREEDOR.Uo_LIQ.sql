create PROCEDURE         SP_REGISTRO_USUARIO_ACREEDOR 
(
      peIdAcreedor              IN NUMBER,
      peOperacion               IN VARCHAR2,
      peIdPersonaModif          IN NUMBER,  --IdPersonaModifcar solo Modif y Eliminacion 
      peNombre                  IN VARCHAR2, 
      peApellidoP               IN VARCHAR2, 
      peApellidoM               IN VARCHAR2, 
      peRFC                     IN VARCHAR, 
      peCuentaCorreo            IN VARCHAR2, --peCveUsuario              IN VARCHAR2,    
      pePassword                IN RUG_SECU_USUARIOS.PASSWORD%TYPE,
      peIdGrupo                 IN VARCHAR2,       
      peRepresentanteAcreedor   IN NUMBER,--peIdUsuario               IN NUMBER,
      psIdTramiteIncomp        OUT NUMBER,
      psIdPersonaAlta          OUT NUMBER,   
      psResult                 OUT NUMBER,
      psTxResult               OUT VARCHAR2
)
IS

  --Variables
vlIdPersona         INTEGER;
vlContador          NUMBER;     
vlContador1         NUMBER;
vlPerfil            VARCHAR2(50);
vlCveAcreedor       VARCHAR2(256);
vlTipoTramite       NUMBER;
vlFirmado           CHAR(2);
vlIdContrato        NUMBER;
vlNumPartes         NUMBER;
vlPerJuridica       CHAR(2);
vlIdTramite         NUMBER;
vlIdTramiteTemp     NUMBER;
vlIdUsuarioLogin    NUMBER;

vlResult            NUMBER;
vlTxtResult         VARCHAR2(500);
vlIdTramiteIncomp   NUMBER;
vlOperacion         CHAR(1);
vlCountCveUsuario   NUMBER;

Ex_ErrParametro     EXCEPTION;

--VARIABLES VALIDACION RFC
vlPsResultValRFC    NUMBER;
vlPsTxtResultValRFC VARCHAR(4000);
Ex_ErrRFC EXCEPTION;

CURSOR cursTramitesIncomp(cpeIdAcreedor IN NUMBER, cpeIdSubUsuario IN NUMBER) IS
SELECT ID_TRAMITE_TEMP, B_FIRMADO, ID_USUARIO_LOGIN
FROM V_USUARIOS_ACREEDORES
WHERE ID_ACREEDOR = cpeIdAcreedor 
AND ID_SUBUSUARIO = cpeIdSubUsuario;


BEGIN

BEGIN

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_ACREEDOR', 'peIdAcreedor', peIdAcreedor, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_ACREEDOR', 'peOperacion', peOperacion, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_ACREEDOR', 'peIdPersonaModif', peIdPersonaModif, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_ACREEDOR', 'peNombre', peNombre, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_ACREEDOR', 'peApellidoP', peApellidoP, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_ACREEDOR', 'peApellidoM', peApellidoM, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_ACREEDOR', 'peRFC', peRFC, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_ACREEDOR', 'peCuentaCorreo', peCuentaCorreo, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_ACREEDOR', 'peIdGrupo', peIdGrupo, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_ACREEDOR', 'peRepresentanteAcreedor', peRepresentanteAcreedor, 'IN');

END;

    vlFirmado := NULL;


    RUG.SP_VALIDA_RFC(1, peRFC, 'PF', vlPsResultValRFC, vlPsTxtResultValRFC);
    IF vlPsResultValRFC <> 0 THEN
        RAISE Ex_ErrRFC;
    END IF;



    vlOperacion:= peOperacion;

    IF vlOperacion IN ('I','U') THEN
        BEGIN

             IF vlOperacion = 'I' THEN

                SELECT COUNT(CVE_USUARIO)
                INTO vlCountCveUsuario
                FROM RUG_SECU_USUARIOS
                WHERE lower(CVE_USUARIO) = lower(peCuentaCorreo)
                AND SIT_USUARIO = 'AC';

                 IF vlCountCveUsuario > 0 THEN
                    psResult := 1;
                    SELECT DESC_CODIGO
                    INTO psTxResult
                    FROM RUG_CAT_MENSAJES_ERRORES
                    WHERE ID_CODIGO = psResult;            
                RAISE Ex_ErrParametro;
                END IF;

             END IF;

             SP_ALTA_TRAMITE_INCOMPLETO(peRepresentanteAcreedor, 14, vlIdTramiteIncomp, vlResult, vlTxtResult);

            dbms_output.put_line(101); 

              IF (peIdGrupo IS NULL) THEN
                    BEGIN

                        psResult   := 1;
                        psTxResult :='Debe indicar el grupo';
                        RAISE Ex_ErrParametro;  

                    END;
              END IF;


           vlCveAcreedor := NULL;

               begin
                    --CVE_ACREEDOR = CUENTA DE CORREO
                    SELECT CVE_ACREEDOR
                      INTO vlCveAcreedor
                      FROM RUG_SECU_USUARIOS
                     WHERE ID_PERSONA = peRepresentanteAcreedor;
                     EXCEPTION
                        WHEN OTHERS THEN
                            vlCveAcreedor := NULL;
               end;                   

            vlIdPersona:= SEQ_RUG_ID_PERSONA.NEXTVAL;

            --ALTA DE LOS DATOS GENERALES DEL USUARIO QUE SE VA A ASOCIAR
            INSERT INTO RUG_PERSONAS (ID_PERSONA, RFC, PER_JURIDICA, FH_REGISTRO, PROCEDENCIA, SIT_PERSONA, REG_TERMINADO)
            VALUES   (vlIdPersona, peRFC, 'PF', TRUNC(SYSDATE), 'NAL', 'AC', 'Y');


            INSERT INTO RUG_PERSONAS_FISICAS (ID_PERSONA, NOMBRE_PERSONA, AP_PATERNO, AP_MATERNO)
            VALUES   (vlIdPersona, peNombre, peApellidoP, peApellidoM);

            INSERT INTO RUG_SECU_USUARIOS (CVE_INSTITUCION, CVE_USUARIO, ID_PERSONA, PASSWORD, F_ASIGNA_PSW,
                                           FH_REGISTRO, SIT_USUARIO, CVE_USUARIO_PADRE, CVE_ACREEDOR, ID_GRUPO, B_FIRMADO)
            VALUES ('SE', lower(peCuentaCorreo), vlIdPersona, LOWER (FNDPSWENCRYPT(pePassword)), SYSDATE, SYSDATE, 
                    'IN', vlCveAcreedor, vlCveAcreedor, 2, 'F');

            INSERT INTO RUG_SECU_PERFILES_USUARIO (CVE_INSTITUCION, CVE_USUARIO, CVE_PERFIL, CVE_APLICACION, ID_PERSONA, B_BLOQUEADO)
            VALUES   ('SE', lower(peCuentaCorreo), 'ACREEDOR',  'RugPortal', vlIdPersona, 'F');

            INSERT INTO REL_USU_ACREEDOR
            VALUES(vlIdPersona, peIdAcreedor, 'N', SYSDATE, 'AC'); 

                 vlIdContrato := SEQ_CONTRATO.NEXTVAL;

                INSERT INTO RUG_REL_TRAM_INC_PARTES
                VALUES (vlIdTramiteIncomp, vlIdPersona, 5, 'PF', 'AC', SYSDATE);

                SELECT   PER_JURIDICA
                  INTO   vlPerJuridica
                  FROM   RUG_PERSONAS
                 WHERE   ID_PERSONA = peIdAcreedor; 

                INSERT INTO RUG_REL_TRAM_INC_PARTES
                VALUES (vlIdTramiteIncomp, peIdAcreedor, 4, vlPerJuridica, 'AC', SYSDATE);


            INSERT INTO RUG_REL_GRUPO_ACREEDOR
            VALUES(SEQ_RUG_REL_PRIVILEGIO_ACREEDO.NEXTVAL, peIdAcreedor, vlIdPersona, peRepresentanteAcreedor, 'AC', SYSDATE, peIdGrupo);


            SP_ALTA_BITACORA_TRAMITE2(vlIdTramiteIncomp, 5, 0, NULL, 'V', vlResult, vlTxtResult);


              IF(peOperacion = 'U') THEN
               BEGIN

                   IF peIdPersonaModif IS NULL THEN
                    psResult   := 18;
                    psTxResult :='El id de usuario a modificar no puede ser nulo';
                    RAISE Ex_ErrParametro;
                   END IF;    

               Dbms_output.put_line(10); 

                    UPDATE RUG_PERSONAS 
                    SET SIT_PERSONA = 'IN'
                    WHERE ID_PERSONA = peIdPersonaModif;

               Dbms_output.put_line(11); 
                    UPDATE RUG_SECU_USUARIOS
                    SET SIT_USUARIO = 'IN'
                    WHERE ID_PERSONA = peIdPersonaModif;

                Dbms_output.put_line(12);             
                    UPDATE RUG_REL_GRUPO_ACREEDOR
                    SET STATUS_REG = 'IN'
                    WHERE ID_SUB_USUARIO = peIdPersonaModif AND ID_ACREEDOR = peIdAcreedor;

                Dbms_output.put_line(13);                                          

               END;
            END IF;

            COMMIT;

            psIdTramiteIncomp := vlIdTramiteIncomp;
            psIdPersonaAlta := vlIdPersona;
            psResult  := 0;
            psTxResult := 'Alta Exitosa';                       
        END;
    END IF;


    IF(peOperacion = 'D') THEN
         IF peIdPersonaModif IS NULL THEN
            psResult   := 18;
            psTxResult :='El id de usuario a modificar no puede ser nulo';
            RAISE Ex_ErrParametro;
         END IF;

        BEGIN        
            OPEN cursTramitesIncomp( peIdAcreedor, peIdPersonaModif);
                LOOP
                    FETCH cursTramitesIncomp INTO vlIdTramiteTemp, vlFirmado, vlIdUsuarioLogin;
                    EXIT WHEN cursTramitesIncomp%NOTFOUND;

                    IF vlFirmado = 'Y' THEN
                        UPDATE RUG.REL_USU_ACREEDOR
                        SET STATUS_REG = 'IN'
                        WHERE ID_USUARIO = peIdPersonaModif
                        AND ID_ACREEDOR = peIdAcreedor;

                        UPDATE RUG.RUG_REL_GRUPO_ACREEDOR
                        SET STATUS_REG = 'IN'
                        WHERE ID_ACREEDOR = peIdAcreedor
                        AND ID_SUB_USUARIO = peIdPersonaModif
                        AND ID_USUARIO = vlIdUsuarioLogin;

                        SELECT COUNT(*)
                          INTO vlContador
                          FROM REL_USU_ACREEDOR
                         WHERE ID_USUARIO = peIdPersonaModif
                           AND STATUS_REG = 'AC';


                        IF vlContador = 0 THEN 

                            SELECT COUNT(*)
                              INTO vlContador
                              FROM RUG_SECU_USUARIOS
                             WHERE ID_PERSONA = peIdPersonaModif
                               AND ID_GRUPO = 2;

                            IF vlContador = 0 THEN 

                                UPDATE RUG_SECU_PERFILES_USUARIO
                                   SET CVE_PERFIL = 'CIUDADANO'
                                 WHERE ID_PERSONA = peIdPersonaModif;

                                UPDATE RUG_SECU_USUARIOS
                                   SET B_FIRMADO = 'F'
                                 WHERE ID_PERSONA = peIdPersonaModif;


                            END IF;

                        END IF;


                    ELSIF vlFirmado = 'N' THEN
                        IF  vlIdTramiteTemp IS NOT NULL THEN  

                        DELETE RUG.RUG_REL_TRAM_INC_PARTES
                        WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;

                        DELETE RUG.RUG_BITAC_TRAMITES
                        WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;

                        DELETE RUG.TRAMITES_RUG_INCOMP
                        WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;

                        UPDATE RUG.REL_USU_ACREEDOR
                        SET STATUS_REG = 'IN'
                        WHERE ID_USUARIO = peIdPersonaModif
                        AND ID_ACREEDOR = peIdAcreedor;


                        SELECT COUNT(*)
                          INTO vlContador
                          FROM REL_USU_ACREEDOR
                         WHERE ID_USUARIO = peIdPersonaModif
                           AND STATUS_REG = 'AC';


                        IF vlContador = 0 THEN

                            SELECT COUNT(*)
                              INTO vlContador
                              FROM RUG_SECU_USUARIOS
                             WHERE ID_PERSONA = peIdPersonaModif
                               AND ID_GRUPO = 2;

                            IF vlContador = 1 THEN 

                                UPDATE RUG_SECU_PERFILES_USUARIO
                                   SET CVE_PERFIL = 'CIUDADANO'
                                 WHERE ID_PERSONA = peIdPersonaModif;

                                UPDATE RUG_SECU_USUARIOS
                                   SET B_FIRMADO = 'F'
                                 WHERE ID_PERSONA = peIdPersonaModif;

                            END IF;

                        END IF;

                    END IF;  
                    END IF;

                END LOOP;  
            CLOSE cursTramitesIncomp;

        EXCEPTION 
            WHEN NO_DATA_FOUND THEN
            DBMS_OUTPUT.PUT_LINE('No hay datos para los valores de acreedor y sub-usuario proporcionados');
        END;

        UPDATE RUG_REL_TRAM_PARTES
           SET STATUS_REG = 'IN' 
         WHERE ID_TRAMITE IN (         
                              SELECT NVL(REL1.ID_TRAMITE, 0)
                              --INTO vlIdTramite
                              FROM REL_USU_ACREEDOR RUA,
                                   (SELECT * FROM RUG_REL_TRAM_PARTES
                                    WHERE ID_PARTE = 4) REL1,
                                   (SELECT * FROM RUG_REL_TRAM_PARTES
                                    WHERE ID_PARTE = 5) REL2
                             WHERE REL1.ID_PERSONA = RUA.ID_ACREEDOR
                               AND REL2.ID_PERSONA = RUA.ID_USUARIO
                               AND REL1.ID_TRAMITE = REL2.ID_TRAMITE
                               AND REL1.ID_PERSONA = peIdAcreedor
                               AND REL2.ID_PERSONA = peIdPersonaModif
                               AND RUA.STATUS_REG = 'AC'         
                             );


        UPDATE RUG_REL_TRAM_INC_PARTES
           SET STATUS_REG = 'IN' 
         WHERE ID_TRAMITE_TEMP IN (
                                        SELECT   A.ID_TRAMITE_TEMP 
                                          --INTO   vlIdTramiteTemp        
                                          FROM   RUG_REL_TRAM_INC_PARTES A, 
                                                 RUG_REL_TRAM_INC_PARTES B
                                         WHERE   A.ID_TRAMITE_TEMP = B.ID_TRAMITE_TEMP         
                                           AND A.ID_PARTE = 4
                                           AND A.ID_PERSONA = peIdAcreedor
                                           AND B.ID_PARTE = 5
                                           AND B.ID_PERSONA = peIdPersonaModif
                                           --AND A.ID_TRAMITE_TEMP NOT IN (SELECT ID_TRAMITE_TEMP FROM TRAMITES)         
                                  );


        UPDATE RUG_REL_GRUPO_ACREEDOR
           SET STATUS_REG = 'IN'
         WHERE ID_SUB_USUARIO = peIdPersonaModif 
           AND ID_ACREEDOR = peIdAcreedor;


        UPDATE REL_USU_ACREEDOR
           SET STATUS_REG = 'IN', B_FIRMADO = 'N' 
         WHERE ID_USUARIO = peIdPersonaModif 
           AND ID_ACREEDOR = peIdAcreedor;


        INSERT INTO RUG.RUG_TRAMITES_REASIGNADOS(ID_ACREEDOR, ID_TRAMITE_TEMP, STATUS_REG, FECHA_REG)
        SELECT A.ID_ACREEDOR, A.ID_TRAMITE_TEMP, 'AC', SYSDATE
        FROM RUG.V_TRAMITES_PENDIENTES A
        WHERE A.ID_PERSONA_LOGIN = peIdPersonaModif
        AND A.ID_TRAMITE_TEMP NOT IN (SELECT ID_TRAMITE_TEMP FROM RUG_TRAMITES_REASIGNADOS WHERE ID_ACREEDOR = A.ID_ACREEDOR)
        AND A.ID_ACREEDOR = peIdAcreedor;


        INSERT INTO RUG.RUG_TRAMITES_REASIGNADOS(ID_ACREEDOR, ID_TRAMITE_TEMP, STATUS_REG, FECHA_REG)
        SELECT A.ID_ACREEDOR, A.ID_TRAMITE_TEMP, 'AC', SYSDATE
        FROM RUG.V_TRAMITES_TERMINADOS A
        WHERE A.ID_PERSONA_LOGIN = peIdPersonaModif
        AND A.ID_TRAMITE_TEMP NOT IN (SELECT ID_TRAMITE_TEMP FROM RUG_TRAMITES_REASIGNADOS WHERE ID_ACREEDOR = A.ID_ACREEDOR)
        AND A.ID_ACREEDOR = peIdAcreedor;


        psResult  := 0;
        psTxResult := 'Eliminacion Exitosa';

         COMMIT;     

    END IF;



    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_ACREEDOR', 'psIdTramiteIncomp', psIdTramiteIncomp, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_ACREEDOR', 'psIdPersonaAlta', psIdPersonaAlta, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_ACREEDOR', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_ACREEDOR', 'psTxResult', psTxResult, 'OUT');    


EXCEPTION
WHEN  Ex_ErrRFC  THEN
      psResult := vlPsResultValRFC;
      psTxResult := vlPsTxtResultValRFC;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_ACREEDOR', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_ACREEDOR', 'psTxResult', psTxResult, 'OUT');
      ROLLBACK;
WHEN  Ex_ErrParametro THEN
      ROLLBACK;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_ACREEDOR', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_ACREEDOR', 'psTxResult', psTxResult, 'OUT');    
WHEN  OTHERS THEN
      psResult  := 999;   
      psTxResult:= 'Error en el proceso ' || SQLERRM;      
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_ACREEDOR', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_ACREEDOR', 'psTxResult', psTxResult, 'OUT');
      ROLLBACK;    
END SP_REGISTRO_USUARIO_ACREEDOR;
/

