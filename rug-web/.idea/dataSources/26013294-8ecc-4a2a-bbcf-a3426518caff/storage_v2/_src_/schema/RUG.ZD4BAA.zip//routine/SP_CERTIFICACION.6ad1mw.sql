create PROCEDURE           SP_CERTIFICACION 
(
    peIdTramiteCer  IN NUMBER,
    peIdTramite     IN NUMBER,
    peIdGarantia    IN NUMBER,
    peIdTipoTramite IN NUMBER,
    peIdPersona     IN NUMBER,
    psResult        OUT  INTEGER,
    psTxResult      OUT  VARCHAR2
)
IS
vlPrecio NUMBER;
/*USUARIO ADMINISTRADOR*/
    
dUserAdmin NUMBER;

BEGIN

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CERTIFICACION', 'peIdTramiteCer', peIdTramiteCer, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CERTIFICACION', 'peIdTramite', peIdTramite, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CERTIFICACION', 'peIdGarantia', peIdGarantia, 'IN');    
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CERTIFICACION', 'peIdTipoTramite', peIdTipoTramite, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CERTIFICACION', 'peIdPersona', peIdPersona, 'IN');
    
    dUserAdmin := 17381;

    SELECT PRECIO
    INTO vlPrecio
    FROM RUG_CAT_TIPO_TRAMITE
    WHERE ID_TIPO_TRAMITE = 5;

        /*IF peIdPersona <> dUserAdmin  THEN*/
            INSERT INTO RUG_CERTIFICACIONES
            VALUES(peIdTramiteCer, peIdTramite, peIdGarantia, peIdTipoTramite, sysdate, 'AC', peIdPersona, vlPrecio);
        /*END IF;*/


    

    psResult := 0;
    psTxResult := 'Alta exitosa';

    commit;

END;
/

