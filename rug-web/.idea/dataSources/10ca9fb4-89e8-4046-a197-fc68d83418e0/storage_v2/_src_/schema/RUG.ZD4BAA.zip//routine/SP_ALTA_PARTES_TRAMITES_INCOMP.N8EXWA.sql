create PROCEDURE         SP_ALTA_PARTES_TRAMITES_INCOMP (
   peIdPersona             IN     NUMBER, -- IDENTIFICADOR DE LA PESONA K SeLOGUEA
   peIdTipoTramite         IN     NUMBER,
   peIdGarantia            IN     NUMBER,
   peIdTramiteIncompleto      OUT NUMBER,
   psResult                   OUT INTEGER,
   psTxResult                 OUT VARCHAR2
)
IS
   vlIdTramiteRugIncom      NUMBER;
   vlIdGarantiaTemp         NUMBER;
   vlIdRelacionAnterior     NUMBER;
   vlRelacion               NUMBER;
   vlRelacionBienAnterior   NUMBER;
   vlIdGarantiaend          NUMBER;
   vlIdUltimoTramite        NUMBER;
   vlIdGarantiaPend         NUMBER;
   vlIdOtorgante            NUMBER;
   vlBanderaPrueba          NUMBER;
   vlAltaOtorgante          NUMBER;
   vlPais_residencia        NUMBER;
   vlIdTramite              NUMBER;
   vlParte                  NUMBER;
   vlTipoPersona            VARCHAR2 (2);
   vlRazonSocial            VARCHAR2 (350);
   vlNombre                 VARCHAR2 (255);
   vlAvlllidoP              VARCHAR2 (60);
   vlAvlllidoM              VARCHAR2 (60);
   vlFolioMercantil         VARCHAR2 (200);
   vlRFC                    VARCHAR2 (20);
   vlCURP                   VARCHAR2 (900);
   vlBDomicilio             CHAR;
   vlCalle                  VARCHAR2 (250);
   vlNumExt                 VARCHAR2 (50);
   vlNumInt                 VARCHAR2 (50);
   vlIdColonia              NUMBER;
   vlIdLocalidad            NUMBER;
   vlIdPersona              NUMBER;
   vlIdNacionalidad         NUMBER;
   vlTelefono               VARCHAR2 (50);
   vlExtension              VARCHAR2 (50);
   vlEmail                  VARCHAR2 (200);
   vlIdPersonaAlta          NUMBER;
   vlResult                 INTEGER;
   vlTxResult               VARCHAR2 (250);
   vlUbicaDomicilio1        VARCHAR2(2000); -- error de garantia, por espacio
   vlUbicaDomicilio2        VARCHAR2(2000);
   vlPoblacion              VARCHAR2(200);
   vlZonaPostal             VARCHAR2(30); 
   vlNumInscrita            VARCHAR2(200);
   vlFolio                  VARCHAR2(200);
   vlLibro                  VARCHAR2(200);
   vlUbicada                VARCHAR2(4000);
   vlEdad                   VARCHAR2(200);
   vlEstadoCivil            VARCHAR2(200);
   vlOcupacionActual        VARCHAR2(200);

   rel_bien        NUMBER :=0;



   Ex_TipoTramite EXCEPTION;

   CURSOR cursPartes (
      cpeIdGarantia   IN            NUMBER
   )
   IS
        SELECT   RPP.ID_PERSONA, RPP.ID_PARTE, REP.PER_JURIDICA
          FROM         RUG_REL_GARANTIA_PARTES RPP
                    INNER JOIN
                       RUG_GARANTIAS RGG
                    ON RPP.ID_RELACION = RGG.ID_RELACION
                 INNER JOIN
                    RUG_PERSONAS REP
                 ON RPP.ID_PERSONA = REP.ID_PERSONA
         WHERE       RPP.ID_GARANTIA = peIdGarantia
                 AND RPP.STATUS_REG = 'AC'
                 AND RPP.ID_PARTE <> 5
      ORDER BY   RPP.ID_PARTE ASC;

   cursPartes_Rec           cursPartes%ROWTYPE;
BEGIN
   REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL,
                  'SP_Alta_Partes_Tramites_Incomp',
                  'peIdPersona',
                  peIdPersona,
                  'IN');
   REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL,
                  'SP_Alta_Partes_Tramites_Incomp',
                  'peIdTipoTramite',
                  peIdTipoTramite,
                  'IN');
   REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL,
                  'SP_Alta_Partes_Tramites_Incomp',
                  'peIdGarantia',
                  peIdGarantia,
                  'IN');

   --PL QUE DA DE ALTA UN TRAMITE INCOMPLETO Y COPIA TODAS LAS RELACIIONES DE PERSONAS DEL COMPLETO AL INCOMPLETO

   IF peIdTipoTramite NOT IN (7,8, 6, 13)
   THEN
      RAISE Ex_TipoTramite;
   END IF;

   vlIdTramiteRugIncom := SEQ_TRAM_INCOMP.NEXTVAL;
   vlIdGarantiaTemp := SEQ_GARANTIAS_TEMP.NEXTVAL;

   SELECT   ID_ULTIMO_TRAMITE
     INTO   vlIdUltimoTramite
     FROM   RUG_GARANTIAS
    WHERE   ID_GARANTIA = peIdGarantia;

   INSERT INTO TRAMITES_RUG_INCOMP
     VALUES   (vlIdTramiteRugIncom,
               peIdPersona,
               peIdTipoTramite,
               SYSDATE,
               NULL,
               'AC',
               0,
               0,
               SYSDATE,
               0);

   INSERT INTO RUG_BITAC_TRAMITES
     VALUES   (vlIdTramiteRugIncom,
               0,
               SYSDATE,
               0,
               peIdTipoTramite,
               SYSDATE,
               'AC');

--   SELECT   ID_PERSONA
--     INTO   vlIdOtorgante
--     FROM   V_GARANTIA_PARTES
--    WHERE       ID_GARANTIA = peIdGarantia
--            AND ID_TRAMITE = (SELECT   ID_TRAMITE
--                                FROM   (  SELECT   ID_TRAMITE
--                                            FROM   V_GARANTIA_PARTES
--                                           WHERE   ID_GARANTIA = peIdGarantia
--                                        ORDER BY   ID_TRAMITE DESC)
--                               WHERE   ROWNUM < 2)
--            AND ID_PARTE = 1;



--   BEGIN
--      SELECT   ID_PERSONA
--        INTO   vlIdOtorgante
--        FROM   (  SELECT   ID_PERSONA, COUNT (ID_PERSONA) CANTIDAD
--                    FROM   V_GARANTIA_PARTES
--                   WHERE   ID_GARANTIA = peIdGarantia
--                           AND ID_TRAMITE =
--                                 (SELECT   ID_TRAMITE
--                                    FROM   (  SELECT   ID_TRAMITE
--                                                FROM   V_GARANTIA_PARTES
--                                               WHERE   ID_GARANTIA = peIdGarantia
--                                            ORDER BY   ID_TRAMITE DESC)
--                                   WHERE   ROWNUM < 2)
--                GROUP BY   ID_PERSONA)
--       WHERE   CANTIDAD > 1;
--   EXCEPTION
--      WHEN NO_DATA_FOUND
--      THEN
--         vlIdOtorgante := NULL;
--   END;

   vlBanderaPrueba := 0;

   BEGIN
 
      FOR cursPartes_Rec IN cursPartes (peIdGarantia)
      LOOP
           
         SELECT   RPH.ID_PARTE,
                  RPH.PER_JURIDICA,
                  RPH.RAZON_SOCIAL,
                  RPH.NOMBRE_PERSONA,
                  RPH.AP_PATERNO,
                  RPH.AP_MATERNO,
                  RPH.FOLIO_MERCANTIL,
                  RPH.RFC,
                  DECODE (RPH.PER_JURIDICA, 'PF',(SELECT CURP FROM RUG_PERSONAS_FISICAS WHERE ID_PERSONA = RPH.ID_PERSONA), RPH.CURP_DOC) AS CURP_DOC,
                  'V',
                  RDH.CALLE,
                  RDH.NUM_EXTERIOR,
                  RDH.NUM_INTERIOR,
                  RDH.ID_COLONIA,
                  RDH.ID_LOCALIDAD,
                  peIdPersona,
                  RPH.ID_NACIONALIDAD,
                  RTH.TELEFONO,
                  RTH.EXTENSION,
                  RPH.E_MAIL,
                  RDEH.UBICA_DOMICILIO_1,
                  RDEH.UBICA_DOMICILIO_2,
                  RDEH.POBLACION,
                  RDEH.ZONA_POSTAL,
                  RDEH.ID_PAIS_RESIDENCIA,
                  DECODE (RPH.PER_JURIDICA, 'PM',(SELECT NUM_INSCRITA FROM RUG_PERSONAS_MORALES WHERE ID_PERSONA = RPH.ID_PERSONA), NULL) AS NUM_INSCRITA,
                  DECODE (RPH.PER_JURIDICA, 'PM',(SELECT FOLIO FROM RUG_PERSONAS_MORALES WHERE ID_PERSONA = RPH.ID_PERSONA), NULL) AS FOLIO,
                  DECODE (RPH.PER_JURIDICA, 'PM',(SELECT LIBRO FROM RUG_PERSONAS_MORALES WHERE ID_PERSONA = RPH.ID_PERSONA), NULL) AS LIBRO,
                  DECODE (RPH.PER_JURIDICA, 'PM',(SELECT UBICADA FROM RUG_PERSONAS_MORALES WHERE ID_PERSONA = RPH.ID_PERSONA), NULL) AS UBICADA,
                  DECODE (RPH.PER_JURIDICA, 'PF',(SELECT EDAD FROM RUG_PERSONAS_FISICAS WHERE ID_PERSONA = RPH.ID_PERSONA), NULL) AS EDAD,
                  DECODE (RPH.PER_JURIDICA, 'PF',(SELECT ESTADO_CIVIL FROM RUG_PERSONAS_FISICAS WHERE ID_PERSONA = RPH.ID_PERSONA), NULL) AS ESTADO_CIVIL,
                  DECODE (RPH.PER_JURIDICA, 'PF',(SELECT OCUPACION_ACTUAL FROM RUG_PERSONAS_FISICAS WHERE ID_PERSONA = RPH.ID_PERSONA), NULL) AS OCUPACION_ACTUAL
           INTO   vlParte,
                  vlTipoPersona,
                  vlRazonSocial,
                  vlNombre,
                  vlAvlllidoP,
                  vlAvlllidoM,
                  vlFolioMercantil,
                  vlRFC,
                  vlCURP,
                  vlBDomicilio,
                  vlCalle,
                  vlNumExt,
                  vlNumInt,
                  vlIdColonia,
                  vlIdLocalidad,
                  vlIdPersona,
                  vlIdNacionalidad,
                  vlTelefono,
                  vlExtension,
                  vlEmail,
                  vlUbicaDomicilio1,
                  vlUbicaDomicilio2,
                  vlPoblacion,
                  vlZonaPostal,
                  vlPais_residencia,
                  vlNumInscrita,
                  vlFolio,
                  vlLibro,
                  vlUbicada,
                  vlEdad,
                  vlEstadoCivil,
                  vlOcupacionActual
           FROM         RUG_PERSONAS_H RPH
                     LEFT JOIN
                        RUG_TELEFONOS_H RTH
                     ON     RPH.ID_TRAMITE = RTH.ID_TRAMITE
                        AND RPH.ID_PERSONA = RTH.ID_PERSONA
                        AND RPH.ID_PARTE = RTH.ID_PARTE
                  LEFT JOIN
                     RUG_DOMICILIOS_H RDH
                  ON     RPH.ID_TRAMITE = RDH.ID_TRAMITE
                     AND RPH.ID_PERSONA = RDH.ID_PERSONA
                     AND RPH.ID_PARTE = RDH.ID_PARTE
                 LEFT JOIN  RUG_DOMICILIOS_EXT_H RDEH
                    ON  RDEH.ID_TRAMITE = RPH.ID_TRAMITE
                    AND RDEH.ID_PERSONA = RPH.ID_PERSONA
                    AND RDEH.ID_PARTE = RPH.ID_PARTE
          WHERE       RPH.ID_TRAMITE = vlIdUltimoTramite
                  AND RPH.ID_PERSONA = cursPartes_Rec.ID_PERSONA
                  AND RPH.ID_PARTE = cursPartes_Rec.ID_PARTE;


         IF cursPartes_Rec.ID_PARTE <> 4
         THEN
            IF vlBanderaPrueba = cursPartes_Rec.ID_PERSONA THEN

                vlIdPersonaAlta := vlAltaOtorgante;


                  
            INSERT INTO RUG_REL_TRAM_INC_PARTES
              VALUES   (vlIdTramiteRugIncom,
                        vlIdPersonaAlta,
                        vlParte,
                        vlTipoPersona,
                        'AC',
                        SYSDATE);

            ELSE


                 SP_ALTAPARTE (vlIdTramiteRugIncom,
                             vlParte,
                             vlTipoPersona,
                             vlRazonSocial,
                             vlNombre,
                             vlAvlllidoP,
                             vlAvlllidoM,
                             vlFolioMercantil,
                             vlRFC,
                             vlCURP,
                             vlBDomicilio,
                             vlCalle,
                             vlNumExt,
                             vlNumInt,
                             vlIdColonia,
                             vlIdLocalidad,
                             vlIdPersona,
                             vlIdNacionalidad,
                             vlTelefono,
                             vlExtension,
                             vlEmail,
                             vlUbicaDomicilio1,
                             vlUbicaDomicilio2,
                             vlPoblacion,
                             vlZonaPostal,
                             vlPais_residencia,
                             vlNumInscrita,
                             vlFolio,
                             vlLibro,
                             vlUbicada,
                             vlEdad,
                             vlEstadoCivil,
                             vlOcupacionActual,
                             vlIdPersonaAlta,
                             vlResult,
                             vlTxResult);

            END IF;

         ELSE
            vlIdPersonaAlta := cursPartes_Rec.ID_PERSONA;
            
            REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL,
                  'SP_Alta_Partes_Tramites_Incomp',
                  'vlIdPersonaAlta-4',
                  vlIdPersonaAlta,
                  'IN');

            INSERT INTO RUG_REL_TRAM_INC_PARTES
              VALUES   (vlIdTramiteRugIncom,
                        vlIdPersonaAlta,
                        vlParte,
                        vlTipoPersona,
                        'AC',
                        SYSDATE);
         END IF;

          IF cursPartes_Rec.ID_PARTE = 1
            THEN
                vlBanderaPrueba := cursPartes_Rec.ID_PERSONA;
                vlAltaOtorgante := vlIdPersonaAlta;
            END IF;

      END LOOP;
   END;


   IF peIdTipoTramite = 8
   THEN                                                         -- TRANSMISION
      SELECT   ID_RELACION, RELACION_BIEN, ID_GARANTIA_PEND
        INTO   vlIdRelacionAnterior, vlRelacionBienAnterior, vlIdGarantiaPend
        FROM   RUG_GARANTIAS
       WHERE   ID_GARANTIA = peIdGarantia;

    /* INI BLOQUE ORIGINAL EEE */
    /*
      INSERT INTO RUG_GARANTIAS_PENDIENTES (ID_GARANTIA_PEND,
                                            ID_PERSONA,
                                            ID_ULTIMO_TRAMITE,
                                            ID_GARANTIA_MODIFICAR,
                                            ID_RELACION)
        VALUES   (vlIdGarantiaTemp,
                  peIdPersona,
                  vlIdTramiteRugIncom,
                  peIdGarantia,
                  vlIdRelacionAnterior);

      INSERT INTO RUG_REL_TRAM_INC_GARAN
      VALUES   (vlIdGarantiaTemp, vlIdTramiteRugIncom, 'AC', SYSDATE);                  
    */

    /* INI CAMBIOS EEE */
        INSERT INTO RUG_GARANTIAS_PENDIENTES (ID_GARANTIA_PEND,
                                            ID_PERSONA,
                                            ID_ULTIMO_TRAMITE,
                                            ID_GARANTIA_MODIFICAR,
                                            ID_RELACION,
                                            RELACION_BIEN)
        VALUES   (vlIdGarantiaTemp,
                  peIdPersona,
                  vlIdTramiteRugIncom,
                  peIdGarantia,
                  vlIdRelacionAnterior,
                  rel_Bien
                  );

      INSERT INTO RUG_REL_TRAM_INC_GARAN
      VALUES   (vlIdGarantiaTemp, vlIdTramiteRugIncom, 'AC', SYSDATE);                  

DBMS_OUTPUT.PUT_LINE ('peIdGarantia:' || peIdGarantia);

    /* ini bloque original EEE */
    /*
     vlRelacion := RUG.SEQ_BIENES.NEXTVAL;

--      SELECT   RELACION_BIEN + 1
--        INTO   vlRelacion
--        FROM   (  SELECT   RELACION_BIEN
--                    FROM   RUG_REL_GAR_TIPO_BIEN
--                   WHERE   RELACION_BIEN IS NOT NULL
--                ORDER BY   1 DESC)
--       WHERE   ROWNUM = 1;

      INSERT INTO RUG_REL_GAR_TIPO_BIEN
         SELECT   vlIdGarantiaTemp, ID_TIPO_BIEN, vlRelacion
           FROM   RUG_REL_GAR_TIPO_BIEN
          WHERE   ID_GARANTIA_PEND = vlIdGarantiaPend
                  AND RELACION_BIEN = vlRelacionBienAnterior;
 /* fin bloque original EEE */

        /* ini cambios EEE */
     --vlRelacion := RUG.SEQ_BIENES.NEXTVAL;

--      SELECT   RELACION_BIEN + 1
--        INTO   vlRelacion
--        FROM   (  SELECT   RELACION_BIEN
--                    FROM   RUG_REL_GAR_TIPO_BIEN
--                   WHERE   RELACION_BIEN IS NOT NULL
--                ORDER BY   1 DESC)
--       WHERE   ROWNUM = 1;

            DBMS_OUTPUT.PUT_LINE ('vlIdGarantiaPend:' || vlIdGarantiaPend);
            select 
            --*
            (max(pend.relacion_bien) + 1 ) into rel_bien
            from rug_garantias_pendientes pend
            where 
            --pend.id_garantia_pend=vlIdGarantiaPend
            pend.id_garantia_modificar=peIdGarantia
            and pend.relacion_bien is not null
            ;


         DBMS_OUTPUT.PUT_LINE ('vlIdGarantiaTemp:' || vlIdGarantiaTemp);
         DBMS_OUTPUT.PUT_LINE ('rel_bien: '||rel_bien );

        insert into RUG_REL_GAR_TIPO_BIEN
            --select vlIdGarantiaTemp, reltipobien.id_tipo_bien, reltipobien.relacion_bien + 1
            select distinct(vlIdGarantiaTemp), reltipobien.id_tipo_bien, rel_bien
            from RUG_REL_GAR_TIPO_BIEN reltipobien
            where relacion_bien in (
                rel_bien - 1
            ) 
            and id_tipo_bien is not null
            ;


         UPDATE RUG_GARANTIAS_PENDIENTES SET RELACION_BIEN = rel_bien
         WHERE ID_GARANTIA_PEND = vlIdGarantiaTemp;


    /* fin cambios EEE */


      INSERT INTO RUG_CONTRATO
         SELECT   SEQ_CONTRATO.NEXTVAL,
                  vlIdGarantiaTemp,
                  CONTRATO_NUM,
                  FECHA_INICIO,
                  FECHA_FIN,
                  OTROS_TERMINOS_CONTRATO,
                  MONTO_LIMITE,
                  OBSERVACIONES,
                  TIPO_CONTRATO,
                  vlIdTramiteRugIncom,
                  SYSDATE,
                  'AC',
                  ID_USUARIO,
                  CLASIF_CONTRATO
           FROM   RUG_CONTRATO
          WHERE   ID_GARANTIA_PEND = vlIdGarantiaPend
                  AND CLASIF_CONTRATO = 'OB';
   END IF;

   peIdTramiteIncompleto := vlIdTramiteRugIncom;

   REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL,
                  'SP_Alta_Partes_Tramites_Incomp',
                  'peIdTramiteIncompleto',
                  peIdTramiteIncompleto,
                  'OUT');

   psResult := 0;
   psTxResult := 'ALTA EXITOSA';  --pkg_infz_inst_fenx.FunObtMsgErr(psResult);

   COMMIT;
EXCEPTION
   WHEN Ex_TipoTramite
   THEN
      psResult := 13;

      SELECT   DESC_CODIGO
        INTO   psTxResult
        FROM   RUG_CAT_MENSAJES_ERRORES
       WHERE   ID_CODIGO = psResult;

      ROLLBACK;
      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL,
                     'SP_Alta_Partes_Tramites_Incomp',
                     'peIdTramiteIncompleto',
                     peIdTramiteIncompleto,
                     'OUT');
      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL,
                     'SP_Alta_Partes_Tramites_Incomp',
                     'psResult',
                     psResult,
                     'OUT');
      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL,
                     'SP_Alta_Partes_Tramites_Incomp',
                     'psTxResult',
                     psTxResult,
                     'OUT');
      DBMS_OUTPUT.PUT_LINE (psTxResult);
   WHEN OTHERS
   THEN

      psResult := 999;
      psTxResult := SUBSTR (SQLCODE || ':' || SQLERRM, 1, 250);
      ROLLBACK;
      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL,
                     'SP_Alta_Partes_Tramites_Incomp',
                     'peIdTramiteIncompleto',
                     peIdTramiteIncompleto,
                     'OUT');
      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL,
                     'SP_Alta_Partes_Tramites_Incomp',
                     'psResult',
                     psResult,
                     'OUT');
      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL,
                     'SP_Alta_Partes_Tramites_Incomp',
                     'psTxResult',
                     psTxResult,
                     'OUT');
                     
      DBMS_OUTPUT.PUT_LINE (psTxResult);
END;
/

