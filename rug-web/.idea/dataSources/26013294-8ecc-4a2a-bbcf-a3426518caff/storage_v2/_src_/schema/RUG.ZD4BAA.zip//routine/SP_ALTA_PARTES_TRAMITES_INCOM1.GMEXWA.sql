create PROCEDURE         SP_ALTA_PARTES_TRAMITES_INCOM1 (
   peIdPersona             IN     NUMBER, -- IDENTIFICADOR DE LA PESONA K SeLOGUEA
   peIdTipoTramite         IN     NUMBER,
   peIdGarantia            IN     NUMBER,
   peIdTramiteIncompleto      OUT NUMBER,
   psResult                   OUT INTEGER,
   psTxResult                 OUT VARCHAR2
)
IS

   vlIdDomicilio            NUMBER;
   vlIdTramiteRugIncom      NUMBER;
   vlIdGarantiaTemp         NUMBER;
   vlIdRelacionAnterior     NUMBER;
   vlRelacion               NUMBER;
   vlRelacionBienAnterior   NUMBER;
   vlIdGarantiaend          NUMBER;
   vlIdUltimoTramite        NUMBER;
   vlIdGarantiaPend         NUMBER;
   vlIdOtorgante            NUMBER;
   vlBanderaPrueba          NUMBER;
   vlAltaOtorgante          NUMBER;
   vlPais_residencia        NUMBER;
   vlIdTramite              NUMBER;
   vlParte                  NUMBER;
   vlIdTipo                 VARCHAR2 (2);
   vlTipoPersona            VARCHAR2 (2);
   vlRazonSocial            VARCHAR2 (350);
   vlNombre                 VARCHAR2 (60);
   vlApellidoP              VARCHAR2 (60);
   vlApellidoM              VARCHAR2 (60);
   vlFolioMercantil         VARCHAR2 (200);
   vlRFC                    VARCHAR2 (20);
   vlCURP                   VARCHAR2 (900);
   vlBDomicilio             CHAR;
   vlCalle                  VARCHAR2 (250);
   vlNumExt                 VARCHAR2 (50);
   vlNumInt                 VARCHAR2 (50);
   vlIdColonia              NUMBER;
   vlIdLocalidad            NUMBER;
   vlIdPersona              NUMBER;
   vlIdNacionalidad         NUMBER;
   vlTelefono               VARCHAR2 (50);
   vlExtension              VARCHAR2 (50);
   vlEmail                  VARCHAR2 (200);
   vlIdPersonaAlta          NUMBER;
   vlResult                 INTEGER;
   vlTxResult               VARCHAR2 (250);
   vlUbicaDomicilio1        VARCHAR2(200);
   vlUbicaDomicilio2        VARCHAR2(200);
   vlPoblacion              VARCHAR2(200);
   vlZonaPostal             VARCHAR2(30);     
   TOTAL NUMBER;  





   Ex_Error EXCEPTION;

   CURSOR cursPartes --(cpeIdGarantia   IN            NUMBER)
   IS
        SELECT   RPP.ID_PERSONA, RPP.ID_PARTE, REP.PER_JURIDICA
          FROM         RUG_REL_GARANTIA_PARTES RPP
                    INNER JOIN
                       RUG_GARANTIAS RGG
                    ON RPP.ID_RELACION = RGG.ID_RELACION
                 INNER JOIN
                    RUG_PERSONAS REP
                 ON RPP.ID_PERSONA = REP.ID_PERSONA
         WHERE       RPP.ID_GARANTIA = peIdGarantia
                 AND RPP.STATUS_REG = 'AC'
                 AND RPP.ID_PARTE <> 5
      ORDER BY   RPP.ID_PERSONA, 2 ASC;

   cursPartes_Rec           cursPartes%ROWTYPE;
BEGIN
   REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL,'SP_Alta_Partes_Tramites_Incomp1','peIdPersona',peIdPersona,'IN');
   REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL,'SP_Alta_Partes_Tramites_Incomp1','peIdTipoTramite',peIdTipoTramite,'IN');
   REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL,'SP_Alta_Partes_Tramites_Incomp1','peIdGarantia',peIdGarantia,'IN');

   --PL QUE DA DE ALTA UN TRAMITE INCOMPLETO Y COPIA TODAS LAS RELACIIONES DE PERSONAS DEL COMPLETO AL INCOMPLETO

   IF peIdTipoTramite NOT IN (7, 8, 6, 13)
   THEN
      psResult := 13;
      RAISE Ex_Error;
   END IF;

   vlIdTramiteRugIncom := SEQ_TRAM_INCOMP.NEXTVAL;
   vlIdGarantiaTemp := SEQ_GARANTIAS_TEMP.NEXTVAL;

   SELECT   ID_ULTIMO_TRAMITE
     INTO   vlIdUltimoTramite
     FROM   RUG_GARANTIAS
    WHERE   ID_GARANTIA = peIdGarantia;

   INSERT INTO TRAMITES_RUG_INCOMP
     VALUES   (vlIdTramiteRugIncom, peIdPersona, peIdTipoTramite, SYSDATE, NULL, 'AC', 0, 0, SYSDATE, 0);

   INSERT INTO RUG_BITAC_TRAMITES
     VALUES   (vlIdTramiteRugIncom, 0, SYSDATE, 0, peIdTipoTramite, SYSDATE, 'AC');


   vlBanderaPrueba := 0;

   BEGIN
      FOR cursPartes_Rec IN cursPartes --(peIdGarantia)
      LOOP

         SELECT   RPH.ID_PARTE,
                  RPH.PER_JURIDICA,
                  RPH.RAZON_SOCIAL,
                  RPH.NOMBRE_PERSONA,
                  RPH.AP_PATERNO,
                  RPH.AP_MATERNO,
                  RPH.FOLIO_MERCANTIL,
                  RPH.RFC,
                  RPH.CURP_DOC,
                  'V',
                  RDH.CALLE,
                  RDH.NUM_EXTERIOR,
                  RDH.NUM_INTERIOR,
                  RDH.ID_COLONIA,
                  RDH.ID_LOCALIDAD,
                  peIdPersona,
                  RPH.ID_NACIONALIDAD,
                  RTH.TELEFONO,
                  RTH.EXTENSION,
                  RPH.E_MAIL,
                  RDEH.UBICA_DOMICILIO_1,
                  RDEH.UBICA_DOMICILIO_2,
                  RDEH.POBLACION,
                  RDEH.ZONA_POSTAL,
                  RDEH.ID_PAIS_RESIDENCIA
           INTO   vlParte,
                  vlTipoPersona,
                  vlRazonSocial,
                  vlNombre,
                  vlApellidoP,
                  vlApellidoM,
                  vlFolioMercantil,
                  vlRFC,
                  vlCURP,
                  vlBDomicilio,
                  vlCalle,
                  vlNumExt,
                  vlNumInt,
                  vlIdColonia,
                  vlIdLocalidad,
                  vlIdPersona,
                  vlIdNacionalidad,
                  vlTelefono,
                  vlExtension,
                  vlEmail,
                  vlUbicaDomicilio1,
                  vlUbicaDomicilio2,
                  vlPoblacion,
                  vlZonaPostal,
                  vlPais_residencia                
           FROM         RUG_PERSONAS_H RPH
                     LEFT JOIN
                        RUG_TELEFONOS_H RTH
                     ON     RPH.ID_TRAMITE = RTH.ID_TRAMITE
                        AND RPH.ID_PERSONA = RTH.ID_PERSONA
                        AND RPH.ID_PARTE = RTH.ID_PARTE
                  LEFT JOIN
                     RUG_DOMICILIOS_H RDH
                  ON     RPH.ID_TRAMITE = RDH.ID_TRAMITE
                     AND RPH.ID_PERSONA = RDH.ID_PERSONA
                     AND RPH.ID_PARTE = RDH.ID_PARTE
                 LEFT JOIN  RUG_DOMICILIOS_EXT_H RDEH
                    ON  RDEH.ID_TRAMITE = RPH.ID_TRAMITE
                    AND RDEH.ID_DOMICILIO = RPH.ID_PERSONA
                    AND RDEH.ID_PARTE = RPH.ID_PARTE
          WHERE       RPH.ID_TRAMITE = vlIdUltimoTramite
                  AND RPH.ID_PERSONA = cursPartes_Rec.ID_PERSONA
                  AND RPH.ID_PARTE = cursPartes_Rec.ID_PARTE;

         IF cursPartes_Rec.ID_PARTE <> 4
         THEN
            IF vlBanderaPrueba = cursPartes_Rec.ID_PERSONA THEN

                vlIdPersonaAlta := vlAltaOtorgante;

                INSERT INTO RUG_REL_TRAM_INC_PARTES
                VALUES   (vlIdTramiteRugIncom, vlIdPersonaAlta, vlParte, vlTipoPersona, 'AC',SYSDATE);

            ELSE

                IF vlTipoPersona = 'PM' THEN

                    SELECT TIPO
                      INTO vlIdTipo
                      FROM RUG_PERSONAS_MORALES
                     WHERE ID_PERSONA = cursPartes_Rec.ID_PERSONA;

                END IF;            

--                SP_ALTAPARTE1 (vlIdTramiteRugIncom, vlParte, vlTipoPersona, vlIdTipo, vlRazonSocial, vlNombre, vlApellidoP, vlApellidoM, vlFolioMercantil, vlRFC, vlCURP,
--                              vlBDomicilio, vlCalle, vlNumExt, vlNumInt, vlIdColonia, vlIdLocalidad, vlIdPersona, vlIdNacionalidad, vlTelefono, vlExtension, vlEmail,
--                              vlUbicaDomicilio1, vlUbicaDomicilio2, vlPoblacion, vlZonaPostal, vlPais_residencia, vlIdPersonaAlta, vlResult, vlTxResult);


                vlIdDomicilio := SEQ_RUG_ID_DOMICILIO.NEXTVAL;        

                IF(vlBDomicilio = 'V') THEN

                     IF vlPais_residencia = 1 OR vlPais_residencia IS NULL  THEN

                        INSERT INTO RUG_DOMICILIOS (ID_DOMICILIO, CALLE, NUM_EXTERIOR, NUM_INTERIOR, ID_COLONIA, ID_LOCALIDAD)
                        VALUES   (vlIdDomicilio, vlCalle, vlNumExt, vlNumInt, DECODE(vlIdColonia, -1, 0,vlIdColonia) , DECODE(vlIdLocalidad,-1,0,vlIdLocalidad));

                     ELSE    


                       INSERT INTO RUG.RUG_DOMICILIOS_EXT(ID_DOMICILIO, ID_PAIS_RESIDENCIA, UBICA_DOMICILIO_1, UBICA_DOMICILIO_2, POBLACION, ZONA_POSTAL)
                       VALUES(vlIdDomicilio, vlPais_residencia, vlUbicaDomicilio1, vlUbicaDomicilio2, vlPoblacion, vlZonaPostal);

                    END IF;                

                END IF;

                vlIdPersona:= SEQ_RUG_ID_PERSONA.NEXTVAL;


                INSERT INTO RUG_PERSONAS (ID_PERSONA, RFC, ID_NACIONALIDAD, PER_JURIDICA, FH_REGISTRO, PROCEDENCIA, SIT_PERSONA,
                                             CVE_NACIONALIDAD, ID_DOMICILIO, FOLIO_MERCANTIL, FECHA_INSCR_CC, REG_TERMINADO, E_MAIL, CURP_DOC)
                VALUES   (vlIdPersona, vlRFC, vlIdNacionalidad, vlTipoPersona, TRUNC(SYSDATE), 'NAL', 'AC', NULL, vlIdDomicilio, vlFolioMercantil, NULL, 'N', vlEmail, vlCurp);

                IF vlTelefono IS NOT NULL THEN

                    INSERT INTO RUG_TELEFONOS
                    VALUES(vlIdPersona, NULL, vlTelefono, vlExtension, SYSDATE, 'AC');

                END IF; 


                IF(UPPER(vlTipoPersona) = 'PM') THEN

                    IF(vlRazonSocial is null OR TRIM (vlRazonSocial)='' )THEN

                        psResult := 77;
                        RAISE Ex_Error;


                    END IF;

                    INSERT INTO RUG_PERSONAS_MORALES (ID_PERSONA, RAZON_SOCIAL, TIPO)
                    VALUES   (vlIdPersona, TRIM(vlRazonSocial), vlIdTipo);


                ELSIF (UPPER(vlTipoPersona) = 'PF') THEN


                    INSERT INTO RUG_PERSONAS_FISICAS (ID_PERSONA, NOMBRE_PERSONA, AP_PATERNO, AP_MATERNO, CURP)
                    VALUES   (vlIdPersona, TRIM(vlNombre), TRIM(vlApellidoP), TRIM(vlApellidoM), TRIM(vlCurp));

                END IF;

                INSERT INTO RUG_REL_TRAM_INC_PARTES( ID_TRAMITE_TEMP,  ID_PERSONA, ID_PARTE, PER_JURIDICA, STATUS_REG, FECHA_REG)
                VALUES (vlIdTramiteRugIncom, vlIdPersona, vlParte, vlTipoPersona, 'AC', SYSDATE);


                vlIdPersonaAlta := vlIdPersona;

            END IF;

         ELSE
            vlIdPersonaAlta := cursPartes_Rec.ID_PERSONA;

            INSERT INTO RUG_REL_TRAM_INC_PARTES
              VALUES   (vlIdTramiteRugIncom,
                        vlIdPersonaAlta,
                        vlParte,
                        vlTipoPersona,
                        'AC',
                        SYSDATE);
         END IF;

          IF cursPartes_Rec.ID_PARTE = 1
            THEN
                vlBanderaPrueba := cursPartes_Rec.ID_PERSONA;
                vlAltaOtorgante := vlIdPersonaAlta;
          END IF;            

      END LOOP;
   END;


   IF peIdTipoTramite = 8
   THEN                                                         -- TRANSMISION
      SELECT   ID_RELACION, RELACION_BIEN, ID_GARANTIA_PEND
        INTO   vlIdRelacionAnterior, vlRelacionBienAnterior, vlIdGarantiaPend
        FROM   RUG_GARANTIAS
       WHERE   ID_GARANTIA = peIdGarantia;

      INSERT INTO RUG_GARANTIAS_PENDIENTES (ID_GARANTIA_PEND,
                                            ID_PERSONA,
                                            ID_ULTIMO_TRAMITE,
                                            ID_GARANTIA_MODIFICAR,
                                            ID_RELACION)
        VALUES   (vlIdGarantiaTemp,
                  peIdPersona,
                  vlIdTramiteRugIncom,
                  peIdGarantia,
                  vlIdRelacionAnterior);

      INSERT INTO RUG_REL_TRAM_INC_GARAN
      VALUES   (vlIdGarantiaTemp, vlIdTramiteRugIncom, 'AC', SYSDATE);                  

     vlRelacion := RUG.SEQ_BIENES.NEXTVAL;

      INSERT INTO RUG_REL_GAR_TIPO_BIEN
         SELECT   vlIdGarantiaTemp, ID_TIPO_BIEN, vlRelacion
           FROM   RUG_REL_GAR_TIPO_BIEN
          WHERE   ID_GARANTIA_PEND = vlIdGarantiaPend
                  AND RELACION_BIEN = vlRelacionBienAnterior;

      INSERT INTO RUG_CONTRATO
         SELECT   SEQ_CONTRATO.NEXTVAL,
                  vlIdGarantiaTemp,
                  CONTRATO_NUM,
                  FECHA_INICIO,
                  FECHA_FIN,
                  OTROS_TERMINOS_CONTRATO,
                  MONTO_LIMITE,
                  OBSERVACIONES,
                  TIPO_CONTRATO,
                  vlIdTramiteRugIncom,
                  SYSDATE,
                  'AC',
                  ID_USUARIO,
                  CLASIF_CONTRATO
           FROM   RUG_CONTRATO
          WHERE   ID_GARANTIA_PEND = vlIdGarantiaPend
                  AND CLASIF_CONTRATO = 'OB';
   END IF;

   peIdTramiteIncompleto := vlIdTramiteRugIncom;

   REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL,'SP_Alta_Partes_Tramites_Incomp1','peIdTramiteIncompleto',peIdTramiteIncompleto,'OUT');

   psResult := 0;
   psTxResult := 'ALTA EXITOSA';  --pkg_infz_inst_fenx.FunObtMsgErr(psResult);

   COMMIT;
EXCEPTION
   WHEN Ex_Error
   THEN     
      psTxResult := RUG.FN_MENSAJE_ERROR(psResult);

      ROLLBACK;
      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL,'SP_Alta_Partes_Tramites_Incomp1','peIdTramiteIncompleto',peIdTramiteIncompleto,'OUT');
      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL,'SP_Alta_Partes_Tramites_Incomp1','psResult',psResult,'OUT');
      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL,'SP_Alta_Partes_Tramites_Incomp1','psTxResult',psTxResult,'OUT');
      DBMS_OUTPUT.PUT_LINE (psTxResult);
   WHEN OTHERS
   THEN
      psResult := 999;
      psTxResult := SUBSTR (SQLCODE || ':' || SQLERRM, 1, 250);
      ROLLBACK;
      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL,'SP_Alta_Partes_Tramites_Incomp1','peIdTramiteIncompleto',peIdTramiteIncompleto,'OUT');
      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL,'SP_Alta_Partes_Tramites_Incomp1','psResult',psResult,'OUT');
      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL,'SP_Alta_Partes_Tramites_Incomp1','psTxResult',psTxResult,'OUT');
      DBMS_OUTPUT.PUT_LINE (psTxResult);
END;
/

