create PROCEDURE         SP_MODIFICA_GARANTIA_RECTIFICA 
( 
    peIdTramiteTemp          IN  RUG_REL_TRAM_INC_GARAN.ID_TRAMITE_TEMP%TYPE,  --  IDENTIFICADOR DEL TRAMITE ASOCIADO A LA GARANTIA
    peIdGarantia             IN  RUG_GARANTIAS_PENDIENTES.ID_GARANTIA_PEND%TYPE,    --  IDENTIFICADOR DE LA GARANTIA
    peIdTipoGarantia         IN  RUG_GARANTIAS_PENDIENTES.ID_TIPO_GARANTIA%TYPE,  --IDENTIFICADOR DEL TIPO DE GARANTIA QUE SE INSCRIBE
    peFechaCelebGarantia     IN  RUG_GARANTIAS_PENDIENTES.FECHA_INSCR %TYPE, -- Fecha de celebracion del Acto o Contrato, que crea la garantia
    peMontoMaxGarantizado    IN  RUG_GARANTIAS_PENDIENTES.MONTO_MAXIMO_GARANTIZADO%TYPE,
    peIdMoneda               IN  RUG_CAT_MONEDAS.ID_MONEDA%TYPE,
    peTipoBien               IN  VARCHAR2,  --CADENA QUE CONTIENE LOS IDS TIPOS DE BIENES QUE INTEGRA UNA GARANTIA, SEPARADOS POR EL CARACTER |
    peDescGarantia           IN  RUG_GARANTIAS_PENDIENTES.DESC_GARANTIA%TYPE,
    peCambiosBienesMonto     IN  RUG_GARANTIAS_PENDIENTES.CAMBIOS_BIENES_MONTO%TYPE, --  El Acto o Contrato preve incrementos, reducciones o sustituciones de los bienes muebles o del monto garantizado
    peInstrumentoPublico     IN  RUG_GARANTIAS_PENDIENTES.INSTRUMENTO_PUBLICO%TYPE,
    peOtrosTerminosG         IN  RUG_GARANTIAS_PENDIENTES.OTROS_TERMINOS_GARANTIA%TYPE,
    peTipoContratoOb         IN  RUG_CONTRATO.TIPO_CONTRATO%TYPE,
    peFechaCelebContOb       IN  RUG_CONTRATO.FECHA_INICIO%TYPE,
    peFechaFinOb             IN  RUG_CONTRATO.FECHA_FIN%TYPE,
    peOtrosTerminosCOb       IN  RUG_CONTRATO.OTROS_TERMINOS_CONTRATO%TYPE,  --PEFECHATERMCELBECONTR     
    peIdPerson               IN  RUG_PERSONAS.ID_PERSONA%TYPE, --   IDENTIFICADOR DE LA PERSONA QUE  HACE LA INSCRIPCION    
    psResult                 OUT  INTEGER,   
    psTxResult               OUT  VARCHAR2
)
IS

vIdTram     NUMBER;
vlIdTipoTram    NUMBER;
vIdRegistro NUMBER;
vlRelacion  NUMBER;
vlIdGarantiaPend NUMBER;
contador number;
vlGarantiaStatus    CHAR(2);
vlGaranTransPend    NUMBER;
vlVigenciaGarantia  NUMBER;

vlTipoBien PKGSE_COMUN.T_PALABRAS;
vlIdTipoBien VARCHAR2(5);

RegGarantias    RUG_GARANTIAS%ROWTYPE;
RegGarantiasPend RUG_GARANTIAS_PENDIENTES%ROWTYPE;

Ex_ErrParametro EXCEPTION;
Ex_GarantiaCancelada  EXCEPTION;
Ex_TipoTramite  EXCEPTION;      


BEGIN

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_RECTIFICA', 'peIdTramiteTemp', CAST(peIdTramiteTemp AS VARCHAR2), 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_RECTIFICA', 'peIdGarantia', CAST(peIdGarantia AS VARCHAR2), 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_RECTIFICA', 'peIdTipoGarantia', CAST(peIdTipoGarantia AS VARCHAR2), 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_RECTIFICA', 'peFechaCelebGarantia', CAST(peFechaCelebGarantia AS VARCHAR2), 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_RECTIFICA', 'peCambiosBienesMonto', peCambiosBienesMonto, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_RECTIFICA', 'peIdPerson', CAST(peIdPerson AS VARCHAR2), 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_RECTIFICA', 'peTipoBien', peTipoBien, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_RECTIFICA', 'peTipoContratoOb', peTipoContratoOb, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_RECTIFICA', 'peFechaCelebContOb', CAST(peFechaCelebContOb AS VARCHAR2), 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_RECTIFICA', 'peMontoMaxGarantizado', peMontoMaxGarantizado ,'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_RECTIFICA', 'peIdMoneda', peIdMoneda, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_RECTIFICA', 'peInstrumentoPublico', peInstrumentoPublico, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_RECTIFICA', 'peFechaFinOb', peFechaFinOb, 'IN');


       BEGIN
         SELECT ID_TRAMITE_TEMP, ID_TIPO_TRAMITE
         INTO vIdTram, vlIdTipoTram
         FROM TRAMITES_RUG_INCOMP
         WHERE ID_TRAMITE_TEMP = peIdTramiteTemp;

         IF vlIdTipoTram NOT IN (6,7,8) THEN
         RAISE Ex_TipoTramite;
         END IF;

        Exception 
          WHEN NO_DATA_FOUND THEN
             dbms_output.put_line('No Existe el Tramite a Relacionar'|| vIdTram);             
       END;      

       dbms_output.put_line('PASO 1');             

       BEGIN
       --VALIDO QUE LA GARANTIA NO ESTE CANCELADA
       SELECT GARANTIA_STATUS
       INTO vlGarantiaStatus
       FROM RUG_GARANTIAS
       WHERE ID_GARANTIA = peIdGarantia;

       IF vlGarantiaStatus IN ('CA', 'CR', 'CT') THEN
        RAISE Ex_GarantiaCancelada;
       END IF;
       END;



      IF vIdTram IS NOT NULL THEN

       vlIdGarantiaPend := SEQ_GARANTIAS_TEMP.NEXTVAL; 


         SELECT VIGENCIA
        INTO vlVigenciaGarantia
        FROM RUG_GARANTIAS
        WHERE ID_GARANTIA = peIdGarantia;



            --INSERTA EN GARANTIAS PENDIENTES LOS VALORES MODIFICADOS

            INSERT INTO RUG_GARANTIAS_PENDIENTES(ID_GARANTIA_PEND
                                                ,ID_TIPO_GARANTIA
                                                ,DESC_GARANTIA
                                                ,ID_PERSONA
                                                ,RELACION_BIEN
                                                ,OTROS_TERMINOS_GARANTIA
                                                ,FECHA_INSCR
                                                ,VIGENCIA
                                                ,GARANTIA_STATUS
                                                ,ID_ULTIMO_TRAMITE
                                                ,MONTO_MAXIMO_GARANTIZADO
                                                ,ID_GARANTIA_MODIFICAR
                                                ,CAMBIOS_BIENES_MONTO
                                                ,INSTRUMENTO_PUBLICO
                                                ,ID_MONEDA)

                                        VALUES(vlIdGarantiaPend
                                            , peIdTipoGarantia
                                            , peDescGarantia
                                            , peIdPerson
                                            , vlRelacion
                                            , peOtrosTerminosG
                                            , peFechaCelebGarantia
                                            , vlVigenciaGarantia
                                            , 'AC'
                                            , peIdTramiteTemp
                                            , peMontoMaxGarantizado
                                            , peIdGarantia
                                            , peCambiosBienesMonto
                                            , peInstrumentoPublico
                                            , peIdMoneda); 

        IF peTipoBien IS NOT NULL THEN

--            SELECT RELACION_BIEN + 1
--            INTO vlRelacion
--            FROM( 
--                SELECT RELACION_BIEN
--                FROM RUG_REL_GAR_TIPO_BIEN
--                ORDER BY 1 DESC    
--                )
--            WHERE ROWNUM = 1;

            vlRelacion := RUG.SEQ_BIENES.NEXTVAL;

            vlTipoBien := INSTITUCIONAL.PKGSE_COMUN.SPLITCADENA(peTipoBien,'|'); 

            FOR i IN 1..vlTipoBien.count loop

                vlIdTipoBien := vlTipoBien(i-1);    
                INSERT INTO RUG_REL_GAR_TIPO_BIEN
                VALUES(vlIdGarantiaPend, vlIdTipoBien, vlRelacion);

            END LOOP;
        END IF;

        UPDATE RUG_GARANTIAS_PENDIENTES
        SET RELACION_BIEN = vlRelacion
        WHERE ID_GARANTIA_PEND = vlIdGarantiaPend; 

        contador :=0;

            --INSERTO EL CONTRATO QUE CREA LA OBLIGACION GARANTIZADA
            INSERT INTO RUG.RUG_CONTRATO
            VALUES (SEQ_CONTRATO.NEXTVAL, vlIdGarantiaPend, NULL, peFechaCelebContOb, peFechaFinOb, peOtrosTerminosCOb, NULL, NULL, peTipoContratoOb, peIdTramiteTemp, SYSDATE, 'AC', peIdPerson, 'OB');

         --INSERTO LA RELACION GARANTIA - TRAMITE PENDIENTES 
        INSERT INTO RUG_REL_TRAM_INC_GARAN
        VALUES(vlIdGarantiaPend, peIdTramiteTemp, 'AC', SYSDATE);

        COMMIT; 
        psResult := 0; 
        psTxResult := 'ACTUALIZACION EXITOSA';                   
      END IF;

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_RECTIFICA', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_RECTIFICA', 'psTxResult', psTxResult, 'OUT');    

  EXCEPTION 
WHEN Ex_TipoTramite  THEN         
    psResult := 13;
    SELECT DESC_CODIGO
    INTO psTxResult
    FROM RUG_CAT_MENSAJES_ERRORES
    WHERE ID_CODIGO = psResult;          
   dbms_output.put_line(psTxResult);
   ROLLBACK;
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_RECTIFICA', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_RECTIFICA', 'psTxResult', psTxResult, 'OUT');    

WHEN Ex_GarantiaCancelada  THEN        
    psResult := 15;
    SELECT DESC_CODIGO
    INTO psTxResult
    FROM RUG_CAT_MENSAJES_ERRORES
    WHERE ID_CODIGO = psResult;          
   dbms_output.put_line(psTxResult);
   ROLLBACK;
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_RECTIFICA', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_RECTIFICA', 'psTxResult', psTxResult, 'OUT');

   WHEN OTHERS THEN
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);  
  dbms_output.put_line(psTxResult);
  ROLLBACK;
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_RECTIFICA', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_RECTIFICA', 'psTxResult', psTxResult, 'OUT');    


END SP_MODIFICA_GARANTIA_RECTIFICA;
/

