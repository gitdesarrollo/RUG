create PROCEDURE         SP_GENERA_FOLIO_ELECTRONICO (
   psFolioElectronico   OUT VARCHAR2,
   psResult             OUT INTEGER,
   psTxResult           OUT VARCHAR2
)
IS
   contador    NUMBER;
   letraSiguiente       CHAR (1);
   vlista      VARCHAR (40);
   vinicia     NUMBER;
   vfinal      NUMBER;
   vcuenta     NUMBER;
   vFolioSeq   VARCHAR (10);

   uno         CHAR (1);
   dos         CHAR (1);
   tres        CHAR (1);
   cuatro      CHAR (1);

   PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
   vlista := '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ0';
   vinicia := NULL;
   vfinal := NULL;
   vcuenta := 0;

   REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL,
                  'SP_GENERA_FOLIO_ELECTRONICO_V2',
                  'Ejecutando',
                  '',
                  'IN');

   SELECT   COUNT ( * ) INTO vcuenta FROM RUG_FOLIO_CONTROL;

   IF vcuenta < 4
   THEN

      DELETE RUG.RUG_FOLIO_CONTROL;

      --Si no tiene letra la tabla empieza con A

      INSERT INTO RUG.RUG_FOLIO_CONTROL (IDFOLIOCONTROL, FECHA, LETRA)
        VALUES   (1, SYSDATE, '0');

      INSERT INTO RUG.RUG_FOLIO_CONTROL (IDFOLIOCONTROL, FECHA, LETRA)
        VALUES   (2, SYSDATE, '0');

      INSERT INTO RUG.RUG_FOLIO_CONTROL (IDFOLIOCONTROL, FECHA, LETRA)
        VALUES   (3, SYSDATE, '0');

      INSERT INTO RUG.RUG_FOLIO_CONTROL (IDFOLIOCONTROL, FECHA, LETRA)
        VALUES   (4, SYSDATE, '0');



   END IF;

       --trae la letra en la que se quedo
       SELECT   NVL (LETRA, '0')
         INTO   uno
         FROM   RUG_FOLIO_CONTROL
        WHERE   IDFOLIOCONTROL = 1
   FOR UPDATE   OF LETRA;



   --Aumenta Letra para la siguiente
   vinicia := INSTR (vlista, uno);
   vfinal := vinicia + 1;

   uno := TRIM (SUBSTR (vlista, vfinal, 1));

   --dbms_output.put_line('letra_siguiente ' || uno);

   UPDATE   RUG_FOLIO_CONTROL
      SET   LETRA = uno
    WHERE   IDFOLIOCONTROL = 1;



   SELECT   NVL (LETRA, '0')
     INTO   dos
     FROM   RUG_FOLIO_CONTROL
    WHERE   IDFOLIOCONTROL = 2 FOR UPDATE   OF LETRA;


   IF (uno = 'Z')
   THEN
      --Aumenta Letra para la siguiente
      vinicia := INSTR (vlista, dos);
      vfinal := vinicia + 1;

      letraSiguiente := TRIM (SUBSTR (vlista, vfinal, 1));

      DBMS_OUTPUT.put_line ('letra_siguiente uno ' || letraSiguiente);

      UPDATE   RUG_FOLIO_CONTROL
         SET   LETRA = letraSiguiente
       WHERE   IDFOLIOCONTROL = 2;


   END IF;

   SELECT   NVL (LETRA, '0')
     INTO   tres
     FROM   RUG_FOLIO_CONTROL
    WHERE   IDFOLIOCONTROL = 3 FOR UPDATE   OF LETRA;

   IF (dos = 'Z' AND uno = 'Z')
   THEN
      --Aumenta Letra para la siguiente
      vinicia := INSTR (vlista, tres);
      vfinal := vinicia + 1;

      letraSiguiente := TRIM (SUBSTR (vlista, vfinal, 1));

      --dbms_output.put_line('letra_siguiente ' || uno);

      UPDATE   RUG_FOLIO_CONTROL
         SET   LETRA = letraSiguiente
       WHERE   IDFOLIOCONTROL = 3;


   END IF;


   SELECT   NVL (LETRA, '0')
     INTO   cuatro
     FROM   RUG_FOLIO_CONTROL
    WHERE   IDFOLIOCONTROL = 4 FOR UPDATE   OF LETRA;

   IF (tres = 'Z' AND dos = 'Z' AND uno = 'Z')
   THEN
      --Aumenta Letra para la siguiente
      vinicia := INSTR (vlista, cuatro);
      vfinal := vinicia + 1;

      letraSiguiente := TRIM (SUBSTR (vlista, vfinal, 1));

      --dbms_output.put_line('letra_siguiente ' || uno);

      UPDATE   RUG_FOLIO_CONTROL
         SET   LETRA = letraSiguiente
       WHERE   IDFOLIOCONTROL = 4;


   END IF;


   vFolioSeq := cuatro || tres || dos || uno;

   psFolioElectronico := 'R' || TO_CHAR (SYSDATE, 'yyyymmdd') || vFolioSeq;



   COMMIT;

   psResult := 0;
   psTxResult := RUG.FN_MENSAJE_ERROR (psResult);

   REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL,
                  'SP_GENERA_FOLIO_ELECTRONICO_V2',
                  'psFolioElectronico',
                  psFolioElectronico,
                  'OUT');
EXCEPTION
   WHEN OTHERS
   THEN
      psResult := 999;
      psTxResult := SUBSTR (SQLCODE || ':' || SQLERRM, 1, 250);

      IF SQLCODE = -8177
      THEN
         psResult := 8177;
      END IF;


      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL,
                     'SP_GENERA_FOLIO_ELECTRONICO_V2',
                     'psFolioElectronico',
                     psFolioElectronico,
                     'OUT');
      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL,
                     'SP_GENERA_FOLIO_ELECTRONICO_V2',
                     'psResult',
                     psResult,
                     'OUT');
      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL,
                     'SP_GENERA_FOLIO_ELECTRONICO_V2',
                     'psTxResult',
                     psTxResult,
                     'OUT');
      DBMS_OUTPUT.PUT_LINE (psTxResult);
      ROLLBACK;
END;
/

