create PROCEDURE         SP_GUARDA_ARCHIVO 
                            (
                                
                                peIdUsuario         IN  NUMBER,
                                peAlgoritmoHash     IN  VARCHAR2,
                                peNombreArchivo     IN  VARCHAR2,
                                peArchivo           IN  BLOB,
                                peTipoArchivo       IN  VARCHAR2,
                                peDescripcion       IN  VARCHAR2,
                                psIdArchivo        OUT  NUMBER,
                                psResult           OUT  INTEGER,   
                                psTxResult         OUT  VARCHAR2                             
                            )
IS


vlIdArchivo     NUMBER;
vlCantidad      NUMBER;
vlResult        VARCHAR2(4000);
Ex_ErrParametro EXCEPTION;

BEGIN

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_GUARDA_ARCHIVO', 'peIdUsuario', peIdUsuario, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_GUARDA_ARCHIVO', 'peAlgoritmoHash', peAlgoritmoHash, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_GUARDA_ARCHIVO', 'peNombreArchivo', peNombreArchivo, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_GUARDA_ARCHIVO', 'peTipoArchivo', peTipoArchivo, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_GUARDA_ARCHIVO', 'peDescripcion', peDescripcion, 'IN');



    BEGIN

        vlCantidad := 0;

        SELECT COUNT(*)
          INTO vlCantidad
          FROM RUG_SECU_USUARIOS
         WHERE ID_PERSONA =  peIdUsuario
           AND SIT_USUARIO = 'AC';           

        IF vlCantidad < 1 THEN
            vlResult := 'El usuario no esta registrado en el sistema';
            RAISE Ex_ErrParametro;
        END IF;

    END;       

    vlIdArchivo := SEQ_ARCHIVOXML.NEXTVAL;


    BEGIN

        INSERT INTO RUG_ARCHIVO(ID_ARCHIVO, ID_USUARIO, ALGORITMO_HASH,  NOMBRE_ARCHIVO, ARCHIVO, TIPO_ARCHIVO, DESCRIPCION, FECHA_REG, STATUS_REG)
        VALUES(vlIdArchivo, peIdUsuario, peAlgoritmoHash, peNombreArchivo, peArchivo, peTipoArchivo, peDescripcion, SYSDATE, 'AC');

    END;

    psIdArchivo:= vlIdArchivo;
    psResult   :=0;        
    psTxResult :='Alta finalizada satisfactoriamente';


    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_GUARDA_ARCHIVO', 'psIdArchivo', psIdArchivo, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_GUARDA_ARCHIVO', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_GUARDA_ARCHIVO', 'psTxResult', psTxResult, 'OUT');


EXCEPTION 
    WHEN Ex_ErrParametro  THEN    
          psResult  := -1;     
          psTxResult:= vlResult;

        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_GUARDA_ARCHIVO', 'psResult', psResult, 'OUT');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_GUARDA_ARCHIVO', 'psTxResult', psTxResult, 'OUT');    


    WHEN OTHERS THEN
        psResult  := 999;   
        psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);

        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_GUARDA_ARCHIVO', 'psResult', psResult, 'OUT');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_GUARDA_ARCHIVO', 'psTxResult', psTxResult, 'OUT');    


END SP_GUARDA_ARCHIVO;
/

