create PROCEDURE         SP_ALTA_TRANSMISION_MASIVA 
(

    peIdTramiteTemp     IN   NUMBER,
    peIdAcreedor        IN   NUMBER,
    peAnotacionJuez     IN   VARCHAR2,
    peIdGarantia        IN   NUMBER,   
    peIdPersona         IN   NUMBER,
    peTipoContratoBasa  IN   VARCHAR2,
    peFechaCelebBasa    IN   DATE,
    peOtrosTerminosBasa IN   CLOB,
    peFechaFinBasa      IN   DATE,
    psResult           OUT   INTEGER,
    psTxResult         OUT   VARCHAR2
)
IS

vlIdTramiteIncompleto       NUMBER;
vlAcreedor                  CHAR(2);
vlIdTipoTramite             NUMBER;

Ex_Error EXCEPTION;

BEGIN

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_TRANSMISION_MASIVA', 'peIdTramiteTemp', peIdTramiteTemp, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_TRANSMISION_MASIVA', 'peAnotacionJuez', peAnotacionJuez, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_TRANSMISION_MASIVA', 'peIdGarantia', peIdGarantia, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_TRANSMISION_MASIVA', 'peIdPersona', peIdPersona, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_TRANSMISION_MASIVA', 'peTipoContratoBasa', peTipoContratoBasa, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_TRANSMISION_MASIVA', 'peFechaCelebBasa', peFechaCelebBasa, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_TRANSMISION_MASIVA', 'peFechaFinBasa', peFechaFinBasa, 'IN');


    BEGIN
        SELECT DECODE(ID_ACREEDOR, peIdAcreedor, 'V', 'F'), ID_TIPO_TRAMITE 
          INTO vlAcreedor, vlIdTipoTramite
          FROM (
                    SELECT ID_ACREEDOR, ID_TIPO_TRAMITE FROM V_TRAMITES_TERMINADOS
                     WHERE ID_GARANTIA = peIdGarantia
                     ORDER BY 1)
         WHERE ROWNUM < 2;

        EXCEPTION WHEN NO_DATA_FOUND THEN
            psResult := 14;
            RAISE Ex_Error;

    END;



    IF(vlAcreedor = 'V') THEN


        SP_ORDEN_AUTORIDAD(peIdTramiteTemp, peAnotacionJuez, psResult, psTxResult);

        IF (psResult = 0) THEN

            SP_MODIFICA_GARANTIA(peIdTramiteTemp, peIdGarantia, NULL, NULL, NULL, peIdPersona, NULL, NULL, NULL, NULL, NULL, NULL, NULL, peTipoContratoBasa, peFechaCelebBasa, peOtrosTerminosBasa,
                                 NULL, peFechaFinBasa, NULL, NULL, psResult, psTxResult);

            IF (psResult = 0) THEN

                SP_Alta_Bitacora_Tramite2(peIdTramiteTemp, 5, 0, NULL, 'V', psResult, psTxResult);

            END IF;

        END IF;            

   ELSE 

        psResult := 60;        
        RAISE Ex_Error;

    END IF;


    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_TRANSMISION_MASIVA', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_TRANSMISION_MASIVA', 'psTxResult', psTxResult, 'OUT');


EXCEPTION


WHEN Ex_Error  THEN

      psTxResult := RUG.FN_MENSAJE_ERROR(psResult);

      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_TRANSMISION_MASIVA', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_TRANSMISION_MASIVA', 'psTxResult', psTxResult, 'OUT');
      ROLLBACK;

WHEN OTHERS THEN
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      ROLLBACK;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_TRANSMISION_MASIVA', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_TRANSMISION_MASIVA', 'psTxResult', psTxResult, 'OUT');

END;
/

