create PROCEDURE     SP_REGISTRO_USUARIO_RUG 
(
      peOperacion               IN VARCHAR2, -- I ALTA, U ACTIVACION
      peNombre                  IN VARCHAR2,
      peApellidoP               IN VARCHAR2,
      peApellidoM               IN VARCHAR2,
      peIdNacionalidad          IN NUMBER,
      peSexo                    IN VARCHAR2,
      peRFC                     IN VARCHAR,
      peCveUsuario              IN VARCHAR2,
      peCveUsuarioPadre         IN VARCHAR2,
      pePassword                IN RUG_SECU_USUARIOS.PASSWORD%TYPE,
      pePregRecupera            IN VARCHAR2,
      peRespRecupera            IN VARCHAR2,
      peCveInstitucion          IN VARCHAR2,
      peCvePerfil               IN VARCHAR2,
      peCveAplicacion           IN VARCHAR2,
      peIdGrupo                 IN VARCHAR2,
      peIdTramiteTemp           IN NUMBER,
      peFechaInicio             IN DATE,
      peFechaFin                IN DATE,
      peOtrosTerm               IN VARCHAR2,
      peTipoContrato            IN NUMBER,
      peIdUsuario               IN NUMBER,
      peIsJudicial              IN VARCHAR2,
      P_TOKEN                   IN RUG_SECU_USUARIOS.TOKEN%TYPE := NULL,
      P_TIPO_PERSONA          	IN VARCHAR,
      P_INSCRITO				IN CHAR,
      P_DOCID					IN VARCHAR,
      psResult                 OUT NUMBER,
      psTxResult               OUT VARCHAR2
)
IS

  --Variables
vlIdPersona         INTEGER;
vlContador          NUMBER;     
vlContador1         NUMBER;
vlPerfil            VARCHAR2(50);
vlCveAcreedor       VARCHAR2(256);
vlTipoTramite       NUMBER;
vlFirmado           CHAR(2);
vlIdContrato        NUMBER;
vlNumPartes         NUMBER;
vlIsJudicial        VARCHAR(1);
Ex_ErrParametro     EXCEPTION;

--VARIABLES VALIDACION RFC
vlPsResultValRFC    NUMBER;
vlPsTxtResultValRFC VARCHAR(4000);
Ex_ErrRFC EXCEPTION;

BEGIN

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'peOperacion', peOperacion, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'peNombre', peNombre, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'peApellidoP', peApellidoP, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'peApellidoM', peApellidoM, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'peIdNacionalidad', peIdNacionalidad, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'peSexo', peSexo, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'peRFC', peRFC, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'peCveUsuario', peCveUsuario, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'peCveUsuarioPadre', peCveUsuarioPadre, 'IN');
    --REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'pePassword', pePassword, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'pePregRecupera', pePregRecupera, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'peRespRecupera', peRespRecupera, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'peCveInstitucion', peCveInstitucion, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'peCvePerfil', peCvePerfil, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'peCveAplicacion', peCveAplicacion, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'peIdGrupo', peIdGrupo, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'peIdTramiteTemp', peIdTramiteTemp, 'IN');    
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'peFechaInicio', peFechaInicio, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'peFechaFin', peFechaFin, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'peOtrosTerm', peOtrosTerm, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'peTipoContrato', peTipoContrato, 'IN');    
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'peIdUsuario', peIdUsuario, 'IN');   
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'peIsJudicial', peIsJudicial, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'P_TOKEN', P_TOKEN, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'P_TIPO_PERSONA', P_TIPO_PERSONA, 'IN');
	REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'P_INSCRITO', P_INSCRITO, 'IN');
	REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'P_DOCID', P_DOCID, 'IN');

    vlFirmado := NULL;


    IF peCveUsuario IS NULL OR TRIM(peCveUsuario) = '' THEN 

        psResult := 5;
        psTxResult  := RUG.FN_MENSAJE_ERROR(psResult);
        RAISE Ex_ErrParametro;

    END IF;


    IF(peIdTramiteTemp IS NOT NULL) THEN

        BEGIN

            SELECT ID_TIPO_TRAMITE
              INTO vlTipoTramite  
            FROM TRAMITES_RUG_INCOMP
            WHERE ID_TRAMITE_TEMP = peIdTramiteTemp;

            IF(vlTipoTramite != 14) THEN
                psResult   := 1;
                psTxResult :='El tipo de tramite no es Alta Usuario';
                RAISE Ex_ErrParametro;
            END IF;

            vlFirmado := 'F'; 

        END;


    END IF;  

    IF (peIdGrupo IS NULL) THEN
        BEGIN

            psResult   := 1;
            psTxResult :='Debe indicar el grupo';
            RAISE Ex_ErrParametro;  

        END;
    END IF;


    vlContador := 0;

    Select count(*) 
    INTO vlContador
    from RUG_SECU_USUARIOS
    WHERE lower(CVE_USUARIO) = lower(peCveUsuario);


    IF(peOperacion = 'I') THEN
        BEGIN


            Select count(*) 
              INTO vlContador1
              from RUG_SECU_PERFILES_USUARIO
             WHERE lower(CVE_USUARIO) = lower(peCveUsuario);      

            IF(vlContador != 0 OR vlContador1 != 0) THEN
                BEGIN
                    psResult   := 1;
                    psTxResult :='El usuario ya existe en el sistema';
                    RAISE Ex_ErrParametro;          
                END;
            END IF;



            IF peIdNacionalidad IS NOT NULL THEN

                SELECT COUNT(*)
                INTO vlContador
                FROM RUG_CAT_NACIONALIDADES
                WHERE ID_NACIONALIDAD = peIdNacionalidad;

                IF vlContador = 0 THEN

                    psResult := 19;
                    psTxResult  := RUG.FN_MENSAJE_ERROR(psResult);
                    RAISE Ex_ErrParametro;

                END IF;

            ELSE

                psResult := 18;
                psTxResult  := RUG.FN_MENSAJE_ERROR(psResult);
                RAISE Ex_ErrParametro;

            END IF;

            SELECT COUNT(*)
              INTO vlContador
              FROM RUG_CAT_PERFILES
             WHERE CVE_PERFIL = UPPER(peCvePerfil);


            IF vlContador < 1 THEN 

                psResult := 118;
                psTxResult  := RUG.FN_MENSAJE_ERROR(psResult);
                RAISE Ex_ErrParametro;            

            END IF;

            IF(peNombre is null OR TRIM(penombre) <> '') THEN

                psResult := 79;    
                psTxResult  := RUG.FN_MENSAJE_ERROR(psResult);
                RAISE Ex_ErrParametro;

            END IF;


            /*IF(peApellidoP is null OR TRIM(peApellidoP) <> '') THEN

                psResult := 80;  
                psTxResult  := RUG.FN_MENSAJE_ERROR(psResult);  
                RAISE Ex_ErrParametro;

            END IF;*/  




            /* SE COMENTA LA VALIDACION DEL RFC PORQUE YA SE VALIDO EN EL FRONTEND
             * RUG.SP_VALIDA_RFC(peIdNacionalidad, peRFC, 'PF', vlPsResultValRFC, vlPsTxtResultValRFC);
            IF vlPsResultValRFC <> 0 THEN
                RAISE Ex_ErrRFC;
            END IF;*/



            IF (peIdGrupo IS NOT NULL) THEN
                BEGIN

                    SELECT COUNT(*)
                      INTO vlContador 
                      FROM RUG_GRUPOS
                     WHERE ID_GRUPO = peIdGrupo
                       AND SIT_GRUPO = 'AC';


                    Dbms_output.put_line('peIdGrupo ' || peIdGrupo); 

                    IF(vlContador = 0) THEN
                        BEGIN
                            psResult   := 1;
                            psTxResult :='No existe el grupo';
                            RAISE Ex_ErrParametro;  

                        END; 
                    END IF;
                END;
            END IF;

           vlCveAcreedor := NULL;

            IF(peIdGrupo = 1) THEN
                BEGIN
                    vlCveAcreedor := lower(peCveUsuario);
                END;

            ELSIF (peIdGrupo = 3) THEN
                BEGIN
                    vlCveAcreedor := lower(peCveUsuarioPadre);
                END;
            ELSE
                BEGIN

                    SELECT CVE_ACREEDOR
                      INTO vlCveAcreedor
                      FROM RUG_SECU_USUARIOS
                     WHERE lower(CVE_USUARIO) = lower(peCveUsuarioPadre);
                     EXCEPTION
                        WHEN OTHERS THEN
                            vlCveAcreedor := NULL;
                END;
            END IF;


            vlIdPersona:= SEQ_RUG_ID_PERSONA.NEXTVAL;

            INSERT INTO RUG_PERSONAS (ID_PERSONA, RFC, ID_NACIONALIDAD, PER_JURIDICA, FH_REGISTRO, PROCEDENCIA, SIT_PERSONA, REG_TERMINADO, INSCRITO, CURP_DOC)
            VALUES   (vlIdPersona, peRFC, peIdNacionalidad, P_TIPO_PERSONA, TRUNC(SYSDATE), 'NAL', 'AC', 'Y', P_INSCRITO, P_DOCID);

            dbms_output.put_line(1); 

            /*IF peIdGrupo = 15 AND P_NUM_SERIE IS NOT NULL THEN

                INSERT INTO RUG_PERSONAS_FISICAS (ID_PERSONA, NOMBRE_PERSONA, SEXO, NUM_SERIE)
                VALUES   (vlIdPersona, peNombre, peSexo, P_NUM_SERIE);

                SP_REGISTRO_HIST_NUM_SERIE(vlIdPersona, P_NUM_SERIE, psResult, psTxResult);

            ELSE*/

                INSERT INTO RUG_PERSONAS_FISICAS (ID_PERSONA, NOMBRE_PERSONA, SEXO, CURP)
                VALUES   (vlIdPersona, peNombre, peSexo, P_DOCID);

            /*END IF;*/

dbms_output.put_line(2);

            INSERT INTO RUG_SECU_USUARIOS (CVE_INSTITUCION, CVE_USUARIO, ID_PERSONA, PASSWORD, F_ASIGNA_PSW, PREG_RECUPERA_PSW, RESP_RECUPERA_PSW, 
                                           FH_REGISTRO, SIT_USUARIO, CVE_USUARIO_PADRE, CVE_ACREEDOR, ID_GRUPO, B_FIRMADO, TOKEN, IS_JUDICIAL)
            VALUES (peCveInstitucion, lower(peCveUsuario), vlIdPersona, LOWER (FNDPSWENCRYPT(pePassword)), SYSDATE, pePregRecupera , peRespRecupera, SYSDATE, 
                    'PA', lower(peCveUsuarioPadre), vlCveAcreedor, peIdGrupo, vlFirmado, P_TOKEN, peIsJudicial);

dbms_output.put_line(3);

            INSERT INTO RUG_SECU_PERFILES_USUARIO (CVE_INSTITUCION, CVE_USUARIO, CVE_PERFIL, CVE_APLICACION, ID_PERSONA, B_BLOQUEADO)
            VALUES   (peCveInstitucion, lower(peCveUsuario), UPPER(peCvePerfil),  peCveAplicacion, vlIdPersona, 'F');

dbms_output.put_line(4);


            IF(vlFirmado = 'F') THEN


                 vlIdContrato := SEQ_CONTRATO.NEXTVAL;


                INSERT INTO RUG_CONTRATO (ID_CONTRATO, FECHA_INICIO, FECHA_FIN, OTROS_TERMINOS_CONTRATO, TIPO_CONTRATO, 
                                    ID_TRAMITE_TEMP, FECHA_REG, STATUS_REG, ID_USUARIO)
                VALUES(vlIdContrato, peFechaInicio, peFechaFin, peOtrosTerm, peTipoContrato, peIdTramiteTemp, SYSDATE, 'AC', peIdUsuario);


                INSERT INTO RUG_REL_TRAM_INC_PARTES
                VALUES (peIdTramiteTemp, vlIdPersona, 5, 'PF', 'AC', SYSDATE);

            END IF;      


            COMMIT;


            psResult  := 0;
            psTxResult := 'Alta Exitosa';                       
        END;
    END IF;

    IF(peOperacion = 'U') THEN
       BEGIN

            IF(vlContador = 0) THEN
                BEGIN
                    psResult   := 1;
                    psTxResult :='El usuario no existe en el sistema';
                    RAISE Ex_ErrParametro;          
                END;
            ELSIF (vlContador > 1) THEN
                BEGIN
                    psResult   := 2;
                    psTxResult :='Existe mas de un usuario con esa clave en el sistema';
                    RAISE Ex_ErrParametro;
                END;
            END IF;      


           SELECT ID_PERSONA, IS_JUDICIAL
           INTO vlIdPersona, vlIsJudicial
           FROM RUG_SECU_USUARIOS
           WHERE lower(CVE_USUARIO) = lower(peCveUsuario);

           UPDATE RUG_SECU_USUARIOS
           SET SIT_USUARIO = 'AC', TOKEN = NULL, FH_ULT_ACTUALIZACION = SYSDATE
           WHERE lower(CVE_USUARIO) = lower(peCveUsuario)
           AND SIT_USUARIO = 'IN';

           INSERT INTO REL_USU_ACREEDOR
           VALUES (vlIdPersona, vlIdPersona, 'Y', SYSDATE, 'AC');

           IF vlIsJudicial = '1' THEN /** ES ORGANISMO JUDICIAL **/
                INSERT INTO RUG_REL_GRUPO_ACREEDOR
                VALUES(SEQ_RUG_REL_PRIVILEGIO_ACREEDO.NEXTVAL, vlIdPersona, vlIdPersona, vlIdPersona, 'AC', SYSDATE, '12') ;
           ELSE  
                INSERT INTO RUG_REL_GRUPO_ACREEDOR
                VALUES(SEQ_RUG_REL_PRIVILEGIO_ACREEDO.NEXTVAL, vlIdPersona, vlIdPersona, vlIdPersona, 'AC', SYSDATE, '1') ;
           END IF;

           psResult  := 0;
           psTxResult := 'Activacion Exitosa'; 

       END;
    END IF;

    COMMIT;     

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'psTxResult', psTxResult, 'OUT');    


EXCEPTION
WHEN Ex_ErrRFC  THEN
      psResult := vlPsResultValRFC;
      psTxResult := vlPsTxtResultValRFC;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'psTxResult', psTxResult, 'OUT');
      ROLLBACK;
WHEN Ex_ErrParametro THEN
     REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'psResult', psResult, 'OUT');
     REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'psTxResult', psTxResult, 'OUT');
     ROLLBACK;    
WHEN OTHERS THEN
     psResult  := 999;   
     psTxResult:= 'Error en el proceso ' || SQLERRM;
     REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'psResult', psResult, 'OUT');
     REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'psTxResult', psTxResult, 'OUT');
     ROLLBACK;    
END SP_REGISTRO_USUARIO_RUG;
/

