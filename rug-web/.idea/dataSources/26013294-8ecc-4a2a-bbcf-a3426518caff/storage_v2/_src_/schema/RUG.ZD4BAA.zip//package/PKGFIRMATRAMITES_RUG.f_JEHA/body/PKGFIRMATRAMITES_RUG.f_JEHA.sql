create PACKAGE BODY     PKGFIRMATRAMITES_RUG AS
/******************************************************************************
   NAME:       PKGFIRMATRAMITES_RUG
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        28/10/2009             1. Created this package body.
******************************************************************************/

--******************************************************************************/
--*Nombre:   IniTramiteXMLFir
--*Objetivo: Procedimiento que inserta la informacion para generar el tramite del SIGER
--*Modifico:  Ernesto Diaz Sanchez de Tagle
--*Fecha Elaboracion: 19-JULIO-2010
--*Ulltima Revision:
--******************************************************************************/

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
--                   P R O C E D I M I E N T O S                             --
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------


PROCEDURE ActDoctoTramFir( peIdTramiteTemp              IN   DOCTOS_TRAM_FIRMADOS_RUG.ID_TRAMITE_TEMP%TYPE,
                           peCadenaOriginalNoFirmada    IN   DOCTOS_TRAM_FIRMADOS_RUG.CADENA_ORIG_NO_FIRMADA%TYPE,
                           peCadenaOriginalFirmada      IN   DOCTOS_TRAM_FIRMADOS_RUG.CADENA_ORIG_FIRMADA%TYPE,
                           peCadenaOrigFirmadaSE        IN   DOCTOS_TRAM_FIRMADOS_RUG.CADENA_ORIG_FIRMADA_SE%TYPE,
                           peTimeStampSE                IN   DOCTOS_TRAM_FIRMADOS_RUG.TIMESTAMP_SE%TYPE,                           
                           --peFechaCreacion              IN DOCTOS_TRAM_FIRMADOS_RUG.FH_REGISTRO%TYPE,
                           peBcommit                IN   VARCHAR2,
                           psResult                 OUT  INTEGER,
                           psTxResult               OUT  VARCHAR2)
IS

 CURSOR CurObtEmpDoctoTram(cpeIdTramiteTemp        IN  DOCTOS_TRAM_FIRMADOS_RUG.ID_TRAMITE_TEMP%TYPE)
 IS
   SELECT 'V' B_Existe
     FROM DOCTOS_TRAM_FIRMADOS_RUG
    WHERE ID_TRAMITE_TEMP  = cpeIdTramiteTemp;

 /*vlContenidoDocto           EMP_DOCTOS_TRAMITE.CONTENIDO_DOCTO%TYPE;
 vlNomArchivo               EMP_DOCTOS_TRAMITE.NOM_ARCHIVO%TYPE;
 vlIdTipoFormato            EMP_DOCTOS_TRAMITE.ID_TIPO_FORMATO%TYPE;
 vlFhUltActualizacion       EMP_DOCTOS_TRAMITE.FH_ULT_ACTUALIZACION%TYPE;
 vlDescTipoDocto            SE_CAT_TIPOS_DOCTO.DESC_TIPO_DOCTO%TYPE;*/
 vlResult                   INTEGER;
 vlTxResult                 VARCHAR2(250);
 vlBExiste                  VARCHAR2(1);
 vlPsName                   VARCHAR2(200);

 Ex_ErrParametro            EXCEPTION;
 Ex_ErrOperTran             EXCEPTION;


BEGIN
 psResult  := 999;
 psTxResult:= 'Error General';
 vlPsName  := 'ActDoctoTramFir';

 vlResult   := 0;
 vlTxResult := '';
 vlBExiste  := coFalso;

 REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'ActDoctoTramFir', 'peIdTramiteTemp', peIdTramiteTemp, 'IN');


   dbms_output.put_line('PASO UNO');
 -- Se valida si el registro ya existe --+
 IF (peIdTramiteTemp IS NOT NULL) THEN
     OPEN CurObtEmpDoctoTram(peIdTramiteTemp);
     FETCH CurObtEmpDoctoTram INTO vlBExiste;
     CLOSE CurObtEmpDoctoTram;
 END IF;
dbms_output.put_line('PASO DOS');
 IF (NVL(vlBExiste,coFalso)= coVerdadero) THEN

     BEGIN
       UPDATE DOCTOS_TRAM_FIRMADOS_RUG
          SET CADENA_ORIG_FIRMADA = NVL(peCadenaOriginalFirmada,CADENA_ORIG_FIRMADA),
              CADENA_ORIG_NO_FIRMADA = NVL(peCadenaOriginalNoFirmada,CADENA_ORIG_NO_FIRMADA) ,
              CADENA_ORIG_FIRMADA_SE = peCadenaOrigFirmadaSE,
              TIMESTAMP_SE = peTimeStampSE,
              FH_ULT_ACTUALIZACION = SYSDATE
        WHERE ID_TRAMITE_TEMP  = peIdTramiteTemp;
     EXCEPTION
      WHEN OTHERS THEN
        vlTxResult:= 'Error al actualizar el documento ';
        RAISE Ex_ErrOperTran;
     END;
dbms_output.put_line('ENTRA AL UPDATE');
 ELSE

    dbms_output.put_line('voy a insertar el documento');
     BEGIN
        INSERT INTO DOCTOS_TRAM_FIRMADOS_RUG ( ID_TRAMITE_TEMP,
                               CADENA_ORIG_FIRMADA ,
                               FH_REGISTRO,
                               CADENA_ORIG_NO_FIRMADA,
                               CADENA_ORIG_FIRMADA_SE,
                               TIMESTAMP_SE )
                      VALUES ( peIdTramiteTemp,
                               peCadenaOriginalFirmada,
                               SYSDATE,
                               peCadenaOriginalNoFirmada,
                               peCadenaOrigFirmadaSE,
                               peTimeStampSE
                               );
      dbms_output.put_line('ENTRA AL INSERT');                               
     EXCEPTION
      WHEN OTHERS THEN
        vlTxResult:= SUBSTR('Error al Insertar el documento '||'-'||SQLERRM, 1, 250);
        RAISE Ex_ErrOperTran;
        dbms_output.put_line('el error es '||vlTxResult||' ');
     END;
    dbms_output.put_line('ya inserto');
dbms_output.put_line('PASO TRES');   
        begin

         REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Bitacora_Tramite2', 'ANTES DE ENTRAR', '0', 'IN');
        dbms_output.put_line('PASO CUATRO'); 
         SP_Alta_Bitacora_Tramite2(peIdTramiteTemp, 3, 0, NULL, 'V', vlResult, vlTxResult);
        dbms_output.put_line('PASO CINCO'); 
         REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Bitacora_Tramite2', 'AL SALIR', '0', 'IN');

        end;
 END IF;


 IF peBCOMMIT = coVerdadero THEN COMMIT; END IF;

 psResult  := 0;
 psTxResult:= '';

EXCEPTION
WHEN Ex_ErrParametro THEN
   psResult  := 1;
   psTxResult:= SUBSTR(vlPsName||':'||vlTxResult,1,250);
   IF peBCOMMIT = coVerdadero THEN ROLLBACK; END IF;
WHEN Ex_ErrOperTran THEN
   psResult  := 5;
   psTxResult:= SUBSTR(vlPsName||':'||vlTxResult,1,250);
   IF peBCOMMIT = coVerdadero THEN ROLLBACK; END IF;
WHEN OTHERS THEN

   psResult  := 5;
   psTxResult:= SUBSTR(vlPsName||SQLCODE||':'||SQLERRM,1,250);
   IF peBCOMMIT = coVerdadero THEN ROLLBACK; END IF;
END ActDoctoTramFir;


PROCEDURE ActDoctoTramFirTsp( peIdTramiteTemp               IN   DOCTOS_TRAM_FIRMADOS_RUG.ID_TRAMITE_TEMP%TYPE,
                           peCadenaOriginalNoFirmada        IN   DOCTOS_TRAM_FIRMADOS_RUG.CADENA_ORIG_NO_FIRMADA%TYPE,
                           peCadenaOriginalFirmada          IN   DOCTOS_TRAM_FIRMADOS_RUG.CADENA_ORIG_FIRMADA%TYPE,
                           peCadenaOrigFirmadaSE            IN   DOCTOS_TRAM_FIRMADOS_RUG.CADENA_ORIG_FIRMADA_SE%TYPE,
                           peTimeStampSE                    IN   DOCTOS_TRAM_FIRMADOS_RUG.TIMESTAMP_SE%TYPE,
                           peFechaCreacion                  IN   VARCHAR2,
                           peUsuarioFirmo                   IN   DOCTOS_TRAM_FIRMADOS_RUG.ID_USUARIO_FIRMO%TYPE,
                           peBcommit                IN   VARCHAR2,
                           psResult                 OUT  INTEGER,
                           psTxResult               OUT  VARCHAR2)
IS

 CURSOR CurObtEmpDoctoTram(cpeIdTramiteTemp        IN  DOCTOS_TRAM_FIRMADOS_RUG.ID_TRAMITE_TEMP%TYPE)
 IS
   SELECT 'V' B_Existe
     FROM DOCTOS_TRAM_FIRMADOS_RUG
    WHERE ID_TRAMITE_TEMP  = cpeIdTramiteTemp;

 vlContenidoDocto           EMP_DOCTOS_TRAMITE.CONTENIDO_DOCTO%TYPE;
 vlNomArchivo               EMP_DOCTOS_TRAMITE.NOM_ARCHIVO%TYPE;
 vlIdTipoFormato            EMP_DOCTOS_TRAMITE.ID_TIPO_FORMATO%TYPE;
 vlFhUltActualizacion       EMP_DOCTOS_TRAMITE.FH_ULT_ACTUALIZACION%TYPE;
 vlDescTipoDocto            SE_CAT_TIPOS_DOCTO.DESC_TIPO_DOCTO%TYPE;
 vlResult                   INTEGER;
 vlTxResult                 VARCHAR2(250);
 vlBExiste                  VARCHAR2(1);
 vlPsName                   VARCHAR2(200);
 vlTipoTramite              NUMBER;
 vlCantidad                 NUMBER;

 Ex_ErrParametro            EXCEPTION;
 Ex_ErrOperTran             EXCEPTION;


BEGIN
 psResult  := 999;
 psTxResult:= 'Error General';
 vlPsName  := 'ActDoctoTramFir';

 vlResult   := 0;
 vlTxResult := '';
 vlBExiste  := coFalso;

 REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'ActDoctoTramFirPrueba', 'peIdTramiteTemp', peIdTramiteTemp, 'IN');
 REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'ActDoctoTramFirPrueba', 'peFechaCreacion', peFechaCreacion, 'IN');

 dbms_output.put_line('PASO UNO');
 dbms_output.put_line('FECHA MIGUEL' || peFechaCreacion);

 SELECT COUNT(*)
   INTO vlCantidad
   FROM TRAMITES_RUG_INCOMP
  WHERE ID_TRAMITE_TEMP = peIdTramiteTemp;

 IF (vlCantidad = 0) THEN

    vlTxResult := 'El tramite no existe'; 
    RAISE Ex_ErrParametro;

 END IF;


 dbms_output.put_line('PASO DOS');
 -- Se valida si el registro ya existe --+
 IF (peIdTramiteTemp IS NOT NULL) THEN
     OPEN CurObtEmpDoctoTram(peIdTramiteTemp);
     FETCH CurObtEmpDoctoTram INTO vlBExiste;
     CLOSE CurObtEmpDoctoTram;
 END IF;
dbms_output.put_line('PASO TRES');
 IF (NVL(vlBExiste,coFalso)= coVerdadero) THEN

     BEGIN
       UPDATE DOCTOS_TRAM_FIRMADOS_RUG
          SET CADENA_ORIG_FIRMADA = NVL(peCadenaOriginalFirmada,CADENA_ORIG_FIRMADA),
              CADENA_ORIG_NO_FIRMADA = NVL(peCadenaOriginalNoFirmada,CADENA_ORIG_NO_FIRMADA) ,
              CADENA_ORIG_FIRMADA_SE = peCadenaOrigFirmadaSE,
              TIMESTAMP_SE = peTimeStampSE,
              FH_ULT_ACTUALIZACION = SYSDATE,
              ID_USUARIO_FIRMO = peUsuarioFirmo
        WHERE ID_TRAMITE_TEMP  = peIdTramiteTemp;
     EXCEPTION
      WHEN OTHERS THEN
        vlTxResult:= 'Error al actualizar el documento '||vlDescTipoDocto;
        RAISE Ex_ErrOperTran;
     END;
dbms_output.put_line('PASO UPDATE');
 ELSE

    dbms_output.put_line('voy a insertar el documento');
     BEGIN

        SELECT ID_TIPO_TRAMITE
          INTO vlTipoTramite
          FROM TRAMITES_RUG_INCOMP
         WHERE ID_TRAMITE_TEMP = peIdTramiteTemp;


        IF (vlTipoTramite = 5) THEN

            INSERT INTO DOCTOS_TRAM_FIRMADOS_RUG ( ID_TRAMITE_TEMP,                                   
                                   FH_REGISTRO,                                   
                                   CADENA_ORIG_FIRMADA_SE,
                                   TIMESTAMP_SE,
                                   ID_USUARIO_FIRMO)
                          VALUES ( peIdTramiteTemp,                                   
                                   SYSDATE,                                   
                                   peCadenaOrigFirmadaSE,
                                   peTimeStampSE,
                                   peUsuarioFirmo);
                                   dbms_output.put_line('PASO INSERT');

        ELSE  

            INSERT INTO DOCTOS_TRAM_FIRMADOS_RUG ( ID_TRAMITE_TEMP,
                                   CADENA_ORIG_FIRMADA ,
                                   FH_REGISTRO,
                                   CADENA_ORIG_NO_FIRMADA,
                                   CADENA_ORIG_FIRMADA_SE,
                                   TIMESTAMP_SE,
                                   ID_USUARIO_FIRMO)
                          VALUES ( peIdTramiteTemp,
                                   peCadenaOriginalFirmada,
                                   SYSDATE,
                                   peCadenaOriginalNoFirmada,
                                   peCadenaOrigFirmadaSE,
                                   peTimeStampSE,
                                   peUsuarioFirmo);
                                   dbms_output.put_line('PASO INSERT');
        END IF;

     EXCEPTION
      WHEN OTHERS THEN
        vlTxResult:= SUBSTR('Error al Insertar el documento '||vlDescTipoDocto||'-'||SQLERRM, 1, 250);
        RAISE Ex_ErrOperTran;
        dbms_output.put_line('el error es '||vlTxResult||' '||vlDescTipoDocto);
     END;
    dbms_output.put_line('ya inserto');
 END IF;

  begin

         REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Bitacora_Tramite2', 'ANTES DE ENTRAR', '0', 'IN');

         SP_Alta_Bitacora_Tramite2(peIdTramiteTemp, 3, 0, NULL, 'V', vlResult, vlTxResult);

         SP_Alta_Bitacora_Tramite2(peIdTramiteTemp, 3, 100,  TO_DATE (peFechaCreacion, 'DD/MM/YYYY - HH24:MI:SS'), 'F', vlResult, vlTxResult);

         REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Bitacora_Tramite2', 'AL SALIR', '0', 'IN');

        end;

 IF peBCOMMIT = coVerdadero THEN COMMIT; END IF;
dbms_output.put_line('PASO COMMIT');
 psResult  := 0;
 psTxResult:= '';

EXCEPTION
WHEN Ex_ErrParametro THEN
   psResult  := 1;
   psTxResult:= SUBSTR(vlPsName||':'||vlTxResult,1,250);
   IF peBCOMMIT = coVerdadero THEN ROLLBACK; END IF;
WHEN Ex_ErrOperTran THEN
   psResult  := 5;
   psTxResult:= SUBSTR(vlPsName||':'||vlTxResult,1,250);
   IF peBCOMMIT = coVerdadero THEN ROLLBACK; END IF;
WHEN OTHERS THEN
   psResult  := 5;
   psTxResult:= SUBSTR(vlPsName||SQLCODE||':'||SQLERRM,1,250);
   dbms_output.put_line(psTxResult);
   IF peBCOMMIT = coVerdadero THEN ROLLBACK; END IF;
END ActDoctoTramFirTsp;





END PKGFIRMATRAMITES_RUG;
/

