create view V_GARANTIA_PARTES as
SELECT
             RRP.ID_TRAMITE
           , RRG.ID_GARANTIA
           , RRP.ID_PERSONA
           , RRP.ID_PARTE
           , RGP.DESC_PARTE
           , RRP.PER_JURIDICA
           , DECODE ( RRP.PER_JURIDICA, 'PF', (
                    SELECT
                           NOMBRE_PERSONA
                                  || ' '
                                  || AP_PATERNO
                                  || ' '
                                  || AP_MATERNO
                    FROM
                           RUG_PERSONAS_FISICAS
                    WHERE
                           ID_PERSONA = RRP.ID_PERSONA
             )
             , 'PM', (
                    SELECT
                           RAZON_SOCIAL
                    FROM
                           RUG_PERSONAS_MORALES
                    WHERE
                           ID_PERSONA = RRP.ID_PERSONA
             )
             ) AS NOMBRE
           , PER.E_MAIL
           , RT.CLAVE_PAIS
           , RT.TELEFONO
           , RT.EXTENSION
           , PER.FOLIO_MERCANTIL
           , PER.RFC
           , DECODE ( RRP.PER_JURIDICA, 'PF', (
                    SELECT 
                           CURP                           
                    FROM
                           RUG_PERSONAS_FISICAS
                    WHERE
                           ID_PERSONA = RRP.ID_PERSONA
             )
             , 'PM', NULL
             ) AS CURP
           , DE.UBICA_DOMICILIO_1  
           , PER.ID_NACIONALIDAD
           , DECODE ( RRP.PER_JURIDICA, 'PM', (
                    SELECT 
                           NUM_INSCRITA                           
                    FROM
                           RUG_PERSONAS_MORALES
                    WHERE
                           ID_PERSONA = RRP.ID_PERSONA
             )
             , 'PF', NULL
             ) AS NUM_INSCRITA
  FROM
             RUG_REL_TRAM_PARTES RRP
             INNER JOIN
                        RUG_PERSONAS PER
                        ON
                                   RRP.ID_PERSONA = PER.ID_PERSONA
             LEFT JOIN
                        RUG_TELEFONOS RT
                        ON
                                   PER.ID_PERSONA = RT.ID_PERSONA
             LEFT JOIN
                        RUG_DOMICILIOS_EXT DE
                        ON
                                   PER.ID_DOMICILIO = DE.ID_DOMICILIO
             INNER JOIN
                        RUG_PARTES RGP
                        ON
                                   RGP.ID_PARTE = RRP.ID_PARTE
             INNER JOIN
                        RUG_REL_TRAM_GARAN RRG
                        ON
                                   RRP.ID_TRAMITE = RRG.ID_TRAMITE
             INNER JOIN
                        RUG_GARANTIAS RGG
                        ON
                                   RGG.ID_GARANTIA = RRG.ID_GARANTIA
  WHERE
             RRP.STATUS_REG      = 'AC'
/

