create PROCEDURE           SP_ALTA_CANCELACION 
                            (
                                peIdTramiteTemp      IN  RUG_REL_TRAM_INC_GARAN.ID_TRAMITE_TEMP%TYPE,--  IDENTIFICADOR DEL TRAMITE ASOCIADO A LA GARANTIA
                                peIdGarantia         IN  NUMBER, --Id de la Garantia a Modificar    
                                peObservaciones      IN  VARCHAR,  --Informacion de la cancelacion
                                psResult            OUT  INTEGER,   
                                psTxResult          OUT  VARCHAR2                             
                            )
IS

vlGaranStatus           CHAR(2);
vlIdGarantiaPend        NUMBER; 
Ex_ErrParametro         EXCEPTION;
vlTipoGarantiaAnterior  NUMBER;
vlIdGarantiaPendAnterior NUMBER;
vsIdUltimoTramite NUMBER;
vsResult INTEGER;
vsTxResult VARCHAR(200);

   CURSOR cursPartes(cpeIdGarantia IN NUMBER) IS   
   SELECT RPP.ID_PERSONA, RPP.ID_PARTE, RGG.PER_JURIDICA
   FROM RUG_REL_GARANTIA_PARTES RPP
   INNER JOIN RUG_PERSONAS RGG
   ON RPP.ID_PERSONA = RGG.ID_PERSONA
   INNER JOIN RUG_GARANTIAS RGT
   ON RPP.ID_RELACION = RGT.ID_RELACION
   WHERE RPP.ID_GARANTIA = cpeIdGarantia;
   cursPartes_Rec cursPartes%ROWTYPE;

BEGIN

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCELACION', 'peIdTramiteTemp', peIdTramiteTemp, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCELACION', 'peIdGarantia', peIdGarantia, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCELACION', 'peObservaciones', peObservaciones, 'IN');

        SELECT ID_TIPO_GARANTIA, ID_GARANTIA_PEND
        INTO vlTipoGarantiaAnterior, vlIdGarantiaPendAnterior
        FROM RUG_GARANTIAS
        WHERE ID_GARANTIA = peIdGarantia;

        SELECT DECODE(ID_TIPO_TRAMITE, 21, 'FV', 'CA')
          INTO vlGaranStatus
          FROM TRAMITES_RUG_INCOMP
         WHERE ID_TRAMITE_TEMP = peIdTramiteTemp;

        vlIdGarantiaPend := SEQ_GARANTIAS_TEMP.NEXTVAL; 

        INSERT INTO RUG_GARANTIAS_PENDIENTES(ID_GARANTIA_PEND, ID_TIPO_GARANTIA, GARANTIA_STATUS, ID_GARANTIA_MODIFICAR)
        VALUES(vlIdGarantiaPend, vlTipoGarantiaAnterior, vlGaranStatus, peIdGarantia);

        SELECT MAX(ID_ULTIMO_TRAMITE)
        INTO vsIdUltimoTramite
        FROM RUG_GARANTIAS_H
        WHERE ID_GARANTIA = peIdGarantia;

        SP_ALTA_BIEN_INCOMPLETO(peIdTramiteTemp,vsIdUltimoTramite,vsResult,vsTxResult);

        IF vsResult <> 0 THEN
            psResult := 74;
            RAISE Ex_ErrParametro;
        END IF;

        --INSERTO RELACION DE PARTES QUE TENIA LA GARANTIA A ESTE NUEVO TRAMITE 
            BEGIN
            FOR cursPartes_Rec IN cursPartes(peIdGarantia)
                LOOP
                INSERT INTO RUG_REL_TRAM_INC_PARTES
                VALUES(peIdTramiteTemp, cursPartes_Rec.ID_PERSONA, cursPartes_Rec.ID_PARTE, cursPartes_Rec.PER_JURIDICA, 'AC', SYSDATE);
                END LOOP;
            END;

         -- INSERTO LOS CONTRATOS QUE TENIA ESTA GARANTIA PARA CONSISTENCIA EN DETALLE
         INSERT INTO RUG_CONTRATO
         SELECT SEQ_CONTRATO.NEXTVAL, vlIdGarantiaPend, CONTRATO_NUM, FECHA_INICIO, FECHA_FIN, OTROS_TERMINOS_CONTRATO, MONTO_LIMITE, peObservaciones, TIPO_CONTRATO, peIdTramiteTemp, SYSDATE, 'AC', ID_USUARIO, CLASIF_CONTRATO
         FROM RUG_CONTRATO
         WHERE ID_GARANTIA_PEND = vlIdGarantiaPendAnterior;

        INSERT INTO RUG_REL_TRAM_INC_GARAN
        VALUES(vlIdGarantiaPend, peIdTramiteTemp, 'AC', SYSDATE);

        COMMIT;

  psResult   :=0;        
  psTxResult :='Actualizacion finalizada satisfactoriamente';

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCELACION', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCELACION', 'psTxResult', psTxResult, 'OUT');    


EXCEPTION 
  WHEN Ex_ErrParametro  THEN         
      psTxResult:= substr(psResult,1,250);
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCELACION', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCELACION', 'psTxResult', psTxResult, 'OUT');    


   WHEN OTHERS THEN
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCELACION', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCELACION', 'psTxResult', psTxResult, 'OUT');    

END SP_ALTA_CANCELACION;
/

