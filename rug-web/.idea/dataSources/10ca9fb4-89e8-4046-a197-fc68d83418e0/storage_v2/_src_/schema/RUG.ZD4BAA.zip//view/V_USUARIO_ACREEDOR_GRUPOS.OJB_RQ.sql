create view V_USUARIO_ACREEDOR_GRUPOS as
SELECT   RRGA.ID_ACREEDOR,
              RRGA.ID_SUB_USUARIO,
              RSPU.CVE_PERFIL,
              RSU.CVE_USUARIO,
              RRGA.ID_GRUPO,
              RRGP.ID_PRIVILEGIO,
              RP.DESC_PRIVILEGIO,
              RP.HTML,
              RP.ID_RECURSO,
              RP.ORDEN,
              RSU.SIT_USUARIO,
              CASE
                 WHEN RRGP.ID_PRIVILEGIO IN (11, 12, 13, 15, 18) THEN 0
                 ELSE 1
              END
                 VISIBLES,
              DECODE (
                 RPP.PER_JURIDICA,
                 'PF',
                 (SELECT      F.NOMBRE_PERSONA
                           || ' '
                           || F.AP_PATERNO
                           || ' '
                           || F.AP_MATERNO
                    FROM   RUG_PERSONAS_FISICAS F
                   WHERE   F.ID_PERSONA = RPP.ID_PERSONA),
                 'PM',
                 (SELECT   M.RAZON_SOCIAL
                    FROM   RUG_PERSONAS_MORALES M
                   WHERE   M.ID_PERSONA = RPP.ID_PERSONA)
              )
                 NOMBRE_ACREEDOR
       FROM   RUG_SECU_USUARIOS RSU,
              RUG_GRUPOS RG,
              RUG_PRIVILEGIOS RP,
              RUG_REL_GRUPO_PRIVILEGIO RRGP,
              RUG_REL_GRUPO_ACREEDOR RRGA,
              RUG_PERSONAS RPP,
              RUG_SECU_PERFILES_USUARIO RSPU,
              REL_USU_ACREEDOR RUA
      WHERE       RSPU.ID_PERSONA = RSU.ID_PERSONA
              AND RUA.ID_USUARIO = RSU.ID_PERSONA
              AND RUA.ID_ACREEDOR = RRGA.ID_ACREEDOR
              AND RUA.B_FIRMADO = 'Y'
              AND RSU.ID_PERSONA = RRGA.ID_SUB_USUARIO
              AND RG.ID_GRUPO = RRGP.ID_GRUPO
              AND RP.ID_PRIVILEGIO = RRGP.ID_PRIVILEGIO
              AND RRGA.ID_GRUPO = RRGP.ID_GRUPO
              AND RPP.ID_PERSONA = RRGA.ID_ACREEDOR
              AND RRGA.STATUS_REG = 'AC'
              AND RRGP.SIT_RELACION = 'AC'
              AND RRGP.ID_PRIVILEGIO NOT IN (25, 31)
   ORDER BY   ID_ACREEDOR, ID_GRUPO, ID_PRIVILEGIO
/

