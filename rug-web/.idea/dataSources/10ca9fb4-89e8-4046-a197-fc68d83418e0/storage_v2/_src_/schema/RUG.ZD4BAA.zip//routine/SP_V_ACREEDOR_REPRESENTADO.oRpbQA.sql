create PROCEDURE           SP_V_ACREEDOR_REPRESENTADO 
                            (
  perIdGarantia         IN RUG_REL_GARANTIA_PARTES.ID_GARANTIA%TYPE,
  perIdPersona          OUT RUG_PERSONAS.ID_PERSONA%TYPE,
  perNombre             OUT RUG_PERSONAS_MORALES.RAZON_SOCIAL%TYPE,
  psResult              OUT    INTEGER,
  psTxResult            OUT  VARCHAR2
                            )
IS
vlIdRegPago   NUMBER;
vlIdPersona   NUMBER;
vlIdTipoTramite   NUMBER;

BEGIN
   SELECT
         a.ID_PERSONA,
         DECODE (
               b.PER_JURIDICA,
               'PF',
               (SELECT      NOMBRE_PERSONA
                         || ' '
                         || AP_PATERNO
                         || ' '
                         || AP_MATERNO
                  FROM   RUG_PERSONAS_FISICAS
                 WHERE   ID_PERSONA = a.ID_PERSONA),
               'PM',
               (SELECT   RAZON_SOCIAL
                  FROM   RUG_PERSONAS_MORALES
                 WHERE   ID_PERSONA = a.ID_PERSONA)
            )
               AS NOMBRE_ACREEDOR
     into perIdPersona,perNombre
     FROM
          RUG_REL_GARANTIA_PARTES a,
          RUG_PERSONAS B
     WHERE
          a.ID_PERSONA= b.ID_PERSONA AND
          a.id_parte=4 AND
          a.ID_GARANTIA=perIdGarantia;

    DBMS_OUTPUT.PUT_LINE('id de la persona:' || perIdPersona || ' Nombre:' || perNombre);

  psResult   :=0;
  psTxResult :='Consulta satisfactoria';

END;
/

