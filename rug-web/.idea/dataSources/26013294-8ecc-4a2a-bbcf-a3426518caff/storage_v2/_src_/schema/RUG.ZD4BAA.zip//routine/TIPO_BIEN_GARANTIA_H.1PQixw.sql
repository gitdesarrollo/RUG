create FUNCTION         TIPO_BIEN_GARANTIA_H (
                                                   peIdGarantia     RUG_GARANTIAS.ID_GARANTIA%TYPE,
                                                   peIdTramite      RUG_GARANTIAS.ID_ULTIMO_TRAMITE%TYPE,
                                                   peLongitud       NUMBER --CANTIDAD  DE CARACTERES A DEVOLVER
                                                   )
RETURN VARCHAR2 

IS
    vlTipoBienes VARCHAR2(500);
    vlDescError VARCHAR2(200);
    vlLongitudCadena number;

    CURSOR cursGarantia IS
    SELECT RGG.ID_GARANTIA, RGN.DESC_TIPO_BIEN
    FROM RUG_GARANTIAS_H RGG
    INNER JOIN RUG_REL_GAR_TIPO_BIEN RGT
    ON RGG.RELACION_BIEN = RGT.RELACION_BIEN
    AND RGG.ID_GARANTIA_PEND = RGT.ID_GARANTIA_PEND
    INNER JOIN RUG_CAT_TIPO_BIEN RGN
    ON RGT.ID_TIPO_BIEN = RGN.ID_TIPO_BIEN
    WHERE RGG.ID_GARANTIA = peIdGarantia
    AND RGG.ID_ULTIMO_TRAMITE = peIdTramite;

    vlIdGarania RUG_GARANTIAS.ID_GARANTIA%TYPE;
    vlDescTipoBien RUG_CAT_TIPO_BIEN.DESC_TIPO_BIEN%TYPE;

BEGIN


   BEGIN
      --select INITCAP(desc_codigo) into vlDescError
       BEGIN

       ------Dbms_output.put_line(1);

       OPEN cursGarantia;

       LOOP FETCH cursGarantia INTO vlIdGarania, vlDescTipoBien;
       EXIT WHEN cursGarantia%NOTFOUND;

       vlTipoBienes :=  vlDescTipoBien || '. ' || vlTipoBienes;

       END LOOP;

       CLOSE cursGarantia;

       IF peLongitud <> 0 THEN

           vlLongitudCadena := LENGTH(vlTipoBienes);

           IF vlLongitudCadena > 85 THEN

           vlTipoBienes := SUBSTR(vlTipoBienes, 0, 85);
           vlTipoBienes := vlTipoBienes || '...';

           END IF;

       END IF;

       vlTipoBienes:= NVL(vlTipoBienes, '   '); 

       ------ Dbms_output.put_line(vlTipoBienes);

       END;


      EXCEPTION WHEN NO_DATA_FOUND THEN
            vlDescError := 'No se encontro el la garantia solicitada';            
            SP_LOG('FunObtMsgErr',14||' - '||SUBSTR(SQLCODE||'-'||SQLERRM,1,1000));
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'Tipo_Bien_Garantia_H', 'vlTipoBienes', vlDescError, 'OUT');
   END;



--   IF(substr(vlTipoBienes, length(trim(vlTipoBienes)),1) = ',' ) THEN
--   
--        vlTipoBienes := substr(vlTipoBienes, 0, length(trim(vlTipoBienes)) - 1);
--   
--   END IF;


   REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'Tipo_Bien_Garantia_H', 'vlTipoBienes', vlTipoBienes, 'OUT');



   RETURN vlTipoBienes;


EXCEPTION
   WHEN OTHERS THEN
      RETURN NULL;
      SP_LOG('FunObtMsgErr',SUBSTR(SQLCODE||'-'||SQLERRM,1,1000));

END;
/

