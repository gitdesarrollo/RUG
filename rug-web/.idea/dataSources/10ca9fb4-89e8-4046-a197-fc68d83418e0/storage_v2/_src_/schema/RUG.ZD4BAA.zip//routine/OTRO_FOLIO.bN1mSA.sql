create PROCEDURE           OTRO_FOLIO (
                            perIdPersona        IN NUMBER,
                            psResult            OUT  INTEGER,
                            psTxResult          OUT  VARCHAR2 
)IS  
  vfolior varchar(15);
  vfecha  varchar(8);
  vultimo varchar(15);
  contador NUMBER;
  letra varchar(4);
  vfechafolio varchar(8);
  vlastfolio varchar(4);
  vlista varchar(30);
  vinicia NUMBER;
  vfinal NUMBER;
  vletra2 varchar(4);
  vcuenta NUMBER;
  vresultado varchar(15);
  vletrasiguiente varchar(4);
  vindice NUMBER;
  vindiceant NUMBER;  
  vcompara NUMBER;

/******************************************************************************
   NAME:       SP_FOLIO_ELECTRONICO
   PURPOSE:    ERIKA ASTORGA

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        16/08/2010          1. Created this procedure.

   NOTES:

   Automatically available Auto Replace Keywords:
      Object Name:     SP_FOLIO_ELECTRONICO
      Sysdate:         16/08/2010
      Date and Time:   16/08/2010, 12:51:12 p.m., and 16/08/2010 12:51:12 p.m.
      Username:         (set in TOAD Options, Procedure Editor)
      Table Name:       (set in the "New PL/SQL Object" dialog)

******************************************************************************/
BEGIN
   vfolior := NULL;
   vfecha := NULL;
   vultimo :=NULL;
   vfechafolio := NULL;
   vlastfolio := NULL;
   vlista:='ABCDEFGHIJKLMNOPQRSRUVWXYZ';
   vinicia := NULL;
   vfinal := NULL;
   vletra2 :=NULL;
   vcuenta := 0;
   vresultado := NULL;
   vletrasiguiente := NULL;

   REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FOLIO_ELECTRONICO', 'perIdPersona', perIdPersona, 'IN');


    SELECT FOLIO_MERCANTIL
    INTO vfolior
    FROM RUG_PERSONAS
    WHERE ID_PERSONA = perIdPersona;


    Select count(*) into vcuenta FROM RUG_FOLIO;

    IF vcuenta =0 THEN
        INSERT INTO RUG_FOLIO (LAST_DATE,LAST_ID) 
            VALUES (SYSDATE,'A000');

        vfechafolio:=to_char(SYSDATE,'yyyymmdd');
        vultimo:='A000';    

    ELSE    
        SELECT to_char(LAST_DATE,'yyyymmdd'), LAST_ID
        INTO vfechafolio, vultimo
        FROM RUG_FOLIO;

    END IF;




   SELECT to_char(SYSDATE, 'yyyymmdd') into vfecha FROM dual;

   --IF vfolior IS NULL THEN 


           IF vultimo is NULL THEN          

                psTxResult:='R'||vfecha||'A000'; 

                vlastfolio :='A000';

           ELSE                         

           --   contador := TO_NUMBER(TRIM(SUBSTR(vultimo, 2, 4)));

            FOR vindice IN 1..4 LOOP

              letra :=  TRIM(SUBSTR(vultimo, 0, vindice));

              vindiceant:= vindice -1;
              vletrasiguiente :=SUBSTR(letra,vindiceant,1);

              vcompara :=INSTR(vlista,vletrasiguiente);

              dbms_output.put_line('vcompara ' || vcompara);    
              IF vcompara > 0 THEN 
                  vletra2 := TRIM(SUBSTR(vultimo, 0, vindice));

                 -- vindice := 1+1;
                 /* vletrasiguiente :=  TRIM(SUBSTR(vultimo, 0, vindice));
                  IF INSTR(vlista,vletrasiguiente) > 0 THEN     

                  END IF;*/

              END IF;

             END LOOP; 

             letra:= vletra2;

             contador := TO_NUMBER(TRIM(SUBSTR(vultimo, length(letra), length(vultimo)))); 

             dbms_output.put_line('contador ' || contador);             


              if ( vfecha = vfechafolio ) then

                  IF (contador=999 or contador = 99) then

                      vinicia:= INSTR(vlista,letra);
                      vfinal := vinicia +1;

                      vletra2 := TRIM(SUBSTR(vlista, vfinal,1));

                      vlastfolio := vletra2 || '000';   
                      vresultado :='R'||vfecha ||vlastfolio;                         

                  ELSE                

                     contador := contador +1;                  


                      IF (LENGTH(TO_CHAR(contador))=1) THEN
                            vlastfolio := letra || '00'||TO_CHAR(contador); 
                        END IF;

                      IF (LENGTH(TO_CHAR(contador))=2) THEN
                           vlastfolio := letra || '0'||TO_CHAR(contador); 
                      END IF;

                      IF (LENGTH(TO_CHAR(contador))=3) THEN
                           vlastfolio := letra || TO_CHAR(contador); 
                      END IF;


                      vresultado :='R'||vfecha||vlastfolio;

                   END IF;   
              ELSE  

                   IF (contador=999)then

                      vinicia:= INSTR(vlista,letra);
                      vfinal := vinicia +1;
                      vletra2 := TRIM(SUBSTR(vlista, vfinal,vfinal)); 

                      vlastfolio := vletra2 || '000';    
                      vresultado :='R'||vfecha|| vlastfolio;                         

                  ELSE                

                    contador := contador +1; 
                    IF (LENGTH(TO_CHAR(contador))=1) THEN
                        vlastfolio := letra || '00'||TO_CHAR(contador); 
                    END IF;

                  IF (LENGTH(TO_CHAR(contador))=2) THEN
                       vlastfolio := letra || '0'||TO_CHAR(contador); 
                  END IF;

                  IF (LENGTH(TO_CHAR(contador))=3) THEN
                       vlastfolio := letra || TO_CHAR(contador); 
                  END IF;


                    vresultado :='R'||vfechafolio||vlastfolio ;

                END IF;


              END IF;

          END IF;    


    --  END IF;

  UPDATE RUG_PERSONAS SET FOLIO_MERCANTIL=vresultado  WHERE ID_PERSONA = perIdPersona;      
  UPDATE RUG_FOLIO SET LAST_DATE=TO_DATE(vfecha,'yyyymmdd'), LAST_ID= vlastfolio; 

  COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FOLIO_ELECTRONICO', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FOLIO_ELECTRONICO', 'psTxResult', psTxResult, 'OUT');
      DBMS_OUTPUT.PUT_LINE(psTxResult);
  END;
/

