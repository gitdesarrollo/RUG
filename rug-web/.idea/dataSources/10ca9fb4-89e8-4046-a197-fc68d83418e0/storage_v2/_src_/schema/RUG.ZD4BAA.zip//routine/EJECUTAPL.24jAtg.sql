create PROCEDURE             EJECUTAPL 
AS
vlResult    NUMBER;
vlTxResult  VARCHAR2(500);

vIdControlUnico number;
BEGIN
--vIdControlUnico :=8599;
FENIX.PKGTRAMITERNIE.TRAMITERNIE('Unilever De Mexico'                                                        --peNombreSolicitud         VARCHAR2
                                    ,'UME651115N48'                                                                 --peRFC                     VARCHAR2
                                    ,19                                                                            --peIdRegimenJuridico       NUMBER
                                    ,'U'                                                                            --peCveTipoAdmin            VARCHAR2                                                               
                                    ,null                                                                           --peIdUsuario               NUMBER
                                    ,vIdControlUnico                                                                --peIdControlUnico          NUMBER
                                    ,5.785633755E9                                                                            --peMontoCapitalFijo        NUMBER
                                    ,6                                                                            --peNumAccCapFijo           NUMBER
                                    ,0.0                                                                            --peMontoCapitalVar         NUMBER
                                    ,null                                                                           --peActa                    BLOB
                                    ,null                                                                           --peTipFormActa       
                                    ,null                                                                           --pePermisoUsoNombre          IN  EMP_DOCTOS_TRAMITE.CONTENIDO_DOCTO%TYPE,
                                    ,null                                                                           --peTipFormPermisoNombre      IN  NUMBER,
                                    ,Null                                                                           --peAvisoUsoNombre            IN  EMP_DOCTOS_TRAMITE.CONTENIDO_DOCTO%TYPE,
                                    ,null                                                                           --peTipForAvisoUso            IN  NUMBER,
                                    ,null                                                                           --peCedulaIdentFiscal         IN  EMP_DOCTOS_TRAMITE.CONTENIDO_DOCTO%TYPE,
                                    ,null                                                                           --peTipForCedFiscal 
                                    ,'183|100'                                                                      --peCadenaActividades       VARCHAR2
                                    ,'90|MONTE ELBRUZ N? 124- 6? PISO|--||105892|0|0|0~34|MONTE ELBRUZ N? 124- 6? PISO|--||105892|0|0|0'                --peCadenaDomicEmp          VARCHAR2
                                    ,'Clemente Jacques Y Cia., S.A. De C.V.|||||||1|0|0||||0|0|0|0|PM|NLD~Mexinvest, B.V.|||||||1|0|0||||0|0|0|0|PM|NLD~Nommexar, B.V.|||||||1|0|0||||0|0|0|0|PM|NLD~Immex, B.V.|||||||1|0|0||||0|0|0|0|PM|NLD~Mexee|B.V.||||||1|0|0||||0|0|0|0|PF|NLD~Mexnom, B.V.|||||||1|0|0||||0|0|0|0|PM|NLD'             --peCadenaSociosAccionistas VARCHAR2
                                    ,'Hilda|Castro|Castellanos|||||11||50|PASEO DE LOS TAMARINDOS 150|--|--|1419924|0|0|0|F'                             --peCadenaAdministradores   VARCHAR2
                                    ,0                                                                              --peIdTramite               NUMBER 
                                    ,''                                                                             --peFolioPago               VARCHAR2 
                                    ,null                                                                           --peFhPago                  DATE
                                    ,0.0                                                                            --peImpPago                 NUMBER 
                                    ,0                                                                              --peNumOperacion            NUMBER 
                                    ,0                                                                              --peIdTipoMedioRecep        NUMBER 
                                    ,0                                                                              --peIdEntFinanciera         NUMBER 
                                    ,''                                                                             --peCveReferenciaDpa        VARCHAR2 
                                    ,''                                                                             --peCadenaDependencia       VARCHAR2                                    
                                    ,'topiltzin_jm@yahoo.com.mx'                                                    --peCveUsuario              VARCHAR2
                                    ,4518
                                    ,'topiltzin_jm@yahoo.com.mx'
                                    ,643540                                                                          --peIdExpediente            NUMBER                                  
                                    ,'V'
                                     ,vlResult                                                                      --psResult                  INTEGER
                                    ,vlTxResult                                                                     --psTxResult                VARCHAR2
                                    ); 

Dbms_output.put_line(vIdControlUnico || ' - ' || vlResult || ' - ' || vlTxResult);


END;
/

