create PROCEDURE         SP_BAJA_CLAVE_RASTREO 
                                                   (
                                                      peIdAcreedor      IN    NUMBER,
                                                      peClaveRastreo    IN    VARCHAR2,
                                                      peIdArchivo       IN    NUMBER,
                                                      psResult         OUT    NUMBER, 
                                                      psTxResult       OUT    VARCHAR2
                                                   )
IS

vlCantidad      NUMBER;
Ex_Error        EXCEPTION;

BEGIN

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_CLAVE_RASTREO', 'peIdAcreedor', peIdAcreedor, 'IN');                                                
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_CLAVE_RASTREO', 'peClaveRastreo', peClaveRastreo, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_CLAVE_RASTREO', 'peIdArchivo', peIdArchivo, 'IN');


    SELECT COUNT(*)
      INTO vlCantidad
      FROM RUG_TRAMITE_RASTREO
     WHERE ID_ARCHIVO = peIdArchivo
       AND CVE_RASTREO = peClaveRastreo;


    IF vlCantidad = 0 THEN

        psResult := 116;
        RAISE Ex_Error;

    END IF;


    SELECT COUNT(*)
      INTO vlCantidad
      FROM RUG_REL_TRAM_INC_PARTES A,
           RUG_TRAMITE_RASTREO B,
           TRAMITES_RUG_INCOMP C
     WHERE C.ID_TRAMITE_TEMP = B.ID_TRAMITE_TEMP
       AND C.ID_STATUS_TRAM IN (3,5)
       AND B.ID_TRAMITE_TEMP = A.ID_TRAMITE_TEMP
       AND ID_PARTE = 4
       AND B.CVE_RASTREO = peClaveRastreo
       AND A.ID_PERSONA = peIdAcreedor;


    IF vlCantidad > 0 THEN

        psResult := 85;
        RAISE Ex_Error;

    END IF;


    DELETE RUG_TRAMITE_RASTREO
     WHERE ID_TRAMITE_TEMP = ( SELECT B.ID_TRAMITE_TEMP 
                             FROM RUG_REL_TRAM_INC_PARTES A,
                                  RUG_TRAMITE_RASTREO B                                  
                            WHERE B.ID_TRAMITE_TEMP = A.ID_TRAMITE_TEMP
                              AND ID_PARTE = 4
                              AND B.CVE_RASTREO = peClaveRastreo
                              AND ID_PERSONA = peIdAcreedor);

    COMMIT;

    psResult:=0;   
    psTxResult:= RUG.FN_MENSAJE_ERROR(psResult);

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_CLAVE_RASTREO', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_CLAVE_RASTREO', 'psTxResult', psTxResult, 'OUT');

EXCEPTION
WHEN Ex_Error  THEN
    psTxResult := RUG.FN_MENSAJE_ERROR(psResult);

    ROLLBACK;
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_CLAVE_RASTREO', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_CLAVE_RASTREO', 'psTxResult', psTxResult, 'OUT');

WHEN OTHERS THEN

    psResult  := 999;   
    psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
    ROLLBACK;
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_CLAVE_RASTREO', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_CLAVE_RASTREO', 'psTxResult', psTxResult, 'OUT');

END;
/

