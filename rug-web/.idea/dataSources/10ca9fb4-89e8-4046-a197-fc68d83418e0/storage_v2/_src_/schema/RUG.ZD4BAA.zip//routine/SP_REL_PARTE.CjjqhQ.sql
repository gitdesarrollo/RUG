create PROCEDURE         SP_REL_PARTE 
                            (
                                peIdPersona          IN  NUMBER,
                                peIdTramiteTemp      IN  NUMBER,
                                peIdParte            IN  NUMBER,
                                peRFC                IN  VARCHAR2,
                                psResult            OUT  INTEGER,   
                                psTxResult          OUT  VARCHAR2                             
                            )
IS
                        

vlIdPersona         NUMBER;
vlPerJuridica       CHAR(2);
vlTipoTramite       NUMBER;
vlTramiteExiste     NUMBER;
vIdCancelacion      NUMBER;
vlIdInscripcion     NUMBER;
vlCancTrans         NUMBER;
vlCantidad          NUMBER;
vlIdParte           NUMBER;



fk_exception  EXCEPTION;
PRAGMA EXCEPTION_INIT (fk_exception, -00001);

Ex_ParteExistente EXCEPTION;
Ex_ErrParametro  EXCEPTION;

   CURSOR cursPartes(cpeIdTramite IN NUMBER) IS
   SELECT ID_PARTE FROM RUG_REL_TRAM_INC_PARTES
   WHERE ID_TRAMITE_TEMP = cpeIdTramite AND ID_PARTE IN (1,4) AND STATUS_REG = 'AC';
   cursPartes_Rec cursPartes%ROWTYPE;

BEGIN

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_PARTE', 'peIdPersona', peIdPersona, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_PARTE', 'peIdTramiteTemp', peIdTramiteTemp, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_PARTE', 'peIdParte', peIdParte, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_PARTE', 'peRFC', peRFC, 'IN');

     BEGIN
             SELECT ID_TRAMITE_TEMP,  ID_TIPO_TRAMITE
             INTO vlTramiteExiste, vlTipoTramite
             FROM TRAMITES_RUG_INCOMP
             WHERE ID_TRAMITE_TEMP = peIdTramiteTemp;
              EXCEPTION
               WHEN NO_DATA_FOUND THEN
                psResult := 16;                
                RAISE Ex_ErrParametro;
       END;

  SELECT PER_JURIDICA
  INTO vlPerJuridica
  FROM RUG_PERSONAS
  WHERE ID_PERSONA = peIdPersona;


             UPDATE RUG_PERSONAS
             SET RFC = peRFC
             WHERE ID_PERSONA = peIdPersona;


   IF vlTipoTramite = 8 THEN

--     SELECT COUNT(*)
--     INTO vlCancTrans 
--     FROM RUG_CANCELACION_TRANSMISION
--     WHERE ID_TRAMITE_TEMP = peIdTramiteTemp;
--     
--     IF vlCancTrans > 0 THEN
--     
--        SELECT ID_CANCELACION
--        INTO vIdCancelacion
--        FROM RUG_CANCELACION_TRANSMISION 
--        WHERE ID_TRAMITE_TEMP = peIdTramiteTemp;
--                
--        SELECT ID_INSCRIPCION
--        INTO vlIdInscripcion
--        FROM RUG_CANCELACION_TRANSMISION 
--        WHERE ID_TRAMITE_TEMP = peIdTramiteTemp;
--        
--        --ACTUALIZO LA CANCELACION
--        UPDATE RUG_REL_TRAM_INC_PARTES
--        SET STATUS_REG = 'IN', FECHA_REG = SYSDATE
--        WHERE ID_TRAMITE_TEMP = vIdCancelacion 
--        AND ID_PARTE = 4;

--        INSERT INTO RUG_REL_TRAM_INC_PARTES
--        VALUES(vIdCancelacion, peIdPersona, 4, vlPerJuridica, 'AC', SYSDATE);
--        
--        --ACTUALIZO LA INSCRIPCION
--        UPDATE RUG_REL_TRAM_INC_PARTES
--        SET STATUS_REG = 'IN', FECHA_REG = SYSDATE
--        WHERE ID_TRAMITE_TEMP = vlIdInscripcion 
--        AND ID_PARTE = 4;

--        INSERT INTO RUG_REL_TRAM_INC_PARTES
--        VALUES(vlIdInscripcion, peIdPersona, 4, vlPerJuridica, 'AC', SYSDATE);
--     
--     END IF;




    IF peIdParte = 4 THEN 

        UPDATE RUG_REL_TRAM_INC_PARTES
        SET STATUS_REG = 'IN', FECHA_REG = SYSDATE
        WHERE ID_TRAMITE_TEMP = peIdTramiteTemp 
        AND ID_PARTE = 4;

        BEGIN

            INSERT INTO RUG_REL_TRAM_INC_PARTES
            VALUES(peIdTramiteTemp, peIdPersona, 4, vlPerJuridica, 'AC', SYSDATE);

        EXCEPTION

            WHEN fk_exception THEN        
            BEGIN
                psResult := 70;
                RAISE Ex_ErrParametro;
            END;

        END;

    ELSE 

        SELECT COUNT(*) 
          INTO vlCantidad
          FROM RUG_REL_TRAM_INC_PARTES
         WHERE ID_TRAMITE_TEMP = peIdTramiteTemp
           AND ID_PERSONA = peIdPersona
           AND ID_PARTE = peIdParte;

        IF (vlCantidad = 0) THEN          

            INSERT INTO RUG_REL_TRAM_INC_PARTES
            VALUES(peIdTramiteTemp, peIdPersona, peIdParte, vlPerJuridica, 'AC', SYSDATE);

        ELSE

            UPDATE RUG_REL_TRAM_INC_PARTES
               SET STATUS_REG = 'AC'
             WHERE ID_TRAMITE_TEMP = peIdTramiteTemp
               AND ID_PERSONA = peIdPersona
               AND ID_PARTE = peIdParte;

        END IF;

    END IF;


    ELSE

     IF peIdParte = 4 THEN
        OPEN cursPartes(peIdTramiteTemp);
             LOOP
                FETCH  cursPartes INTO vlIdParte;
                    IF vlIdParte = peIdParte THEN
                        RAISE Ex_ParteExistente;
                    END IF;
                EXIT WHEN  cursPartes%NOTFOUND;   
            END LOOP;
        CLOSE cursPartes;
     END IF;

    SELECT COUNT(*) 
      INTO vlCantidad
      FROM RUG_REL_TRAM_INC_PARTES
     WHERE ID_TRAMITE_TEMP = peIdTramiteTemp
       AND ID_PERSONA = peIdPersona
       AND ID_PARTE = peIdParte;


     IF (vlCantidad = 0) THEN          

        INSERT INTO RUG_REL_TRAM_INC_PARTES
        VALUES(peIdTramiteTemp, peIdPersona, peIdParte, vlPerJuridica, 'AC', SYSDATE);

     ELSE 

        UPDATE RUG_REL_TRAM_INC_PARTES
           SET STATUS_REG = 'AC'
         WHERE ID_TRAMITE_TEMP = peIdTramiteTemp
           AND ID_PERSONA = peIdPersona
           AND ID_PARTE = peIdParte;

            UPDATE RUG_PERSONAS
            SET RFC = peRFC
         WHERE ID_PERSONA = peIdPersona;



     END IF;

   END IF;    

  COMMIT;

  psResult   :=0;        
  psTxResult :='Actualizacion finalizada satisfactoriamente';

  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_PARTE', 'psResult', psResult, 'OUT');
  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_PARTE', 'psTxResult', psTxResult, 'OUT');    


EXCEPTION
  WHEN Ex_ParteExistente  THEN
      psResult   :=29;               
      psTxResult := RUG.FN_MENSAJE_ERROR(psResult);
      ROLLBACK;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_PARTE', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_PARTE', 'psTxResult', psTxResult, 'OUT');
      DBMS_OUTPUT.PUT_LINE(psTxResult);

   WHEN Ex_ErrParametro  THEN
      psTxResult := RUG.FN_MENSAJE_ERROR(psResult);
      ROLLBACK;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_PARTE', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_PARTE', 'psTxResult', psTxResult, 'OUT');
      DBMS_OUTPUT.PUT_LINE(psTxResult);    

   WHEN OTHERS THEN
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      ROLLBACK;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_PARTE', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_PARTE', 'psTxResult', psTxResult, 'OUT');
      DBMS_OUTPUT.PUT_LINE(psTxResult);
END SP_REL_PARTE;
/

