create PROCEDURE         SP_CADUCIDAD_TRAMITES 
                            (
                                psResult            OUT  INTEGER,   
                                psTxResult          OUT  VARCHAR2                             
                            )
IS
                        
vlFechaFinVigencia DATE;    
vlIdTramiteTemp NUMBER;
vlIdTipoTramite NUMBER;
vlIdGarantia    NUMBER;   
vlIdTramiteIncompleto Number;
vlIdPersona     Number;
vlResult        Number; 
vlTxResult      Varchar2(2000 Byte);

CURSOR cursTramitesFinVigencia IS
SELECT ID_TRAMITE_TEMP, ID_TIPO_TRAMITE, ID_GARANTIA
FROM V_TRAMITES_TERM_VIGENCIA
;

BEGIN


    BEGIN

        --ACTUALIZO ESTADO ISRUNNING
        --SP_LOG_JOBS_RUG(1, 1, 1);

        OPEN cursTramitesFinVigencia;
            LOOP
                FETCH cursTramitesFinVigencia INTO vlIdTramiteTemp, vlIdTipoTramite, vlIdGarantia;
                EXIT WHEN cursTramitesFinVigencia%NOTFOUND;

                SELECT ID_PERSONA INTO vlIdPersona
                FROm TRAMITES 
                WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;

                IF(vlIdTipoTramite = 3) THEN

                    UPDATE TRAMITES
                       SET STATUS_REG = 'CA'
                     WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;


                    UPDATE RUG_BITAC_TRAMITES
                       SET STATUS_REG = 'IN'
                     WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;


                    INSERT INTO RUG_BITAC_TRAMITES
                    VALUES (vlIdTramiteTemp, 10, SYSDATE, 0, 3, SYSDATE, 'AC');

                ELSIF (vlIdTipoTramite = 10) THEN

                    SP_Alta_Tramite_Incompleto(vlIdPersona, 20, vlIdTramiteIncompleto, vlResult, vlTxResult);


                    INSERT INTO RUG_ANOTACIONES_SIN_GARANTIA_H
                    SELECT * 
                      FROM RUG_ANOTACIONES_SIN_GARANTIA
                     WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;


                    UPDATE RUG_ANOTACIONES_SIN_GARANTIA
                       SET ID_TRAMITE_TEMP = vlIdTramiteIncompleto
                     WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;

                     UPDATE TRAMITES
                       SET STATUS_REG = 'CA'
                     WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;


                    UPDATE RUG_BITAC_TRAMITES
                       SET STATUS_REG = 'IN'
                     WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;


                    INSERT INTO RUG_BITAC_TRAMITES
                    VALUES (vlIdTramiteTemp, 10, SYSDATE, 0, 10, SYSDATE, 'AC');

                    SP_ALTA_BITACORA_TRAMITE2(vlIdTramiteIncompleto, 3, 0, NULL, 'V', vlResult, vlTxResult);

                    SP_ALTA_BITACORA_TRAMITE2(vlIdTramiteIncompleto, 3, 100,  TO_DATE (SYSDATE, 'YYYY-MM-DD HH24:MI:SS'), 'F', vlResult, vlTxResult);


                    INSERT INTO RUG_ANOTACIONES_SIN_GARANTIA_H
                    SELECT * 
                      FROM RUG_ANOTACIONES_SIN_GARANTIA
                     WHERE ID_TRAMITE_TEMP = vlIdTramiteIncompleto;


                ELSE

                    SP_Alta_Tramite_Incompleto(vlIdPersona, 21, vlIdTramiteIncompleto, vlResult, vlTxResult);

                    If ( vlResult <> 0 Or vlResult Is Not Null )  Then

                        SP_ALTA_CANCELACION(vlIdTramiteIncompleto, vlIdGarantia, '', vlResult, vlTxResult);

                        If ( vlResult <> 0 Or vlResult Is Not Null ) Then

                            SP_ALTA_BITACORA_TRAMITE2(vlIdTramiteIncompleto, 3, 0, NULL, 'V', vlResult, vlTxResult);

                            If ( vlResult <> 0 Or vlResult Is Not Null ) Then

                                vlResult:= 0;
                                SP_ALTA_BITACORA_TRAMITE2(vlIdTramiteIncompleto, 3, 100, SYSDATE, 'F', vlResult, vlTxResult);

                            End If;

                        End If;

                     End If;

                    IF vlIdTipoTramite = 1 OR vlIdTipoTramite = 31 THEN    

                        DELETE FROM rug.RUG_TBL_BUSQUEDA          --rug_rel_tram_garan
                        WHERE ID_TRAMITE In (SELECT ID_TRAMITE FROM RUG_REL_TRAM_GARAN WHERE ID_GARANTIA = vlIdGarantia);

                    END IF;

                END IF;

                    COMMIT;
            END LOOP;

        CLOSE cursTramitesFinVigencia;

        psResult:= 0;
        psTxResult:= 'Finalizo exitosamente el proceso';
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
           --SP_LOG_JOBS_RUG(1, 1, 0);
           RUG.REG_PARAM_PLS (RUG.SEQ_RUG_PARAM_PLS.NEXTVAL,
              'SP_CADUCIDAD_TRAMITES','psResult',777, 'OUT');  
              RUG.REG_PARAM_PLS (RUG.SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CADUCIDAD_TRAMITES',
              'psTxResult', 'NO HAY TRAMITES CON VIGENCIA VENCIDA', 'OUT');         
    END;


EXCEPTION
   WHEN OTHERS THEN
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      ROLLBACK;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CADUCIDAD_TRAMITES', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CADUCIDAD_TRAMITES', 'psTxResult', psTxResult, 'OUT');
END SP_CADUCIDAD_TRAMITES;
/

