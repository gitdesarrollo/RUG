create PROCEDURE     MODIFICAR_CORREO (pIdPersona IN NUMBER, pNuevoCorreo IN VARCHAR2, pUsuario IN NUMBER) IS
	v_correo_original VARCHAR2(500);
BEGIN
	SELECT cve_usuario
	INTO v_correo_original
	FROM rug_secu_usuarios
	WHERE ID_PERSONA = pIdPersona;

	-- insertar en bitacora de operaciones
	INSERT INTO RUG.BITACORA_OPERACIONES(BITACORA_ID, USUARIO_ID, OPERACION, FECHA)
	VALUES(RUG.SEQ_BITACORA_OPERACIONES.NEXTVAL, pUsuario, 'Se modifica el correo '||v_correo_original||' por '||pNuevoCorreo, SYSDATE);

	-- actualizar persona
	UPDATE RUG.RUG_SECU_USUARIOS SET CVE_USUARIO=pNuevoCorreo WHERE ID_PERSONA = pIdPersona;

	UPDATE RUG.RUG_SECU_PERFILES_USUARIO SET CVE_USUARIO=pNuevoCorreo WHERE ID_PERSONA = pIdPersona;

	-- si es un usuario con subcuentas, modificar las subcuentas
	UPDATE RUG.RUG_SECU_USUARIOS SET CVE_USUARIO_PADRE = pNuevoCorreo
	WHERE CVE_USUARIO_PADRE = v_correo_original;

	COMMIT;	
END;
/

