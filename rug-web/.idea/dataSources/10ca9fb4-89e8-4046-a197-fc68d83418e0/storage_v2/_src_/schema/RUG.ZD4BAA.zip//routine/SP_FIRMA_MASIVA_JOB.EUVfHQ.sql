create PROCEDURE         SP_FIRMA_MASIVA_JOB IS 

    vlStatusJob CHAR(5);

    CURSOR cursFirmaMasiva IS
    SELECT ID_TRAMITE_TEMP, ID_USUARIO_FIRMO
      FROM RUG_FIRMA_DOCTOS
     WHERE PROCESADO = 'N';


    CURSOR cursTramites ( cpeIdTramiteTemp   IN NUMBER) IS
    SELECT   ID_TRAMITE_TEMP
      FROM   RUG_FIRMA_MASIVA
     WHERE   ID_FIRMA_MASIVA = cpeIdTramiteTemp 
       AND STATUS_REG = 'AC';

    cursTramites_Rec   cursTramites%ROWTYPE;
    cursFirmaMasiva_Rec cursFirmaMasiva%ROWTYPE;

    vlTimeStamp_SE          BLOB;
    vlCadenaOrigFirmada     CLOB;
    vlCadenaOrigNoFirmada   CLOB;
    vlCadenaOrigFirmada_SE  CLOB;
    vlUsuarioFirmo          NUMBER;
    vlIdTipoTramite         NUMBER;
    vlIdTramiteTemp         NUMBER;
    vlTramiteFirmar         NUMBER;
    vlTramitesFirmados      NUMBER;    
    vlResult                INTEGER;
    vlFechaCreacion         VARCHAR2(30);
    vlDestinatario          VARCHAR2(500);
    vlTxResult              VARCHAR2(4000);


    Ex_Err_FirmaTramites  EXCEPTION;


BEGIN

  --VERIFICO SI ESTA ACTIVO; PROCESO DE LO CONTRARIO NO
        SELECT STATUS_JOB
          INTO vlStatusJob
          FROM RUG_JOBS
         WHERE JOB_NAME = 'JOB_FIRMA_MASIVA';

           IF vlStatusJob = 'AC' THEN

            REG_PARAM_PLS (RUG.SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FIRMA_MASIVA_JOB', 'INCIA PROCESO', 1, 'IN');


            SP_LOG_JOBS_RUG(2, 1, 1);

                 BEGIN

                   OPEN cursFirmaMasiva;

                       LOOP

                           FETCH cursFirmaMasiva INTO vlIdTramiteTemp, vlUsuarioFirmo;
                           EXIT WHEN cursFirmaMasiva%NOTFOUND;


                           REG_PARAM_PLS (RUG.SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FIRMA_MASIVA_JOB', 'INICIA FIRMA TRAMITE', 1, 'IN');

                           SELECT TO_CHAR(FECHA_STATUS,'DD/MM/YYYY HH24:MI:SS') 
                             INTO vlFechaCreacion
                             FROM RUG.RUG_BITAC_TRAMITES
                            WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp
                              AND ID_STATUS = 8;

--                           RUG.SP_FIRMA_MASIVA_JOB(vlIdTramiteTemp,vlCadenaOrigNoFirmada,vlCadenaOrigFirmada,vlCadenaOrigFirmada_SE,vlTimeStamp_SE, vlFechaCreacion,vlUsuarioFirmo,'V',vlResult,vlTxResult);

                            BEGIN

                                  UPDATE RUG_FIRMA_DOCTOS
                                     SET PROCESADO = 'P'
                                   WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;

                                  COMMIT;

                               OPEN cursTramites(vlIdTramiteTemp);
                                   LOOP

                                    FETCH cursTramites INTO vlTramiteFirmar;
                                    EXIT WHEN cursTramites%NOTFOUND; 

                                        INSERT INTO RUG.RUG_BITAC_FIRMA_MASIVA (
                                        ID_FIRMA_MASIVA, ID_TRAMITE_TEMP, FECHA_REG, ID_STATUS) 
                                        VALUES (vlIdTramiteTemp,vlTramiteFirmar ,SYSDATE ,9 );

                                        COMMIT;

                                       /* INSERT INTO RUG_FIRMA_DOCTOS
                                        SELECT 0, vlTramiteFirmar, ID_USUARIO_FIRMO, XML_CO, CO_USUAIRO, CERTIFICADO_USUARIO_B64, FIRMA_USUARIO_B64, CO_SELLO,
                                               SELLO_TS_B64, CO_FIRMA_RUG, FIRMA_RUG_B64, FECHA_REG, STATUS_REG, CERTIFICADO_CENTRAL_B64, PROCESADO
                                          FROM RUG_FIRMA_DOCTOS
                                         WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;*/


                                         REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Bitacora_Tramite2', 'ANTES DE ENTRAR', '0', 'IN');

                                         SP_Alta_Bitacora_Tramite2(vlTramiteFirmar, 3, 0, NULL, 'V', vlResult, vlTxResult);

                                         IF vlResult = 0 THEN

                                            SP_Alta_Bitacora_Tramite2(vlTramiteFirmar, 3, 100,  TO_DATE (vlFechaCreacion, 'DD/MM/YYYY HH24:MI:SS'), 'F', vlResult, vlTxResult);

                                            IF vlResult = 0 THEN

                                                INSERT INTO RUG.RUG_BITAC_FIRMA_MASIVA (
                                                ID_FIRMA_MASIVA, ID_TRAMITE_TEMP, FECHA_REG, ID_STATUS) 
                                                VALUES (vlIdTramiteTemp,vlTramiteFirmar ,SYSDATE ,3 );

                                                COMMIT;

                                            ELSE
                                                ROLLBACK;

                                                /*UPDATE RUG_FIRMA_DOCTOS
                                                   SET PROCESADO = 'E'
                                                 WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;*/

                                                  INSERT INTO RUG.RUG_BITAC_FIRMA_MASIVA (
                                                  ID_FIRMA_MASIVA, ID_TRAMITE_TEMP, FECHA_REG, ID_STATUS) 
                                                  VALUES (vlIdTramiteTemp,vlTramiteFirmar ,SYSDATE ,11 );

                                                  COMMIT;


                                            END IF;


                                         ELSE

                                            ROLLBACK;

                                            /*UPDATE RUG_FIRMA_DOCTOS
                                               SET PROCESADO = 'E'
                                             WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;*/

                                             INSERT INTO RUG.RUG_BITAC_FIRMA_MASIVA (
                                             ID_FIRMA_MASIVA, ID_TRAMITE_TEMP, FECHA_REG, ID_STATUS) 
                                             VALUES (vlIdTramiteTemp,vlTramiteFirmar ,SYSDATE ,11 );

                                             COMMIT;

                                         END IF;

                                         REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Bitacora_Tramite2', 'AL SALIR', '0', 'IN');

                                   END LOOP;

                               CLOSE  cursTramites;

                            EXCEPTION
                               WHEN OTHERS THEN
                                RAISE Ex_Err_FirmaTramites;
                               ROLLBACK;
                            END;


                           SELECT COUNT(*)
                             INTO vlTramitesFirmados
                             FROM RUG.TRAMITES_RUG_INCOMP TRI,
                                  RUG.RUG_FIRMA_MASIVA RFM
                            WHERE TRI.ID_TRAMITE_TEMP = RFM.ID_TRAMITE_TEMP
                              AND TRI.ID_STATUS_TRAM <> 3
                              AND RFM.ID_FIRMA_MASIVA = vlIdTramiteTemp;


                           IF vlTramitesFirmados = 0 THEN

                                UPDATE RUG.RUG_FIRMA_DOCTOS
                                SET PROCESADO = 'Y'
                                WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;

                                COMMIT;

                                --TERMINO EL TRAMITE
                                SP_ALTA_BITACORA_TRAMITE2(vlIdTramiteTemp, 3, 0, NULL, 'V', vlResult, vlTxResult);

                                SELECT CVE_USUARIO
                                INTO vlDestinatario
                                FROM RUG_SECU_USUARIOS
                                WHERE ID_PERSONA = vlUsuarioFirmo;

                                SELECT   B.ID_TIPO_TRAMITE
                                  INTO   vlIdTipoTramite
                                  FROM   RUG_FIRMA_MASIVA A, 
                                         TRAMITES_RUG_INCOMP B
                                 WHERE   A.ID_FIRMA_MASIVA = vlIdTramiteTemp 
                                   AND   A.STATUS_REG = 'AC'
                                   AND   A.ID_TRAMITE_TEMP = B.ID_TRAMITE_TEMP   
                                   AND   ROWNUM < 2;


                                IF vlIdTipoTramite = 12 THEN

                                    INSERT INTO RUG_MAIL_POOL(ID_MAIL, ID_TIPO_CORREO, ID_MAIL_ACCOUNT, DESTINATARIO, ASUNTO, MENSAJE, ID_STATUS_MAIL)
                                    VALUES(SEQ_RUG_MAIL_POOL.NEXTVAL, 3, 2, vlDestinatario, 'Notificacion RUG: Sus tramites de Carga Masiva estan listos', 
                                    'El Alta de Acreedor Multiple ha sido realizada correctamente. Para poder visualizarlos de clic en : <a href="http://www.rug.gob.mx/Rug/acreedor/inicia.do"> ALTA DE ACREEDORES', 
                                    1);  

                                    COMMIT;                      

                                ELSE

                                    --ENVIO DE CORREO DE CORREO DE FINALIZACION
                                    --FALTA PARAMETRIZAR EL MENSAJE Y EL ASUNTO DEL MAIL
                                    INSERT INTO RUG_MAIL_POOL(ID_MAIL, ID_TIPO_CORREO, ID_MAIL_ACCOUNT, DESTINATARIO, ASUNTO, MENSAJE, ID_STATUS_MAIL)
                                    VALUES(SEQ_RUG_MAIL_POOL.NEXTVAL, 3, 2, vlDestinatario, 'Notificacion RUG: Sus tramites de Carga Masiva estan listos', 
                                    'Estimado: ' || vlDestinatario || ', Sus Tramites de Firma Masiva Con Tramite Temporal: ' || vlIdTramiteTemp||' han sido correctamente firmados, 
                                     la boleta se encuentra disponible en el siguiente link:  <a href="http://www.rug.gob.mx/Rug/home/boleta.do?idTramite='||vlIdTramiteTemp||CHR(38)||'idTipoTramite=18"> descargar boleta', 
                                    1);

                                    COMMIT;

                                END IF;

                                COMMIT;

                           END IF;

                           REG_PARAM_PLS (RUG.SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FIRMA_MASIVA_JOB', 'TERMINA FIRMA TRAMITE', 1, 'IN');                                                      

                       END LOOP;
                   CLOSE  cursFirmaMasiva;

                 EXCEPTION WHEN NO_DATA_FOUND THEN

                    SP_LOG_JOBS_RUG(2, 1, 0);

                    REG_PARAM_PLS (RUG.SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FIRMA_MASIVA_JOB', 'psResult', 777, 'OUT');

                    REG_PARAM_PLS (RUG.SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FIRMA_MASIVA_JOB', 'psTxResult', 'No hay tramites de firma masiva pendientes', 'OUT');

                 END;




            REG_PARAM_PLS (RUG.SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_FIRMA_MASIVA_JOB', 'TERMINA PROCESO', 1, 'IN');

            SP_LOG_JOBS_RUG(2, 1, 0);

            SP_LOG_JOBS_RUG(2, 2, 1);

            END IF;
EXCEPTION

  WHEN OTHERS THEN

    SP_LOG_JOBS_RUG(2, 1, 0);

    ROLLBACK;

    SP_LOG_JOBS_RUG(2, 3, 1);

END;
/

