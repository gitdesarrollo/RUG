create PROCEDURE     SP_COPIA_INFO_ULTIM_ANOTACION 
(
     P_ID_ANOTACION_TEMP    IN RUG_ANOTACIONES_SEG_INC_CSG.ID_ANOTACION_TEMP%TYPE,
     P_ID_TRAMITE_PADRE     IN RUG.TRAMITES.ID_TRAMITE%TYPE,
     psResult               OUT INTEGER,
     psTxResult             OUT VARCHAR2
)
AS

    V_ORIGEN            INT;
    V_ID_TRAMITE_TEMP   RUG.RUG_ANOTACIONES_SIN_GARANTIA.ID_TRAMITE_TEMP%TYPE;

    CURSOR C_TRAMITES (V_ID_TRAMITE_PADRE RUG.TRAMITES.ID_TRAMITE%TYPE) IS
    SELECT CASE
            WHEN T.ID_TIPO_TRAMITE = 10 THEN
                1
            ELSE 2 END AS ORIGEN
             , T.ID_TRAMITE_TEMP
           --  , T.ID_TIPO_TRAMITE
      FROM RUG.TRAMITES T
     WHERE T.ID_TRAMITE = V_ID_TRAMITE_PADRE
     ORDER BY T.ID_TRAMITE DESC;

BEGIN   

    REG_PARAM_PLS2 ('SP_COPIA_INFO_ULTIM_ANOTACION','P_ID_ANOTACION_TEMP',P_ID_ANOTACION_TEMP,'IN');
    REG_PARAM_PLS2 ('SP_COPIA_INFO_ULTIM_ANOTACION','P_ID_TRAMITE_PADRE',P_ID_TRAMITE_PADRE,'IN');

    OPEN C_TRAMITES(P_ID_TRAMITE_PADRE);

    LOOP
        FETCH C_TRAMITES 
         INTO V_ORIGEN
            , V_ID_TRAMITE_TEMP;

         IF V_ORIGEN = 1 THEN

            INSERT INTO RUG_ANOTACIONES_SEG_INC_CSG (
                       ID_ANOTACION_TEMP,   
                       ID_TRAMITE_PADRE, 
                       AUTORIDAD_AUTORIZA,  
                       ANOTACION,
                       VIGENCIA)
            SELECT  P_ID_ANOTACION_TEMP
                  , P_ID_TRAMITE_PADRE
                  , R.AUTORIDAD_AUTORIZA
                  , R.ANOTACION
                  , R.VIGENCIA_ANOTACION
              FROM  RUG.RUG_ANOTACIONES_SIN_GARANTIA R
             WHERE  STATUS_REG = 'AC'
               AND  R.ID_TRAMITE_TEMP = V_ID_TRAMITE_TEMP;

        ELSIF V_ORIGEN = 2 THEN

            INSERT INTO RUG_ANOTACIONES_SEG_INC_CSG (
                       ID_ANOTACION_TEMP,   
                       ID_TRAMITE_PADRE, 
                       AUTORIDAD_AUTORIZA,  
                       ANOTACION,
                       VIGENCIA)
            SELECT  P_ID_ANOTACION_TEMP
                  , P_ID_TRAMITE_PADRE
                  , A.AUTORIDAD_AUTORIZA
                  , dbms_lob.substr( A.ANOTACION, 4000, 1 ) 
                  , A.VIGENCIA
              FROM  RUG.RUG_ANOTACIONES_SEG_INC_CSG A
             WHERE  A.STATUS_REG = 'AC'
               AND  A.ID_ANOTACION_TEMP = V_ID_TRAMITE_TEMP;

        END IF;

        EXIT;

    END LOOP;

    CLOSE C_TRAMITES;



    psResult := 0;
    psTxResult := RUG.FN_MENSAJE_ERROR (psResult);            

    REG_PARAM_PLS2 ('SP_COPIA_INFO_ULTIM_ANOTACION','psResult',psResult,'OUT');

    REG_PARAM_PLS2 ('SP_COPIA_INFO_ULTIM_ANOTACION','psTxResult',psTxResult,'OUT');


EXCEPTION
    WHEN OTHERS THEN

        psResult := 999;
        psTxResult := SUBSTR (SQLCODE || ':' || SQLERRM, 1, 250);
        REG_PARAM_PLS2 ('SP_COPIA_INFO_ULTIM_ANOTACION', 'psResult',psResult, 'OUT');
        REG_PARAM_PLS2 ('SP_COPIA_INFO_ULTIM_ANOTACION', 'psTxResult', psTxResult,'OUT');
END;
/

