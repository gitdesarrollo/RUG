create view V_OPERACIONES_PENDIENTES as
SELECT   TRAM.ID_PERSONA,
              RCTT.ID_TIPO_TRAMITE,
              RCTT.DESCRIPCION,
              RCTT.PRECIO,
              NVL (TRAM.CANTIDAD, 0) AS CANTIDAD,
              NVL (TRAM.CANTIDAD * RCTT.PRECIO, 0) AS TOTAL
       FROM   (SELECT * -- GGR 11042013 - MMESCN2013-81
                 FROM ( -- GGR 11042013 - MMESCN2013-81
                         SELECT   TRI.ID_PERSONA,
                                  TRI.ID_TIPO_TRAMITE,
                                  COUNT ( * ) AS CANTIDAD
                           FROM   TRAMITES_RUG_INCOMP TRI, RUG_BITAC_TRAMITES RBT
                          WHERE   RBT.ID_TRAMITE_TEMP = TRI.ID_TRAMITE_TEMP
                                  AND TRI.ID_TRAMITE_TEMP NOT IN
                                           (SELECT   TRA.ID_TRAMITE_TEMP
                                              FROM   TRAMITES TRA
                                             WHERE   TRA.ID_TRAMITE_TEMP = TRI.ID_TRAMITE_TEMP
                                            )
                                  AND RBT.ID_STATUS = 2
                        GROUP BY   TRI.ID_PERSONA, TRI.ID_TIPO_TRAMITE
                        -- ORDER BY   2
                      -- GGR 11042013 - MMESCN2013-81 inicio
                      UNION 
                      SELECT TI.ID_PERSONA AS ID_USUARIO
                           , TI.ID_TIPO_TRAMITE
                           , COUNT(*) AS CANTIDAD
                        FROM RUG.RUG_ANOTACIONES_SEG_INC_CSG TA
                       INNER JOIN RUG.TRAMITES_RUG_INCOMP TI
                          ON TI.ID_TRAMITE_TEMP = TA.ID_ANOTACION_TEMP
                       WHERE TI.ID_STATUS_TRAM = 5
                         AND TA.ID_ANOTACION_TEMP NOT IN
                                   ( SELECT T.ID_TRAMITE_TEMP
                                       FROM TRAMITES T  
                                      WHERE T.ID_TRAMITE_TEMP = TA.ID_ANOTACION_TEMP 
                                   ) 
                       GROUP BY TI.ID_PERSONA, TI.ID_TIPO_TRAMITE
                       -- GGR 11042013 - MMESCN2013-81 fin
               ) ORDER BY 2 -- GGR 11042013 - MMESCN2013-81
               ) TRAM,
              RUG_CAT_TIPO_TRAMITE RCTT
      WHERE   TRAM.ID_TIPO_TRAMITE(+) = RCTT.ID_TIPO_TRAMITE
        AND   RCTT.STATUS_REG = 'AC' --  GGR 11042013 - MMESCN2013-81
   ORDER BY   2
/

