create FUNCTION             FN_PRECIO_REAL
                                                     (
                                                         pUserId      IN VARCHAR2
                                                       , pTipoTramite IN NUMBER
                                                       , pIdTramite   IN NUMBER
													   , pPendiente   IN NUMBER default 0
                                                     ) -- 0 NO_TIENE 1 TIENE
    RETURN NUMBER
IS    
    l_arancel   NUMBER;
    l_facturas  NUMBER;
    l_vehiculos NUMBER;
    l_precio    NUMBER;

	l_fecha_creacion TRAMITES.FECHA_CREACION%TYPE;
    vlDescMensajeError  VARCHAR(4000);
BEGIN

    --REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'FN_PRECIO_REAL', 'pUserId', pUserId, 'IN');
    --REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'FN_PRECIO_REAL', 'pTipoTramite', pTipoTramite, 'IN');
    --REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'FN_PRECIO_REAL', 'pIdTramite', pIdTramite, 'IN');

	IF pPendiente = 0 THEN  
        SELECT 
                FECHA_CREACION
        INTO    l_fecha_creacion
        FROM    
                TRAMITES
        WHERE   ID_TRAMITE = pIdTramite;
    ELSE
        l_fecha_creacion := SYSDATE;
    END IF;

	-- validamos vigencia precio
        BEGIN
            SELECT
                precio
            INTO l_precio
            FROM RUG_CAT_TIPO_TRAM_PAGO
            WHERE id_tipo_tramite = pTipoTramite
            AND VIGENCIA_PRECIO > TO_TIMESTAMP(l_fecha_creacion);

            EXCEPTION WHEN no_data_found THEN
            BEGIN
                SELECT
                    precio
                INTO l_precio
                FROM RUG_CAT_TIPO_TRAM_PAGO
                WHERE id_tipo_tramite = pTipoTramite
                AND VIGENCIA_PRECIO IS NULL;

                EXCEPTION WHEN no_data_found THEN
                BEGIN
                    SELECT
                       PRECIO
                    INTO   l_precio
                    FROM
                           RUG_CAT_TIPO_TRAMITE
                    WHERE
                           ID_TIPO_TRAMITE = pTipoTramite
                    ;
                END;
            END;
        END;

    IF pTipoTramite = 1 THEN

        --SELECT
        --       COUNT(*) AS VEHICULOS
        --INTO   l_vehiculos
        --FROM
               --RUG_GARANTIAS_BIENES_H
        --WHERE
               --ID_TRAMITE        = pIdTramite
               --AND TIPO_BIEN_ESPECIAL = 1
        --;

        IF pPendiente = 1 THEN         
            SELECT
                   COUNT(*) AS FACTURAS
            INTO   l_facturas
            FROM
                   RUG_GARANTIAS_BIENES_PEND
            WHERE
                   ID_TRAMITE_TEMP        = pIdTramite
                   AND TIPO_BIEN_ESPECIAL = 2;                        
        ELSE 
            SELECT
                   COUNT(*) AS FACTURAS
            INTO   l_facturas
            FROM
                   RUG_GARANTIAS_BIENES_H
            WHERE
                   ID_TRAMITE        = pIdTramite
                   AND TIPO_BIEN_ESPECIAL = 2
            ;
        END IF;

        l_arancel := 20*l_facturas;

        IF(NVL(l_arancel,0) = 0) THEN
           l_arancel := l_precio;
        END IF;

    ELSE
        l_arancel := l_precio;

    END IF;

    --REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'FN_PRECIO_REAL', 'arancel', l_arancel, 'OUT');

    RETURN l_arancel;

	EXCEPTION 
        WHEN OTHERS THEN
            vlDescMensajeError := SUBSTR(SQLCODE||'-'||SQLERRM,1,1000);  
            REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'FN_PRECIO_REAL', 'ERROR', vlDescMensajeError, 'OUT');
            RETURN NULL;
END;
/

