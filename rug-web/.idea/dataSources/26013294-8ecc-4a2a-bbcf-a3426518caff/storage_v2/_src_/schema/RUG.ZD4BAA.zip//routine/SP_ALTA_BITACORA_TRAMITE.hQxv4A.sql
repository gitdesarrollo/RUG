create PROCEDURE           SP_ALTA_BITACORA_TRAMITE 
(
  peIdTramiteTemp           IN RUG_BITAC_TRAMITES.ID_TRAMITE_TEMP%TYPE,
  peIdStatus                IN RUG_BITAC_TRAMITES.ID_STATUS%TYPE,
  peIdPaso                  IN RUG_BITAC_TRAMITES.ID_PASO%TYPE,
  peFechaCreacion           IN VARCHAR2,
  peBanderaFecha            IN CHAR, --BANDERA QUE INDICA SI EL PL PLASMA LA FECHA CON EL SYSDATE O USA LA QUE MANDA EN peFechaCreacion, VALORES POSIBLES V o F
  psResult                  OUT  INTEGER,
  psTxResult                OUT  VARCHAR2
)
IS


vlResult        NUMBER;
vlTxResult      VARCHAR2(500);

BEGIN

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_BITACORA_TRAMITE', 'FIRMA: ANTES DE ENTRAR', '0', 'IN');

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_BITACORA_TRAMITE', 'peFechaCreacion', peFechaCreacion, 'IN');

    SP_ALTA_BITACORA_TRAMITE2(peIdTramiteTemp, 3, 0, NULL, 'V', vlResult, vlTxResult);

    IF (vlresult = 0) THEN
      BEGIN

        -- 'DD/MM/YYYY - HH24:MI:SS'

        SP_ALTA_BITACORA_TRAMITE2(peIdTramiteTemp, 3, 100,  TO_DATE (peFechaCreacion, 'YYYY-MM-DD HH24:MI:SS'), 'F', vlResult, vlTxResult);
      END;

    END IF;

      psResult:=vlresult;
      psTxResult:=vlTxResult;    


    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_BITACORA_TRAMITE', 'FIRMA: AL SALIR', '0', 'IN');

END;
/

