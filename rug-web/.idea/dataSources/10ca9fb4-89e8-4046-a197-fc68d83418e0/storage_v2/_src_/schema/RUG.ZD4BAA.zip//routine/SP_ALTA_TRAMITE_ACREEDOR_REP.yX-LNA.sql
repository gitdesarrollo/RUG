create PROCEDURE         SP_ALTA_TRAMITE_ACREEDOR_REP (peIdPersona            IN     NUMBER, -- IDENTIFICADOR DE LA PESONA K SeLOGUEA
                                                             peIdTipoTramite        IN     NUMBER, --INSCRIPCION , ALTA ACREEDORES, AVISO PREVENTIVO
                                                             peIdPersonaAcreedor    IN     NUMBER, --IDENTIFICADOR UNICO DE LA PERSONA ACREEDOR REPRESENTADO
                                                             pePersonaJuridica      IN     VARCHAR2, --IDENTIFICADOR DE LA PERSONA JURIDICA PUEDE SER PF O PM
                                                             peIdPaso               IN     NUMBER,
                                                             peStatusTram           IN     NUMBER,
                                                             peFechaStatus          IN     DATE,
                                                             psIdTramiteIncompleto  OUT    NUMBER, --IDENTIFICADOR UNICO DEL REGISTRO
                                                             psResult               OUT    INTEGER,   
                                                             psTxResult             OUT    VARCHAR2)
IS

  vlIdTramiteRugIncom  NUMBER;
  Ex_ErrParametro   EXCEPTION;


BEGIN


REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Tramite_Acreedor_Rep', 'peIdPersona', CAST(peIdPersona AS VARCHAR2),'IN');

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Tramite_Acreedor_Rep', 'peIdTipoTramite', CAST(peIdTipoTramite AS VARCHAR2), 'IN');

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Tramite_Acreedor_Rep', 'peIdPersonaAcreedor', CAST(peIdPersonaAcreedor AS VARCHAR2), 'IN');

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Tramite_Acreedor_Rep', 'pePersonaJuridica', pePersonaJuridica, 'IN');

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Tramite_Acreedor_Rep', 'peIdPaso', CAST(peIdPaso AS VARCHAR2), 'IN');

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Tramite_Acreedor_Rep', 'peStatusTram', CAST(peStatusTram AS VARCHAR2), 'IN');

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Tramite_Acreedor_Rep', 'peFechaStatus', CAST(peFechaStatus AS VARCHAR2), 'IN');


vlIdTramiteRugIncom:= SEQ_TRAM_INCOMP.NEXTVAL;

  IF pePersonaJuridica IS NULL OR peIdTipoTramite IS NULL OR peIdPersona IS NULL THEN
  RAISE Ex_ErrParametro;
  END IF;

  INSERT INTO TRAMITES_RUG_INCOMP VALUES(vlIdTramiteRugIncom,peIdPersona,peIdTipoTramite,SYSDATE,NULL,'AC', peIdPaso, 0, peFechaStatus,0);

  INSERT INTO RUG_REL_TRAM_INC_PARTES VALUES(vlIdTramiteRugIncom, peIdPersonaAcreedor, 4,  pePersonaJuridica, 'AC', SYSDATE);

  INSERT INTO RUG_BITAC_TRAMITES VALUES(vlIdTramiteRugIncom, 0, SYSDATE, 0, peIdTipoTramite, SYSDATE, 'AC');



  COMMIT;

  psIdTramiteIncompleto:=vlIdTramiteRugIncom;

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Tramite_Acreedor_Rep', 'psIdTramiteIncompleto', CAST(psIdTramiteIncompleto AS VARCHAR2), 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Tramite_Acreedor_Rep', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Tramite_Acreedor_Rep', 'psTxResult', psTxResult, 'OUT');    


  psResult:=0;   
  psTxResult:= 'ALTA EXITOSA';--pkg_infz_inst_fenx.FunObtMsgErr(psResult);
EXCEPTION 
  WHEN Ex_ErrParametro  THEN
   psResult:=13;
   SELECT DESC_CODIGO   
   INTO psTxResult
   FROM RUG_CAT_MENSAJES_ERRORES
   WHERE ID_CODIGO = psResult;     
      rollback;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Tramite_Acreedor_Rep', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Tramite_Acreedor_Rep', 'psTxResult', psTxResult, 'OUT');    


   WHEN OTHERS THEN
   ROLLBACK;
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);


END;
/

