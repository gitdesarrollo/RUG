create view V_GARANTIA_TRANSMISION_PARTES as
SELECT   a.ID_GARANTIA,
            a.ID_PERSONA,
            c.DESC_PARTE,
            b.PER_JURIDICA,
            DECODE (b.PER_JURIDICA,
                    'PF', (SELECT   NOMBRE_PERSONA
                             FROM   RUG_PERSONAS_FISICAS
                            WHERE   ID_PERSONA = b.ID_PERSONA),
                    NULL)
               AS NOMBRE,
            DECODE (b.PER_JURIDICA,
                    'PF', (SELECT   AP_PATERNO
                             FROM   RUG_PERSONAS_FISICAS
                            WHERE   ID_PERSONA = b.ID_PERSONA),
                    NULL)
               AS APELLIDO_PATERNO,
            DECODE (b.PER_JURIDICA,
                    'PF', (SELECT   AP_MATERNO
                             FROM   RUG_PERSONAS_FISICAS
                            WHERE   ID_PERSONA = b.ID_PERSONA),
                    NULL)
               APELLIDO_MATERNO,
            DECODE (b.PER_JURIDICA,
                    'PM', (SELECT   RAZON_SOCIAL
                             FROM   RUG_PERSONAS_MORALES
                            WHERE   ID_PERSONA = b.ID_PERSONA),
                    NULL)
               AS RAZON_SOCIAL,
            b.FOLIO_MERCANTIL,
            b.RFC
     FROM   RUG_REL_GARANTIA_PARTES a,
            RUG_PERSONAS b,
            RUG_PARTES c,
            RUG_GARANTIAS d
    WHERE       D.ID_RELACION = A.ID_RELACION
            AND A.ID_PERSONA = B.ID_PERSONA
            AND A.ID_PARTE = C.ID_PARTE
/

