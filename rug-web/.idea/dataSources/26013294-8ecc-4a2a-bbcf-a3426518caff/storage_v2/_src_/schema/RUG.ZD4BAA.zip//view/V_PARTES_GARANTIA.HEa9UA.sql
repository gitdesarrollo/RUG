create view V_PARTES_GARANTIA as
SELECT   RRTG.ID_TRAMITE,
            RRT.ID_GARANTIA,
            RRT.ID_PERSONA,
            RRT.ID_PARTE,
            RGP.DESC_PARTE,
            PER.PER_JURIDICA,
            DECODE (
               PER.PER_JURIDICA,
               'PF',
               (SELECT      NOMBRE_PERSONA
                         || ' '
                         || AP_PATERNO
                         || ' '
                         || AP_MATERNO
                  FROM   RUG_PERSONAS_FISICAS
                 WHERE   ID_PERSONA = RRT.ID_PERSONA),
               'PM',
               (SELECT   RAZON_SOCIAL
                  FROM   RUG_PERSONAS_MORALES
                 WHERE   ID_PERSONA = RRT.ID_PERSONA)
            )
               AS NOMBRE,
            PER.FOLIO_MERCANTIL,
            PER.RFC
     FROM            RUG_REL_GARANTIA_PARTES RRT
                  INNER JOIN
                     RUG_PERSONAS PER
                  ON RRT.ID_PERSONA = PER.ID_PERSONA
               INNER JOIN
                  RUG_PARTES RGP
               ON RRT.ID_PARTE = RGP.ID_PARTE
            INNER JOIN
               RUG_REL_TRAM_GARAN RRTG
            ON RRTG.ID_GARANTIA = RRT.ID_GARANTIA
/

