create view V_TRAMITES_TERMINADOS2 as
SELECT   TRAM.ID_TRAMITE,
            TRAM.ID_TIPO_TRAMITE,
            GTT.DESCRIPCION,                        /* RUG_CAT_TIPO_TRAMITE */
            TRAM.FECH_PRE_INSCR,
            TRAM.FECHA_INSCR,
            RELT.ID_GARANTIA,                     /* REG_REL_TRAM_INC_GARAN */
            RTP.ID_PERSONA,                        /*RUG_REL_TRAM_INC_PARTES*/
            RTP.PER_JURIDICA,
            DECODE (
               RTP.PER_JURIDICA,
               'PF',
               (SELECT      NOMBRE_PERSONA
                         || ' '
                         || AP_PATERNO
                         || ' '
                         || AP_MATERNO
                  FROM   RUG_PERSONAS_FISICAS
                 WHERE   ID_PERSONA = RTP.ID_PERSONA),
               'PM',
               (SELECT   RAZON_SOCIAL
                  FROM   RUG_PERSONAS_MORALES
                 WHERE   ID_PERSONA = RTP.ID_PERSONA)
            )
               AS NOMBRE,
            RGP.FOLIO_MERCANTIL,                            /* RUG_PERSONAS */
            TRAM.ID_STATUS_TRAM,
            STT.DESCRIP_STATUS,                           /* STATUS_TRAMITE */
            GTT.PRECIO,                             /* RUG_CAT_TIPO_TRAMITE */
            RBB.FECHA_STATUS,
            NULL AS VALOR,
            TRAM.ID_PERSONA AS ID_PERSONA_LOGIN,           /* RUG_CAT_PASOS */
            TRAM.ID_TRAMITE_TEMP,
            RTP.ID_PARTE,
            DECODE (RTP.ID_PARTE, 1, (SELECT   RFC
                                        FROM   RUG_PERSONAS
                                       WHERE   ID_PERSONA = RTP.ID_PERSONA))
               RFC,
            (SELECT   ID_PERSONA
               FROM   RUG_REL_TRAM_PARTES
              WHERE   ID_TRAMITE = TRAM.ID_TRAMITE AND ID_PARTE = 4)
               ID_ACREEDOR
     FROM   tramites TRAM,
            rug_cat_tipo_tramite GTT,
            rug_rel_tram_garan RELT,
            rug_rel_tram_partes RTP,
            rug_personas RGP,
            status_tramite STT,
            RUG_BITAC_TRAMITES RBB
    WHERE       TRAM.ID_TIPO_TRAMITE = GTT.ID_TIPO_TRAMITE
            AND TRAM.ID_TRAMITE = RELT.ID_TRAMITE(+)
            AND TRAM.ID_TRAMITE = RTP.ID_TRAMITE(+)
            AND RTP.ID_PARTE = 1
            AND RGP.ID_PERSONA = RTP.ID_PERSONA
            AND STT.ID_STATUS_TRAM = TRAM.ID_STATUS_TRAM
            AND TRAM.ID_TRAMITE_TEMP = RBB.ID_TRAMITE_TEMP
            AND RBB.ID_STATUS = 3
            AND RELT.STATUS_REG = 'AC'
            AND RGP.SIT_PERSONA = 'AC'
   UNION ALL
   SELECT   TRAM.ID_TRAMITE,
            TRAM.ID_TIPO_TRAMITE,
            GTT.DESCRIPCION,                        /* RUG_CAT_TIPO_TRAMITE */
            TRAM.FECH_PRE_INSCR,
            TRAM.FECHA_INSCR,
            0 ID_GARANTIA,                        /* REG_REL_TRAM_INC_GARAN */
            RTP.ID_PERSONA,                        /*RUG_REL_TRAM_INC_PARTES*/
            RTP.PER_JURIDICA,
            DECODE (
               RTP.PER_JURIDICA,
               'PF',
               (SELECT      NOMBRE_PERSONA
                         || ' '
                         || AP_PATERNO
                         || ' '
                         || AP_MATERNO
                  FROM   RUG_PERSONAS_FISICAS
                 WHERE   ID_PERSONA = RTP.ID_PERSONA),
               'PM',
               (SELECT   RAZON_SOCIAL
                  FROM   RUG_PERSONAS_MORALES
                 WHERE   ID_PERSONA = RTP.ID_PERSONA)
            )
               AS NOMBRE,
            RGP.FOLIO_MERCANTIL,                            /* RUG_PERSONAS */
            TRAM.ID_STATUS_TRAM,
            STT.DESCRIP_STATUS,                           /* STATUS_TRAMITE */
            GTT.PRECIO,                             /* RUG_CAT_TIPO_TRAMITE */
            RBB.FECHA_STATUS,
            NULL AS VALOR,
            TRAM.ID_PERSONA AS ID_PERSONA_LOGIN,           /* RUG_CAT_PASOS */
            TRAM.ID_TRAMITE_TEMP,
            RTP.ID_PARTE,
            DECODE (RTP.ID_PARTE, 1, (SELECT   RFC
                                        FROM   RUG_PERSONAS
                                       WHERE   ID_PERSONA = RTP.ID_PERSONA))
               RFC,
            (SELECT   ID_PERSONA
               FROM   RUG_REL_TRAM_PARTES
              WHERE   ID_TRAMITE = TRAM.ID_TRAMITE AND ID_PARTE = 4)
               ID_ACREEDOR
     FROM   tramites TRAM,
            rug_cat_tipo_tramite GTT,
            rug_rel_tram_partes RTP,
            rug_personas RGP,
            status_tramite STT,
            RUG_BITAC_TRAMITES RBB
    WHERE       TRAM.ID_TIPO_TRAMITE = GTT.ID_TIPO_TRAMITE
            AND TRAM.ID_TRAMITE = RTP.ID_TRAMITE(+)
            AND RTP.ID_PARTE = 1
            AND RGP.ID_PERSONA = RTP.ID_PERSONA
            AND TRAM.ID_STATUS_TRAM = 3
            AND STT.ID_STATUS_TRAM = TRAM.ID_STATUS_TRAM
            AND TRAM.ID_TRAMITE_TEMP = RBB.ID_TRAMITE_TEMP
            AND RBB.ID_STATUS = 3
            AND TRAM.STATUS_REG = 'AC'
            AND RGP.SIT_PERSONA = 'AC'
            AND GTT.ID_TIPO_TRAMITE IN (10, 3, 11, 5)
/

