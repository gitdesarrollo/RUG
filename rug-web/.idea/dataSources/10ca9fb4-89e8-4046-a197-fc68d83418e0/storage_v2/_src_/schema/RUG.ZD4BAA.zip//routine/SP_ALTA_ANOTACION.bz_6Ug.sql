create PROCEDURE         SP_ALTA_ANOTACION (
                                                    peIdPersona         IN  NUMBER,
                                                    peIdTramiteTemp     IN  NUMBER,
                                                    peIdGarantia        IN  NUMBER,
                                                    peAutoridadAutoriza IN  VARCHAR2,
                                                    peAnotacion         IN  RUG_ANOTACIONES.ANOTACION%TYPE,
                                                    peVigenciaAnotacion IN  NUMBER,
                                                    psResult           OUT  NUMBER,
                                                    psTxResult         OUT  VARCHAR2                                                                                                        
                                               )
IS

vlUsuario           NUMBER;
vlIdAnotacion       NUMBER;
vlCountAcreedor     NUMBER;
vlIdGarantiaPend    NUMBER;
vlCountTramitesTemp NUMBER;

Ex_ErrParametro EXCEPTION;


fk_exception  EXCEPTION;

PRAGMA EXCEPTION_INIT (fk_exception, -02291);


    CURSOR cursPartes(cpeIdGarantia IN NUMBER) IS

    SELECT   RPP.ID_PERSONA, RPP.ID_PARTE, RGG.PER_JURIDICA
      FROM         RUG_REL_GARANTIA_PARTES RPP
                INNER JOIN
                   RUG_PERSONAS RGG
                ON RPP.ID_PERSONA = RGG.ID_PERSONA
             INNER JOIN
                RUG_GARANTIAS RGT
             ON RPP.ID_RELACION = RGT.ID_RELACION
     WHERE   RPP.ID_GARANTIA = cpeIdGarantia;

    cursPartes_Rec cursPartes%ROWTYPE;

BEGIN


REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ANOTACION', 'peIdPersona', peIdPersona, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ANOTACION', 'peIdTramiteTemp', peIdTramiteTemp, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ANOTACION', 'peIdGarantia', peIdGarantia, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ANOTACION', 'peAutoridadAutoriza', peAutoridadAutoriza, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ANOTACION', 'peAnotacion', '', 'IN');

    vlIdAnotacion:= SEQ_ANOTACIONES.NEXTVAL;

    vlIdGarantiaPend := SEQ_GARANTIAS_TEMP.NEXTVAL;

    SELECT COUNT(*)
      INTO vlUsuario 
      FROM V_USUARIO_LOGIN_RUG
     WHERE ID_PERSONA = peIdPersona;


    IF(vlUsuario = 0)THEN

        psResult := 2;
        RAISE Ex_ErrParametro;

    END IF;   


    IF (peVigenciaAnotacion > 9999) THEN

        psResult := 74;
        RAISE Ex_ErrParametro;  

    END IF;


    BEGIN   

        INSERT INTO RUG_ANOTACIONES 
        VALUES (vlIdAnotacion, peIdGarantia, peAutoridadAutoriza, peAnotacion, SYSDATE, 'AC', peIdTramiteTemp, peIdPersona, peVigenciaAnotacion);

    EXCEPTION

        WHEN fk_exception THEN
        BEGIN
          psResult := 14;
          RAISE Ex_ErrParametro;
        END;

    END;


    INSERT INTO RUG_GARANTIAS_PENDIENTES (ID_GARANTIA_PEND, ID_ANOTACION, ID_GARANTIA_MODIFICAR)
    VALUES(vlIdGarantiaPend, vlIdAnotacion, peIdGarantia);


  /*
            INICIO
            insercion relacion tipo_bien
            EEE
        */
        INSERT INTO RUG.RUG_REL_GAR_TIPO_BIEN
            SELECT 
                vlIdGarantiaPend, BIEN.ID_TIPO_BIEN, BIEN.RELACION_BIEN
                --, RUGPEND.ID_GARANTIA_MODIFICAR
            FROM RUG.RUG_GARANTIAS_PENDIENTES RUGPEND
            INNER JOIN RUG.RUG_REL_GAR_TIPO_BIEN BIEN
            ON 
                RUGPEND.ID_GARANTIA_PEND = BIEN.ID_GARANTIA_PEND
                AND RUGPEND.ID_GARANTIA_MODIFICAR=peIdGarantia
                AND BIEN.RELACION_BIEN IS NOT NULL
                AND ROWNUM = 1
            ORDER BY 1 DESC
            ;
        /*
            FIN
            insercion relacion tipo_bien
            EEE
        */


    --INSERTO RELACION DE PARTES QUE TENIA LA GARANTIA A ESTE NUEVO TRAMITE 
    BEGIN
        FOR cursPartes_Rec IN cursPartes(peIdGarantia)
            LOOP

                SELECT COUNT(*)
                  INTO vlCountAcreedor
                  FROM RUG_REL_TRAM_INC_PARTES
                 WHERE ID_TRAMITE_TEMP = peIdTramiteTemp
                   AND ID_PERSONA = cursPartes_Rec.ID_PERSONA
                   AND ID_PARTE = cursPartes_Rec.ID_PARTE;

                IF (vlCountAcreedor = 0) THEN    

                    INSERT INTO RUG_REL_TRAM_INC_PARTES
                    VALUES(peIdTramiteTemp, cursPartes_Rec.ID_PERSONA, cursPartes_Rec.ID_PARTE, cursPartes_Rec.PER_JURIDICA, 'AC', SYSDATE);

                END IF;

            END LOOP;
    END;

    SELECT COUNT(ID_TRAMITE_TEMP)
    INTO vlCountTramitesTemp
    FROM RUG_REL_TRAM_INC_GARAN
    WHERE ID_TRAMITE_TEMP = peIdTramiteTemp;

    IF vlCountTramitesTemp > 0 THEN

        psResult   :=10;

        RAISE Ex_ErrParametro;

    ELSE

        INSERT INTO RUG_REL_TRAM_INC_GARAN
        VALUES(vlIdGarantiaPend, peIdTramiteTemp, 'AC', SYSDATE);

    END IF;    

  COMMIT;

  psResult:=0;   
  psTxResult:= 'ALTA EXITOSA';

  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ANOTACION', 'psResult', psResult, 'OUT');
  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ANOTACION', 'psTxResult', psTxResult, 'OUT');

  EXCEPTION
  WHEN Ex_ErrParametro  THEN

    psTxResult := RUG.FN_MENSAJE_ERROR(psResult);

    ROLLBACK;
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ANOTACION', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ANOTACION', 'psTxResult', psTxResult, 'OUT');
    DBMS_OUTPUT.PUT_LINE(psTxResult);

   WHEN OTHERS THEN

      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      ROLLBACK;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ANOTACION', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ANOTACION', 'psTxResult', psTxResult, 'OUT');
      DBMS_OUTPUT.PUT_LINE(psTxResult); 

END SP_ALTA_ANOTACION;
/

