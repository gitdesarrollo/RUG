create PROCEDURE         SP_TRAMITES_REASIGNADOS 
                            (
                                peIdAcreedor         IN     NUMBER,
                                peIdPersonaCambio    IN     NUMBER,
                                peIdGrupoDestino     IN     NUMBER,
                                peIdGrupoModificar   IN     NUMBER,
                                pePrivilegios        IN     VARCHAR2,
                                peOperacion          IN     NUMBER,  --1 PARA MODIFICACION DE PRIVILEGIOS DE GRUPOS, 2 PARA CAMBIO DE GRUPO, 3 CAMBIO DE ACREEDOR        
                                psResult            OUT     INTEGER,   
                                psTxResult          OUT     VARCHAR2                             
                            )
IS
                        
CURSOR cursPrivilegios (cpePrivilegios IN VARCHAR2) IS
SELECT TO_CHAR(ID_PRIVILEGIO) 
FROM RUG.RUG_REL_GRUPO_PRIVILEGIO
WHERE ID_GRUPO = peIdGrupoModificar
AND SIT_RELACION = 'AC'
MINUS
SELECT COLUMN_VALUE AS PRIVILEGIOS
FROM   TABLE (RUG.SPLIT_TEM (pePrivilegios, '|'));

CURSOR cursPrivilegiosUsuario (cpeIdGrupoOrigen IN NUMBER, cpeIdGrupoDestino IN NUMBER) IS
SELECT ID_PRIVILEGIO FROM RUG.RUG_REL_GRUPO_PRIVILEGIO
WHERE ID_GRUPO = cpeIdGrupoOrigen AND  SIT_RELACION = 'AC' -- ORIGEN
MINUS
SELECT ID_PRIVILEGIO FROM RUG.RUG_REL_GRUPO_PRIVILEGIO
WHERE ID_GRUPO = cpeIdGrupoDestino AND  SIT_RELACION = 'AC'; -- DESTINO



vlIdPrivilegio      NUMBER;
vlIdTipoTramite     NUMBER;
vlCountTramReasig   NUMBER;
vlGrupoOrigen       NUMBER;

BEGIN
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_TRAMITES_REASIGNADOS', 'peIdAcreedor', peIdAcreedor, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_TRAMITES_REASIGNADOS', 'peIdPersonaCambio', peIdPersonaCambio, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_TRAMITES_REASIGNADOS', 'peIdGrupoDestino', peIdGrupoDestino, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_TRAMITES_REASIGNADOS', 'peIdGrupoModificar', peIdGrupoModificar, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_TRAMITES_REASIGNADOS', 'pePrivilegios', pePrivilegios, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_TRAMITES_REASIGNADOS', 'peOperacion', peOperacion, 'IN');

    IF peOperacion = 1 THEN --MODIFICACION DE PRIVILEGIOS DE GRUPOS
        OPEN cursPrivilegios(pePrivilegios);
            LOOP
                FETCH cursPrivilegios INTO vlIdPrivilegio;
                EXIT WHEN cursPrivilegios%NOTFOUND;
                    CASE
                        WHEN vlIdPrivilegio = 14 THEN
                        BEGIN
                            vlIdTipoTramite := 3;
                        END;
                        WHEN vlIdPrivilegio = 17 THEN
                        BEGIN
                            vlIdTipoTramite := 14;
                        END;
                    ELSE
                           vlIdTipoTramite := vlIdPrivilegio;         
                    END CASE;

                    SELECT COUNT(*)
                    INTO vlCountTramReasig
                    FROM RUG.V_TRAMITES_SUBUSUARIOS
                    WHERE ID_GRUPO = peIdGrupoModificar
                    AND ID_TIPO_TRAMITE = vlIdPrivilegio;

                    IF vlCountTramReasig > 0 THEN
                        INSERT INTO RUG.RUG_TRAMITES_REASIGNADOS(ID_ACREEDOR, ID_TRAMITE_TEMP, STATUS_REG, FECHA_REG)
                        SELECT VTP.ID_ACREEDOR, VTP.ID_TRAMITE_TEMP, 'AC', SYSDATE
                        FROM V_TRAMITES_PENDIENTES VTP,
                        RUG_REL_GRUPO_ACREEDOR RRG
                        WHERE VTP.ID_PERSONA_LOGIN = RRG.ID_SUB_USUARIO
                        AND VTP.ID_ACREEDOR = RRG.ID_ACREEDOR
                        AND RRG.ID_GRUPO = peIdGrupoModificar
                        AND VTP.ID_TIPO_TRAMITE = vlIdTipoTramite
                        AND ID_STATUS <> 0;
                    END IF;  
            END LOOP;
        CLOSE cursPrivilegios;
    ELSIF peOperacion = 2 THEN --CAMBIO DE GRUPO
        SELECT ID_GRUPO
        INTO vlGrupoOrigen 
        FROM RUG.RUG_REL_GRUPO_ACREEDOR
        WHERE ID_ACREEDOR = peIdAcreedor
        AND ID_SUB_USUARIO = peIdPersonaCambio
        AND STATUS_REG = 'AC';

        OPEN cursPrivilegiosUsuario(vlGrupoOrigen, peIdGrupoDestino);
            LOOP
                FETCH cursPrivilegiosUsuario INTO vlIdPrivilegio;
                EXIT WHEN cursPrivilegiosUsuario%NOTFOUND;
                 CASE
                        WHEN vlIdPrivilegio = 14 THEN
                        BEGIN
                            vlIdTipoTramite := 3;
                        END;
                        WHEN vlIdPrivilegio = 17 THEN
                        BEGIN
                            vlIdTipoTramite := 14;
                        END;
                    ELSE
                           vlIdTipoTramite := vlIdPrivilegio;         
                    END CASE;

                    SELECT COUNT(*)
                    INTO vlCountTramReasig
                    FROM RUG.V_TRAMITES_SUBUSUARIOS
                    WHERE ID_GRUPO = vlGrupoOrigen
                    AND ID_TIPO_TRAMITE = vlIdTipoTramite;

                    IF vlCountTramReasig > 0 THEN
                        INSERT INTO RUG.RUG_TRAMITES_REASIGNADOS(ID_ACREEDOR, ID_TRAMITE_TEMP, STATUS_REG, FECHA_REG)
                        SELECT ID_ACREEDOR, ID_TRAMITE_TEMP, 'AC', SYSDATE
                        FROM RUG.V_TRAMITES_PENDIENTES
                        WHERE ID_PERSONA_LOGIN = peIdPersonaCambio
                        AND ID_ACREEDOR = peIdAcreedor
                        AND ID_TIPO_TRAMITE = vlIdTipoTramite;
                    END IF; 
            END LOOP;
        CLOSE cursPrivilegiosUsuario;

    ELSIF peOperacion = 3 then


        FOR vlIdPersona IN (
                                SELECT ID_SUB_USUARIO
                                FROM RUG.RUG_REL_GRUPO_ACREEDOR
                                WHERE ID_ACREEDOR = peIdAcreedor
                                AND ID_GRUPO = peIdGrupoDestino
                                --AND STATUS_REG = 'AC'

                           ) LOOP   


            INSERT INTO RUG.RUG_TRAMITES_REASIGNADOS(ID_ACREEDOR, ID_TRAMITE_TEMP, STATUS_REG, FECHA_REG)
            SELECT ID_ACREEDOR, ID_TRAMITE_TEMP, 'AC', SYSDATE
            FROM RUG.V_TRAMITES_PENDIENTES
            WHERE ID_PERSONA_LOGIN = vlIdPersona.ID_SUB_USUARIO
            AND ID_ACREEDOR = peIdAcreedor;


            INSERT INTO RUG.RUG_TRAMITES_REASIGNADOS(ID_ACREEDOR, ID_TRAMITE_TEMP, STATUS_REG, FECHA_REG)
            SELECT ID_ACREEDOR, ID_TRAMITE_TEMP, 'AC', SYSDATE
            FROM RUG.V_TRAMITES_TERMINADOS
            WHERE ID_PERSONA_LOGIN = vlIdPersona.ID_SUB_USUARIO
            AND ID_ACREEDOR = peIdAcreedor;



        END LOOP;


    END IF;   


    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_TRAMITES_REASIGNADOS', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_TRAMITES_REASIGNADOS', 'psTxResult', psTxResult, 'OUT');    


EXCEPTION
   WHEN OTHERS THEN
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      ROLLBACK;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_TRAMITES_REASIGNADOS', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_TRAMITES_REASIGNADOS', 'psTxResult', psTxResult, 'OUT');
END SP_TRAMITES_REASIGNADOS;
/

