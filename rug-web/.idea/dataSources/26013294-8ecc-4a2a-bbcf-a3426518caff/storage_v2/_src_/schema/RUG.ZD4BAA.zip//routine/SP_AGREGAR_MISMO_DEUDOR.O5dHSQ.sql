create PROCEDURE         SP_AGREGAR_MISMO_DEUDOR ( 
  peIdTramite      IN RUG_REL_TRAM_INC_GARAN.ID_TRAMITE_TEMP%TYPE,
  peIdOtorgante  IN RUG_REL_TRAM_INC_GARAN.ID_GARANTIA_PEND%TYPE,
  psResult      OUT    INTEGER,   
  psTxResult    OUT    VARCHAR2
 )
IS 
/*
Primer PL de Abrahamcito Chulo muajajaja
*/
vlPerJuridica CHAR(2);
vlNumPartes   NUMBER;
BEGIN

  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AGREGAR_MISMO_DEUDOR', 'peIdTramite', peIdTramite, 'IN');
  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AGREGAR_MISMO_DEUDOR', 'peIdOtorgante', peIdOtorgante, 'IN');

  SELECT PER_JURIDICA
  INTO vlPerJuridica
  FROM RUG_PERSONAS
  WHERE ID_PERSONA = peIdOtorgante;

  SELECT COUNT (*)
  INTO vlNumPartes
  FROM RUG_REL_TRAM_INC_PARTES
  WHERE ID_TRAMITE_TEMP = peIdTramite AND ID_PERSONA = peIdOtorgante AND ID_PARTE = 2;

  IF vlNumPartes > 0 THEN
    UPDATE RUG_REL_TRAM_INC_PARTES
    SET STATUS_REG = 'AC'
    WHERE ID_TRAMITE_TEMP = peIdTramite AND ID_PERSONA = peIdOtorgante AND ID_PARTE = 2;
  ELSE
   INSERT INTO RUG.RUG_REL_TRAM_INC_PARTES
   VALUES (peidtramite , peIdOtorgante,2, vlPerJuridica,'AC', SYSDATE);  
  END IF;

  COMMIT;  
  psresult:=0;
  pstxresult:='Todo sin problema.!';
  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AGREGAR_MISMO_DEUDOR', 'psresult', psresult, 'OUT');
  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AGREGAR_MISMO_DEUDOR', 'pstxresult', pstxresult, 'OUT');
  EXCEPTION 
  WHEN OTHERS THEN
     dbms_output.put_line('Error en la transaccion:'||SQLERRM);
     dbms_output.put_line('Se deshacen las modificaciones');
     psresult:=909;
     pstxresult:= substr(SQLCODE||':'||SQLERRM,1,250);
     REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AGREGAR_MISMO_DEUDOR', 'psresult', psresult, 'OUT');
     REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AGREGAR_MISMO_DEUDOR', 'pstxresult', pstxresult, 'OUT');
     ROLLBACK;

END SP_AGREGAR_MISMO_DEUDOR;
/

