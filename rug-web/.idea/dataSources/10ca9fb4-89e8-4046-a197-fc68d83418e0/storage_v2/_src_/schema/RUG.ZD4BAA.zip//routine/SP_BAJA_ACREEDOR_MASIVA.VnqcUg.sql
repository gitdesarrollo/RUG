create PROCEDURE         SP_BAJA_ACREEDOR_MASIVA 
                                                    (
                                                        peIdTramiteFirma     IN  NUMBER,
                                                        peIdUsuario          IN  NUMBER,
                                                        psResult            OUT  INTEGER,   
                                                        psTxResult          OUT  VARCHAR2                             
                                                    )
IS


vlIdTramiteTemp     NUMBER;
vlIdPersona         NUMBER;
vlIdArchivo         NUMBER;


CURSOR  cursEliminaAcreedor (peIdFirma IN NUMBER) IS
SELECT A.ID_TRAMITE_TEMP, A.ID_PERSONA, B.ID_ARCHIVO
          FROM RUG_REL_TRAM_INC_PARTES A,
               RUG_FIRMA_MASIVA B
         WHERE A.ID_TRAMITE_TEMP = B.ID_TRAMITE_TEMP
           AND B.ID_FIRMA_MASIVA = peIdFirma
           AND A.ID_PARTE = 4;

Ex_Error EXCEPTION;


BEGIN


    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_ACREEDOR_M', 'peIdTramiteFirma', peIdTramiteFirma, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_ACREEDOR_M', 'peIdUsuario', peIdUsuario, 'IN');

    OPEN    cursEliminaAcreedor(peIdTramiteFirma);
        LOOP
            FETCH   cursEliminaAcreedor INTO vlIdTramiteTemp, vlIdPersona, vlIdArchivo;
            EXIT WHEN  cursEliminaAcreedor%NOTFOUND;

                DELETE RUG_REL_TRAM_INC_PARTES
                WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;                

                DELETE RUG_DOMICILIOS_EXT
                 WHERE ID_DOMICILIO IN (SELECT ID_DOMICILIO FROM RUG_PERSONAS WHERE ID_PERSONA = vlIdPersona);

                DELETE RUG_DOMICILIOS
                 WHERE ID_DOMICILIO IN (SELECT ID_DOMICILIO FROM RUG_PERSONAS WHERE ID_PERSONA = vlIdPersona);

                DELETE RUG_TELEFONOS
                WHERE ID_PERSONA = vlIdPersona;

                DELETE RUG_PERSONAS_MORALES
                WHERE ID_PERSONA = vlIdPersona;

                DELETE RUG_PERSONAS_FISICAS
                WHERE ID_PERSONA = vlIdPersona;

                DELETE REL_USU_ACREEDOR
                 WHERE ID_USUARIO = peIdUsuario
                   AND ID_ACREEDOR = vlIdPersona;

                DELETE RUG_REL_GRUPO_ACREEDOR
                 WHERE ID_SUB_USUARIO = peIdUsuario
                   AND ID_USUARIO = peIdUsuario
                   AND ID_ACREEDOR = vlIdPersona;


                DELETE RUG_PERSONAS
                WHERE ID_PERSONA = vlIdPersona;

                DELETE RUG_CONTRATO
                 WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;

                DELETE RUG_FIRMA_MASIVA
                 WHERE ID_FIRMA_MASIVA = peIdTramiteFirma;

                DELETE RUG_CARGA_POOL
                WHERE id_archivo_firma = vlIdArchivo;

                DELETE RUG_CARGA_POOL
                WHERE id_archivo = vlIdArchivo;

                DELETE RUG_ARCHIVO
                 WHERE ID_ARCHIVO = vlIdArchivo;

        END LOOP;

    CLOSE cursEliminaAcreedor;

    psResult   := 0;        
    psTxResult := RUG.FN_MENSAJE_ERROR(psResult);

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_ACREEDOR_M', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_ACREEDOR_M', 'psTxResult', psTxResult, 'OUT');    


EXCEPTION 
WHEN Ex_Error  THEN      
      psTxResult := RUG.FN_MENSAJE_ERROR(psResult);
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_ACREEDOR_M', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_ACREEDOR_M', 'psTxResult', psTxResult, 'OUT');
      ROLLBACK;
WHEN OTHERS THEN
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_ACREEDOR_M', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_ACREEDOR_M', 'psTxResult', psTxResult, 'OUT');
      ROLLBACK;
END;
/

