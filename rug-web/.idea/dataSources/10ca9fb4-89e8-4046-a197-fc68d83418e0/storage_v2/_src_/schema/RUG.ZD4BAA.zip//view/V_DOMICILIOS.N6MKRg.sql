create view V_DOMICILIOS as
SELECT   RD.ID_DOMICILIO ID_DOMICILIO,
            (RD.CALLE) CALLE,
            (RD.NUM_EXTERIOR) NUM_EXTERIOR,
            (RD.NUM_INTERIOR) NUM_INTERIOR,
            SCC.ID_COLONIA ID_COLONIA,
            SCC.CVE_COLONIA CVE_COLONIA,
            SCC.DESC_COLONIA NOM_COLONIA,
            DECODE (NVL (SCL.ID_LOCALIDAD, 0),
                    0, SCC.CVE_MUNICIP_DELEG,
                    SCL.CVE_MUNICIP_DELEG)
               CVE_DELEG_MUNICIP,
            (DECODE (NVL (SCL.ID_LOCALIDAD, 0),
                     0, scmd1.DESC_MUNICIP_DELEG,
                     scmd2.DESC_MUNICIP_DELEG))
               NOM_DELEG_MUNICIP,
            DECODE (NVL (SCL.ID_LOCALIDAD, 0),
                    0, SCC.CVE_ESTADO,
                    SCL.CVE_ESTADO)
               CVE_ESTADO,
            (DECODE (NVL (SCL.ID_LOCALIDAD, 0),
                     0, SCE1.DESC_ESTADO,
                     SCE2.DESC_ESTADO))
               NOM_ESTADO,
            DECODE (NVL (SCL.ID_LOCALIDAD, 0),
                    0, SCC.CODIGO_POSTAL,
                    SCL.CODIGO_POSTAL)
               CODIGO_POSTAL,
            SCP.CVE_PAIS,
            (SCP.DESC_PAIS) NOM_PAIS,
            SCL.ID_LOCALIDAD ID_LOCALIDAD,
            SCL.CVE_LOCALIDAD CVE_LOCALIDAD,
            (SCL.DESC_LOCALIDAD) LOCALIDAD,
            RD.ID_VIALIDAD ID_VIALIDAD,
            (SCTV.DESC_TIPO_VIALIDAD) VIALIDAD,
            (TX_REFER_ADICIONAL) REFERENCIA,
            '' UBICA_DOMICILIO_1,
            '' UBICA_DOMICILIO_2,
            '' POBLACION,
            '' ZONA_POSTAL,
            1 ID_PAIS_RESIDENCIA
     FROM   RUG_DOMICILIOS RD,
            SE_CAT_PAISES SCP,
            SE_CAT_COLONIAS SCC,
            SE_CAT_MUNICIP_DELEG scmd2,
            SE_CAT_ESTADOS SCE2,
            SE_CAT_LOCALIDADES SCL,
            SE_CAT_MUNICIP_DELEG scmd1,
            SE_CAT_ESTADOS SCE1,
            INSTITUCIONAL.V_SE_CAT_TIPOS_VIALIDAD SCTV
    WHERE       SCP.CVE_PAIS = 'MEX'
            AND SCC.ID_COLONIA(+) = RD.ID_COLONIA
            AND SCL.ID_LOCALIDAD(+) = RD.ID_LOCALIDAD
            AND SCTV.ID_TIPO_VIALIDAD(+) = RD.ID_VIALIDAD
            AND SCE1.CVE_PAIS(+) = 'MEX'
            AND SCE1.CVE_ESTADO(+) = SCC.CVE_ESTADO
            AND SCE2.CVE_PAIS(+) = 'MEX'
            AND SCE2.CVE_ESTADO(+) = SCL.CVE_ESTADO
            AND scmd1.CVE_PAIS(+) = 'MEX'
            AND scmd1.CVE_ESTADO(+) = SCC.CVE_ESTADO
            AND scmd1.CVE_MUNICIP_DELEG(+) = SCC.CVE_MUNICIP_DELEG
            AND scmd2.CVE_PAIS(+) = 'MEX'
            AND scmd2.CVE_ESTADO(+) = SCL.CVE_ESTADO
            AND scmd2.CVE_MUNICIP_DELEG(+) = SCL.CVE_MUNICIP_DELEG
   UNION ALL
   SELECT   RDE.ID_DOMICILIO ID_DOMICILIO,
            '' CALLE,
            '' NUM_EXTERIOR,
            '' NUM_INTERIOR,
            0 ID_COLONIA,
            '' CVE_COLONIA,
            '' NOM_COLONIA,
            0 CVE_DELEG_MUNICIP,
            '' NOM_DELEG_MUNICIP,
            '' CVE_ESTADO,
            '' NOM_ESTADO,
            '' CODIGO_POSTAL,
            '' CVE_PAIS,
            '' NOM_PAIS,
            0 ID_LOCALIDAD,
            '' CVE_LOCALIDAD,
            '' LOCALIDAD,
            0 ID_VIALIDAD,
            '' VIALIDAD,
            '' REFERENCIA,
            RDE.UBICA_DOMICILIO_1,
            RDE.UBICA_DOMICILIO_2,
            RDE.POBLACION,
            RDE.ZONA_POSTAL,
            RDE.ID_PAIS_RESIDENCIA
     FROM   RUG_DOMICILIOS_EXT RDE
/

