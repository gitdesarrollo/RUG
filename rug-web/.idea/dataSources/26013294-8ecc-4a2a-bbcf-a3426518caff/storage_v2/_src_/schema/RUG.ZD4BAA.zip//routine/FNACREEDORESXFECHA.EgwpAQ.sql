create FUNCTION           FNACREEDORESXFECHA (Fecha Date) RETURN NUMBER IS
vlTotal1  number;
vlTotal2  number;
vlTotal3  number;
BEGIN
 vlTotal1:=0;
 vlTotal2:=0;
 vlTotal3:=0;
  --- Se suman los que tienen RFC
  SELECT /*+RULE*/  
         COUNT(CONTADOR)
  INTO VLTOTAL1      
  FROM ( SELECT /*+RULE*/ 
                  1 CONTADOR  
           FROM ( SELECT /*+RULE*/ 
                         MIN(DECODE(ID_PERFIL, 4, 1,2,2, 1, 3 )) TIPO_PERFIL,
                         RFC_ACREEDOR
                  FROM V_REP_BASE_ACREEDORES
                  WHERE REGEXP_SUBSTR(RFC_ACREEDOR,  '^AAA[0|1]{6}') IS NULL
                  AND TRUNC(FECHA_STATUS)= FECHA
                  GROUP BY RFC_ACREEDOR
                ) T1,
                ( SELECT /*+RULE*/ 
                         ID_ACREEDOR,
                         DECODE(ID_PERFIL, 4, 1,2,2, 1, 3 ) TIPO_PERFIL,
                         RFC_ACREEDOR
                  FROM V_REP_BASE_ACREEDORES
                ) T2               
           WHERE T1.RFC_ACREEDOR=T2.RFC_ACREEDOR
           AND T1.TIPO_PERFIL=T2.TIPO_PERFIL       
           GROUP BY   T1.TIPO_PERFIL, T1.RFC_ACREEDOR
       );
  --- Se suman los que NO tienen RFC o tienen RFC Generico
  SELECT /*+RULE*/  
         COUNT(CONTADOR)
  INTO VLTOTAL2      
  FROM ( SELECT /*+RULE*/ 
                  1 CONTADOR
         FROM V_REP_BASE_ACREEDORES
         WHERE (REGEXP_SUBSTR(RFC_ACREEDOR,  '^AAA[0|1]{6}') IS NOT NULL
                OR RFC_ACREEDOR IS NULL)
         AND TRUNC (FECHA_STATUS)= FECHA
         GROUP BY TRIM(NOMBRE_ACREEDOR)
       ) ;

  VLTOTAL3 := VLTOTAL1+ VLTOTAL2;
--select * from V_REP_BASE_ACREEDORES where id_acreedor = 3621  
   RETURN vlTotal3;

   EXCEPTION
     WHEN NO_DATA_FOUND THEN
       return null;
     WHEN OTHERS THEN
       return null;
END FnAcreedoresXFecha;
/

