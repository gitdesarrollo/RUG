create FUNCTION         FN_GETACREEDOR (
                                                   peIdGarantia     RUG_GARANTIAS.ID_GARANTIA%TYPE,
                                                   peOpcion       NUMBER --1 Nombre, 2 ID
                                                   )
RETURN VARCHAR2 

IS
    vlDescError VARCHAR2(200);
	vlSeparador VARCHAR(10);
    vlNameAcreedor VARCHAR2(500);
	vlIDAcreedor VARCHAR2(500);

	vlPersona RUG_PERSONAS_H.NOMBRE_PERSONA%TYPE;
	vlRfc RUG_PERSONAS_H.RFC%TYPE;
    vlCurp RUG_PERSONAS_H.CURP%TYPE;
    vlJuridica RUG_PERSONAS_H.PER_JURIDICA%TYPE;

	CURSOR listAcreedores IS
	SELECT a.nombre_persona, a.rfc, a.curp, a.per_juridica
	FROM RUG_PERSONAS_H a
	WHERE a.id_tramite = peIdGarantia
	AND a.id_parte IN (1,2);

BEGIN

	vlSeparador := '<br>';

	BEGIN    
            OPEN listAcreedores;
                LOOP
                    FETCH listAcreedores 
                    INTO vlPersona,vlRfc,vlCurp,vlJuridica;
                    EXIT WHEN listAcreedores%NOTFOUND;                    
                    vlNameAcreedor := CONCAT(vlNameAcreedor, vlPersona || vlSeparador);
                    IF(vlJuridica = 'PM') THEN
                        vlIDAcreedor := CONCAT(vlIDAcreedor, vlRfc || vlSeparador);
                    ELSE
                        vlIDAcreedor := CONCAT(vlIDAcreedor, vlCurp || vlSeparador);
                    END IF;
                END LOOP;
            CLOSE listAcreedores;

        END;    

	IF(peOpcion = 1) THEN
		REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'FN_GETACREEDOR', 'vlDescAcreedor', vlNameAcreedor, 'OUT');
		RETURN vlNameAcreedor;
	ELSE
		REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'FN_GETACREEDOR', 'vlDescAcreedor', vlIDAcreedor, 'OUT');
		RETURN vlIDAcreedor;
	END IF;

	EXCEPTION 
        WHEN NO_DATA_FOUND THEN
            vlDescError := 'No se encontro el acreedor solicitado';            
            SP_LOG('FN_GETACREEDOR',14||' - '||SUBSTR(SQLCODE||'-'||SQLERRM,1,1000));

        WHEN OTHERS THEN
            SP_LOG('FN_GETACREEDOR',SUBSTR(SQLCODE||'-'||SQLERRM,1,1000));
            RETURN NULL;

END;
/

