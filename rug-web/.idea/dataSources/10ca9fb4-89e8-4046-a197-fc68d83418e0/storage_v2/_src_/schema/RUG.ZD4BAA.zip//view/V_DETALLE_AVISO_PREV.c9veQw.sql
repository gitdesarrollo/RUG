create view V_DETALLE_AVISO_PREV
            (ID_TRAMITE, DESC_BIENES, ID_USUARIO, NOMBRE_USUARIO, FECHA_CREACION, PERFIL, VIGENCIA, ANOTACION_JUEZ,
             FOLIO_OTORGANTE)
as
SELECT   TRI.ID_TRAMITE,
            AVP.DESC_BIENES,
            AVP.ID_USUARIO,
            (SELECT      F.NOMBRE_PERSONA
                      || ' '
                      || F.AP_PATERNO
                      || ' '
                      || F.AP_MATERNO
               FROM   RUG_PERSONAS_H F
              WHERE       F.ID_PERSONA = AVP.ID_USUARIO
                      AND ID_TRAMITE = TRI.ID_TRAMITE
                      AND F.ID_PARTE = 6)
               AS NOMBRE_USUARIO,
            TO_CHAR (RBB.FECHA_STATUS, 'DD/MM/YYYY - HH24:MI:SS')
            || DECODE ( (SELECT   COUNT ( * )
                           FROM   V_FIRMA_DOCTOS
                          WHERE   ID_TRAMITE_TEMP = TRI.ID_TRAMITE_TEMP),
                       1, ' * ZULU GMT / UTC',
                       ' * Hora central Mexico, D.F.')
               AS FECHA_CREACION,
            RSU.CVE_PERFIL AS PERFIL,
            '15 dias naturales improrrogables ',
            NVL (RUA.ANOTACION_JUEZ, 'N/A'),
            (SELECT   RPP.FOLIO_MERCANTIL
               FROM   RUG_PERSONAS RPP, RUG_REL_TRAM_PARTES RRT
              WHERE       RPP.ID_PERSONA = RRT.ID_PERSONA
                      AND RRT.ID_PARTE = 1
                      AND RRT.ID_TRAMITE = TRI.ID_TRAMITE)
     FROM               AVISOS_PREV AVP
                     INNER JOIN
                        TRAMITES TRI
                     ON AVP.ID_TRAMITE_TEMP = TRI.ID_TRAMITE_TEMP
                  INNER JOIN
                     RUG_BITAC_TRAMITES RBB
                  ON TRI.ID_TRAMITE_TEMP = RBB.ID_TRAMITE_TEMP
               INNER JOIN
                  RUG_SECU_PERFILES_USUARIO RSU
               ON AVP.ID_USUARIO = RSU.ID_PERSONA
            LEFT JOIN
               RUG_AUTORIDAD RUA
            ON AVP.ID_TRAMITE_TEMP = RUA.ID_TRAMITE_TEMP
    WHERE   RBB.ID_STATUS IN (3, 10) AND RBB.STATUS_REG = 'AC'
/

