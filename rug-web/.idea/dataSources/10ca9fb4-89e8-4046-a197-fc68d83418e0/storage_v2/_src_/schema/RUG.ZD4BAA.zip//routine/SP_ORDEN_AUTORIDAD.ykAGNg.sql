create PROCEDURE         SP_ORDEN_AUTORIDAD 
                            (
                               
                                peID_TRAMITE_TEMP   IN   NUMBER,
                                peANOTACION_JUEZ    IN   VARCHAR2,                              
                                psResult            OUT  INTEGER,   
                                psTxResult          OUT  VARCHAR2                             
                            )

IS

vlTipoTramite       NUMBER;
vlCountOrdenJuez    NUMBER;
vlANOTACION_JUEZ    NUMBER;
vlPerfil            VARCHAR2(20);

Ex_Error            EXCEPTION;

BEGIN


REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ORDEN_AUTORIDAD', 'peID_TRAMITE_TEMP ', peID_TRAMITE_TEMP , 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ORDEN_AUTORIDAD', 'peANOTACION_JUEZ', peANOTACION_JUEZ, 'IN');



    SELECT B.CVE_PERFIL, A.ID_TIPO_TRAMITE
      INTO vlPerfil, vlTipoTramite
      FROM TRAMITES_RUG_INCOMP A, RUG_SECU_PERFILES_USUARIO B
     WHERE B.ID_PERSONA = A.ID_PERSONA
       AND A.ID_TRAMITE_TEMP = peID_TRAMITE_TEMP;

    IF vlPerfil != 'AUTORIDAD' THEN

        psResult := 0;
        RAISE Ex_Error;

    END IF;   

    IF(peANOTACION_JUEZ IS NULL OR peANOTACION_JUEZ = '') THEN

        CASE
            WHEN vlTipoTramite = 1 THEN
            BEGIN 

                psResult := 114;
                RAISE Ex_Error;

            END;
            WHEN vlTipoTramite = 2 THEN
            BEGIN 

                psResult := 82;
                RAISE Ex_Error;

            END;
            WHEN vlTipoTramite = 3 THEN 
            BEGIN 

                psResult := 83;
                RAISE Ex_Error;

            END;                
            WHEN vlTipoTramite = 4 THEN 
            BEGIN 

                psResult := 84; -- GGR  09/05/2013   INICSCN2013-52
                RAISE Ex_Error;

            END;
            WHEN vlTipoTramite = 6 THEN 
            BEGIN 


                psResult := 86;
                RAISE Ex_Error;

            END;            
            WHEN vlTipoTramite = 7 THEN 
            BEGIN 

                psResult := 87;
                RAISE Ex_Error;

            END;
            WHEN vlTipoTramite = 8 THEN 
            BEGIN 

                psResult := 88;
                RAISE Ex_Error;

            END;            
            WHEN vlTipoTramite = 9 THEN 
            BEGIN 

                psResult := 89;
                RAISE Ex_Error;

            END;
            WHEN vlTipoTramite = 10 THEN 
            BEGIN 

                psResult := 90;
                RAISE Ex_Error;

            END;



        END CASE;

    END IF;


    SELECT COUNT(*)
      INTO vlCountOrdenJuez
      FROM RUG_AUTORIDAD
     WHERE ID_TRAMITE_TEMP = peID_TRAMITE_TEMP;


    IF vlCountOrdenJuez = 1 THEN

        UPDATE RUG_AUTORIDAD
           SET ANOTACION_JUEZ = peANOTACION_JUEZ
         WHERE ID_TRAMITE_TEMP =  peID_TRAMITE_TEMP;

    ELSIF vlCountOrdenJuez = 0 THEN

        vlANOTACION_JUEZ := SEQ_AUTORIDAD.NEXTVAL;        

        INSERT INTO RUG_AUTORIDAD (ID_AUTORIDAD, ID_TRAMITE_TEMP, ANOTACION_JUEZ, STATUS_REG, FECHA_REG)
        VALUES (vlANOTACION_JUEZ, peID_TRAMITE_TEMP, peANOTACION_JUEZ, 'AC', SYSDATE);      

    END IF;

    COMMIT;

    psResult   :=0;        
    psTxResult :='Actualizacion finalizada satisfactoriamente';

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ORDEN_AUTORIDAD', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ORDEN_AUTORIDAD', 'psTxResult', psTxResult, 'OUT');    


EXCEPTION

    WHEN Ex_Error  THEN

      psTxResult := RUG.FN_MENSAJE_ERROR(psResult);

      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ORDEN_AUTORIDAD', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ORDEN_AUTORIDAD', 'psTxResult', psTxResult, 'OUT');
      COMMIT;

   WHEN OTHERS THEN
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      ROLLBACK;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ORDEN_AUTORIDAD', 'pspeANOTACION_JUEZ', peANOTACION_JUEZ, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ORDEN_AUTORIDAD', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ORDEN_AUTORIDAD', 'psTxResult', psTxResult, 'OUT');
      DBMS_OUTPUT.PUT_LINE(psTxResult);
END SP_ORDEN_AUTORIDAD;
/

