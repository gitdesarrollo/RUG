create PROCEDURE         SP_MODIFICA_PARTE_ANTERIOR 
                            ( 
                                peIdPersonaModificar   IN  NUMBER, --ID DE LA PERSONA QUE SE VA A MODIFICAR
                                peIdTramiteTemp        IN  NUMBER, --ID TRAMITE DEL CUAL SE VA A MODIFICAR LA PARTE
                                peIdParteModificar     IN  NUMBER,  -- ID DE PARTE ANTERIOR DE LA PERSONA QUE SE VA A MODIFICAR
                                peIdParte              IN  NUMBER,  -- NUEVO ID DE PARTE DE LA PERSONA A MODIFICAR
                                peTipoPersona          IN  VARCHAR2, -- Fisica (PF) o Moral(PM)                              
                                peRazonSocial          IN  VARCHAR2, --Razon social (solo persona moral)
                                peNombre               IN  VARCHAR2,  --(solo persona fisica)
                                peApellidoP            IN  VARCHAR2,  --(solo persona fisica)
                                peApellidoM          IN  VARCHAR2,  --(solo persona fisica)
                                peFolioMercantil     IN  VARCHAR2,
                                peRFC                IN  VARCHAR2,
                                peCURP               IN  VARCHAR2,
                                peBDomicilio         IN  CHAR,      --BANDERA QUE INDICA SI SE MANDA EL DOMICILIO LOS VALORES SON V o F
                                peCalle              IN  VARCHAR2,
                                peNumExt             IN  VARCHAR2,
                                peNumInt             IN  VARCHAR2,                                
                                peIdColonia          IN  NUMBER,           
                                peIdLocalidad        IN  NUMBER,
                                peIdUsuario          IN  NUMBER,  --idPersona Usuario
                                peIdNacionalidad     IN  NUMBER,
                                peTelefono           IN  VARCHAR2,
                                peExtension          IN  VARCHAR2,   
                                peEmail              IN  VARCHAR2, 
                                psResult            OUT  INTEGER,   
                                psTxResult          OUT  VARCHAR2                             
                            )
IS


vlIdPersona   NUMBER;
vlIdDomicilio NUMBER; 
vlBFirmado    CHAR(2);
Ex_ErrParametro EXCEPTION;
vlIdPersonaModificar NUMBER;
Ex_PersonaNoExiste EXCEPTION;

BEGIN

   REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peIdPersonaModificar', CAST(peIdPersonaModificar AS VARCHAR2), 'IN');
   REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peIdTramiteTemp', CAST(peIdTramiteTemp AS VARCHAR2), 'IN');
   REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peIdParteModificar', CAST(peIdParteModificar AS VARCHAR2), 'IN');
   REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peIdParte', CAST(peIdParte AS VARCHAR2), 'IN');
   REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peTipoPersona', peTipoPersona, 'IN');
   REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peRazonSocial', peRazonSocial, 'IN'); 
   REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peNombre', peNombre, 'IN');
   REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peApellidoP', peApellidoP, 'IN');
   REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peApellidoM', peApellidoM, 'IN');
   REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peFolioMercantil', peFolioMercantil, 'IN');
   REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peRFC', peRFC, 'IN');
   REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peCURP', peCURP, 'IN');
   REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peBDomicilio', peBDomicilio, 'IN');
   REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peCalle', peCalle, 'IN');
   REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peNumExt', peNumExt, 'IN');
   REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peNumInt', peNumInt, 'IN');
   REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peIdColonia', CAST(peIdColonia AS VARCHAR2), 'IN');
   REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peIdLocalidad', CAST(peIdLocalidad AS VARCHAR2), 'IN');
   REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peIdUsuario', CAST(peIdUsuario AS VARCHAR2), 'IN');
   REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peIdNacionalidad', CAST(peIdNacionalidad AS VARCHAR2), 'IN');
   REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peTelefono', peTelefono, 'IN');
   REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peExtension', peExtension, 'IN');
   REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peEmail', peEmail, 'IN');


   vlIdDomicilio := SEQ_RUG_ID_DOMICILIO.NEXTVAL;        

        IF(peBDomicilio = 'V') THEN

        INSERT INTO RUG_DOMICILIOS (ID_DOMICILIO, CALLE, NUM_EXTERIOR, NUM_INTERIOR, ID_COLONIA, CALLE_COLINDANTE_1, CALLE_COLINDANTE_2,
                                       CALLE_POSTERIOR, LOCALIDAD, ID_VIALIDAD, TX_REFER_ADICIONAL, ID_TIPO_DOMICILIO, ID_LOCALIDAD)
        VALUES   (vlIdDomicilio, peCalle, peNumExt, peNumInt, DECODE(peIdColonia, -1, 0,peIdColonia), NULL, NULL, NULL, NULL, NULL, NULL, NULL, DECODE(peIdLocalidad,-1,0,peIdLocalidad));

        END IF;

        vlIdPersona:= SEQ_RUG_ID_PERSONA.NEXTVAL;


        INSERT INTO RUG_PERSONAS (ID_PERSONA, RFC, ID_NACIONALIDAD, PER_JURIDICA, FH_REGISTRO, PROCEDENCIA, SIT_PERSONA,
                                     CVE_NACIONALIDAD, ID_DOMICILIO, FOLIO_MERCANTIL, FECHA_INSCR_CC, REG_TERMINADO, ID_PERSONA_MODIFICAR, E_MAIL, CURP_DOC)
        VALUES   (vlIdPersona, peRFC, peIdNacionalidad, peTipoPersona, TRUNC(SYSDATE), 'NAL', 'AC', NULL, vlIdDomicilio, peFolioMercantil, NULL, 'N', peIdPersonaModificar, peEmail, peCURP);


        IF(UPPER(peTipoPersona) = 'PM') THEN


            INSERT INTO RUG_PERSONAS_MORALES (ID_PERSONA, RAZON_SOCIAL, SIGLAS_MERCANTIL, ID_PAIS_ORIGEN, IMP_CAP_SOC_FIJO,
                                                 B_CONSEJO_ADMON, NUM_ACCIONES, VALOR_NOMINAL_ACC, F_CONSTITUCION, ID_PERS_REPRESNTE_LEGAL,
                                                 B_EXCLUSION_EXTRANJEROS, CVE_PAIS_ORIGEN, CVE_USUARIO_REGISTRO, IMP_CAP_VARIABLE,
                                                 NUM_ACC_CAP_VAR, VAL_NOM_ACC_CAP_VAR, F_INI_ACTIVIDAD, NOMBRE_COMERCIAL)
            VALUES   (vlIdPersona, peRazonSocial, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);


        ELSIF (UPPER(peTipoPersona) = 'PF') THEN


            INSERT INTO RUG_PERSONAS_FISICAS (ID_PERSONA, NOMBRE_PERSONA, AP_PATERNO, AP_MATERNO, CURP, ID_CALIDAD_MIGRAT, ID_PAIS_NACIM,
                                                 F_NACIMIENTO, ESTADO_CIVIL, OCUPACION_ACTUAL, SEXO, CVE_PAIS_NACIM, CVE_ESTADO_NACIM,
                                                 CVE_MUN_DEL_NACIM, LUGAR_NAC_PERS_EXT, FOLIO_DOCTO_MIGRAT, CVE_ESCOLARIDAD)
            VALUES   (vlIdPersona, peNombre, peApellidoP, peApellidoM, peCURP, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

        END IF;

        IF(peIdParte IN (3,4)) THEN

            INSERT INTO RUG_TELEFONOS
            VALUES (vlIdPersona, NULL, peTelefono, peExtension, SYSDATE, 'AC');

        END IF;

        IF peIdParte = 4 THEN

           SELECT ID_ACREEDOR , B_FIRMADO
             INTO vlIdPersonaModificar, vlBFirmado
             FROM  REL_USU_ACREEDOR
            WHERE ID_USUARIO = peIdUsuario 
              AND ID_ACREEDOR = peIdPersonaModificar;

            IF vlIdPersonaModificar IS NOT NULL THEN

                UPDATE REL_USU_ACREEDOR
                SET STATUS_REG = 'IN'
                WHERE ID_USUARIO = peIdUsuario AND ID_ACREEDOR = peIdPersonaModificar;

                INSERT INTO REL_USU_ACREEDOR
                VALUES(peIdUsuario, vlIdPersona, vlBFirmado, SYSDATE, 'AC');


                INSERT INTO RUG_REL_TRAM_INC_PARTES( ID_TRAMITE_TEMP,  ID_PERSONA, ID_PARTE, PER_JURIDICA, STATUS_REG, FECHA_REG)
                VALUES (peIdTramiteTemp, vlIdPersona, peIdParte, peTipoPersona, 'AC', SYSDATE);


                COMMIT;

            ELSE
                RAISE Ex_PersonaNoExiste;
            END IF;

        ELSE

            UPDATE RUG_REL_TRAM_INC_PARTES
            SET STATUS_REG = 'IN', FECHA_REG = SYSDATE
            WHERE ID_TRAMITE_TEMP = peIdTramiteTemp AND ID_PERSONA = peIdPersonaModificar AND ID_PARTE = peIdParteModificar;

            INSERT INTO RUG_REL_TRAM_INC_PARTES( ID_TRAMITE_TEMP,  ID_PERSONA, ID_PARTE, PER_JURIDICA, STATUS_REG, FECHA_REG)
            VALUES (peIdTramiteTemp, vlIdPersona, peIdParte, peTipoPersona, 'AC', SYSDATE);

            COMMIT;

        END IF;

  ROLLBACK;

  psResult   :=0;        
  psTxResult :='Actualizacion finalizada satisfactoriamente';

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'psTxResult', psTxResult, 'OUT');    


EXCEPTION 
 WHEN Ex_PersonaNoExiste  THEN   
      psResult  := 12;         
      SELECT DESC_CODIGO
      INTO psTxResult
      FROM RUG_CAT_MENSAJES_ERRORES
      WHERE ID_CODIGO = psResult;
      ROLLBACK;
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'psTxResult', psTxResult, 'OUT');

  WHEN Ex_ErrParametro  THEN         
      psTxResult:= substr(psResult,1,250);
      ROLLBACK;
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'psTxResult', psTxResult, 'OUT');    

   WHEN OTHERS THEN
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      ROLLBACK;
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'psTxResult', psTxResult, 'OUT');    


END SP_MODIFICA_PARTE_ANTERIOR;
/

