create view V_TRAMITES_PENDIENTES as
SELECT   TCR.ID_TRAMITE_TEMP AS ID_TRAMITE_TEMP,
            TCR.ID_TIPO_TRAMITE AS ID_TIPO_TRAMITE,
            -- GGR 11042013 - MMESCN2013-81  /* INICIO */
            RUG.FN_BORRA_SIN_CON_GARANTIA(TTR.DESCRIPCION) AS TIPO_TRAMITE,
            -- GGR 11042013 - MMESCN2013-81  /* FIN */
            TTR.PRECIO AS PRECIO,
            RBB.FECHA_STATUS AS FECHA_STATUS,
            SST.DESCRIP_STATUS AS DESCRIP_STATUS,
            TCR.ID_STATUS_TRAM AS ID_STATUS,
            RAN.ID_GARANTIA_PEND AS ID_GARANTIA_PEND,
            TPS.DESC_GARANTIA AS DESC_GARANTIA,
            FNCONCATOTORGANTE (TCR.ID_TRAMITE_TEMP, 3) NOMBRE,
            FNCONCATOTORGANTE (TCR.ID_TRAMITE_TEMP, 4) FOLIO_MERCANTIL,
            TCR.ID_PERSONA AS ID_PERSONA_LOGIN,
            RSS.URL AS URL,
            TCR.ID_PASO AS ID_PASO,
            (SELECT   ID_PERSONA
               FROM   rug.RUG_REL_TRAM_INC_PARTES
              WHERE       ID_TRAMITE_TEMP = TCR.ID_TRAMITE_TEMP
                      AND ID_PARTE = 4
                      AND STATUS_REG = 'AC')
               ID_ACREEDOR,
            TPS.ID_GARANTIA_MODIFICAR AS ID_GARANTIA_MODIFICAR,
            CASE WHEN RTR.ID_TRAMITE_TEMP IS NOT NULL THEN 'V' ELSE 'F' END
               AS TRAMITE_REASIGNADO,
            NULL DESC_TRAM_FIRMA
     FROM   rug.TRAMITES_RUG_INCOMP TCR
     LEFT JOIN rug.RUG_CAT_TIPO_TRAMITE TTR
       ON   TCR.ID_TIPO_TRAMITE = TTR.ID_TIPO_TRAMITE
     LEFT JOIN rug.RUG_BITAC_TRAMITES RBB
       ON   TCR.ID_TRAMITE_TEMP = RBB.ID_TRAMITE_TEMP
    INNER JOIN rug.STATUS_TRAMITE SST
       ON   TCR.ID_STATUS_TRAM = SST.ID_STATUS_TRAM
     LEFT JOIN rug.RUG_REL_TRAM_INC_GARAN RAN
       ON   TCR.ID_TRAMITE_TEMP = RAN.ID_TRAMITE_TEMP
     LEFT JOIN       (SELECT   *
                        FROM   rug.RUG_GARANTIAS_PENDIENTES
                       WHERE   id_garantia_pend IN
                                     (SELECT   DISTINCT id_garantia_pend
                                        FROM   rug.rug_garantias
                                       WHERE   garantia_status <> 'FV')) TPS
       ON   RAN.ID_GARANTIA_PEND = TPS.ID_GARANTIA_PEND
     LEFT OUTER JOIN rug.RUG_CAT_PASOS RSS
       ON   TCR.ID_PASO = RSS.ID_PASO
     LEFT JOIN rug.RUG_TRAMITES_REASIGNADOS RTR
       ON   TCR.ID_TRAMITE_TEMP = RTR.ID_TRAMITE_TEMP
    WHERE   TCR.ID_STATUS_TRAM <> 3
      AND   TCR.STATUS_REG = 'AC'
      AND   RBB.STATUS_REG = 'AC'
      AND   TCR.ID_TIPO_TRAMITE NOT IN (12, 19
                                        , 26,27,28,29, 25,24,23,22) --- GGR 05122013 - MMESCN2013-81 y 82 
      AND   TCR.ID_TRAMITE_TEMP NOT IN
                 (SELECT   DISTINCT ID_TRAMITE_TEMP
                    FROM   RUG.RUG_FIRMA_MASIVA
                   WHERE   ID_TRAMITE_TEMP IN
                                 (SELECT   DISTINCT ID_TRAMITE_TEMP
                                    FROM   TRAMITES_RUG_INCOMP
                                   WHERE   ID_TIPO_TRAMITE <> 12)
                  UNION ALL
                  SELECT   TRA.ID_TRAMITE_TEMP
                    FROM   rug.TRAMITES_RUG_INCOMP TRA,
                           (SELECT   ID_TRAMITE_TEMP,
                                     ID_PERSONA ID_ACREEDOR
                              FROM   rug.RUG_REL_TRAM_INC_PARTES
                             WHERE   ID_PARTE = 4) PRT,
                           REL_USU_ACREEDOR UACR
                   WHERE       1 = 1
                           AND TRA.ID_TRAMITE_TEMP = PRT.ID_TRAMITE_TEMP
                           AND UACR.ID_USUARIO = TRA.ID_PERSONA
                           AND UACR.ID_ACREEDOR = PRT.ID_ACREEDOR
                           --                               AND TRA.ID_TIPO_TRAMITE <> 12
                           AND TRA.ID_STATUS_TRAM <> 3
                           AND UACR.STATUS_REG = 'IN'
                           AND TRA.ID_PERSONA = TCR.ID_PERSONA)
   UNION ALL
   SELECT   TCR.ID_TRAMITE_TEMP,
            TCR.ID_TIPO_TRAMITE,
            TTR.DESCRIPCION AS TIPO_TRAMITE,
            TTR.PRECIO,
            RBB.FECHA_STATUS,
            SST.DESCRIP_STATUS,
            TCR.ID_STATUS_TRAM AS ID_STATUS,
            NULL ID_GARANTIA_PEND,
            NULL DESC_GARANTIA,
            NULL NOMBRE,
            NULL FOLIO_MERCANTIL,
            TCR.ID_PERSONA AS ID_PERSONA_LOGIN,
            NULL URL,
            TCR.ID_PASO,
            (SELECT   ID_PERSONA
               FROM   rug.RUG_REL_TRAM_INC_PARTES
              WHERE       ID_TRAMITE_TEMP = TCR.ID_TRAMITE_TEMP
                      AND ID_PARTE = 4
                      AND STATUS_REG = 'AC')
               ID_ACREEDOR,
            NULL ID_GARANTIA_MODIFICAR,
            CASE WHEN RTR.ID_TRAMITE_TEMP IS NOT NULL THEN 'V' ELSE 'F' END
               AS TRAMITE_REASIGNADO,
            (SELECT   DISTINCT C.DESCRIPCION
               FROM   rug.TRAMITES_RUG_INCOMP A,
                      rug.RUG_FIRMA_MASIVA B,
                      rug.RUG_CAT_TIPO_TRAMITE C,
                      rug.TRAMITES_RUG_INCOMP D
              WHERE       A.ID_TIPO_TRAMITE = 18
                      AND B.ID_FIRMA_MASIVA = A.ID_TRAMITE_TEMP
                      AND B.ID_TRAMITE_TEMP = D.ID_TRAMITE_TEMP
                      AND D.ID_TIPO_TRAMITE = C.ID_TIPO_TRAMITE
                      AND A.ID_TRAMITE_TEMP = TCR.ID_TRAMITE_TEMP)
               DESC_TRAM_FIRMA
     FROM   rug.TRAMITES_RUG_INCOMP TCR
     LEFT JOIN rug.RUG_CAT_TIPO_TRAMITE TTR
       ON   TCR.ID_TIPO_TRAMITE = TTR.ID_TIPO_TRAMITE
     LEFT JOIN rug.RUG_BITAC_TRAMITES RBB
       ON   TCR.ID_TRAMITE_TEMP = RBB.ID_TRAMITE_TEMP
    INNER JOIN rug.STATUS_TRAMITE SST
       ON   TCR.ID_STATUS_TRAM = SST.ID_STATUS_TRAM
     LEFT JOIN rug.RUG_TRAMITES_REASIGNADOS RTR
       ON   TCR.ID_TRAMITE_TEMP = RTR.ID_TRAMITE_TEMP
    WHERE   TCR.ID_STATUS_TRAM <> 3
      AND   TCR.ID_TIPO_TRAMITE NOT IN (12)
      AND   TCR.STATUS_REG = 'AC'
      AND   RBB.STATUS_REG = 'AC'
      AND   TCR.ID_TRAMITE_TEMP IN
                 (SELECT   DISTINCT ID_FIRMA_MASIVA
                    FROM   RUG.RUG_FIRMA_MASIVA
                   WHERE   ID_TRAMITE_TEMP IN
                                 (SELECT   DISTINCT ID_TRAMITE_TEMP
                                    FROM   TRAMITES_RUG_INCOMP
                                   WHERE   ID_TIPO_TRAMITE <> 12)
                  UNION ALL
                  SELECT   TRA.ID_TRAMITE_TEMP
                    FROM   rug.TRAMITES_RUG_INCOMP TRA,
                           (SELECT   ID_TRAMITE_TEMP,
                                     ID_PERSONA ID_ACREEDOR
                              FROM   rug.RUG_REL_TRAM_INC_PARTES
                             WHERE   ID_PARTE = 4) PRT,
                           REL_USU_ACREEDOR UACR
                   WHERE       1 = 1
                           AND TRA.ID_TRAMITE_TEMP = PRT.ID_TRAMITE_TEMP
                           AND UACR.ID_USUARIO = TRA.ID_PERSONA
                           AND UACR.ID_ACREEDOR = PRT.ID_ACREEDOR
                           AND TRA.ID_TIPO_TRAMITE <> 12
                           AND TRA.ID_STATUS_TRAM <> 3
                           AND UACR.STATUS_REG = 'IN'
                           AND TRA.ID_PERSONA = TCR.ID_PERSONA)
   -- GGR 11042013 - MMESCN2013-81  /* INICIO */
     UNION ALL
   SELECT   AI.ID_ANOTACION_TEMP
        ,   TI.ID_TIPO_TRAMITE  
        ,   REPLACE( 
                REPLACE(TT.DESCRIPCION, 'con Garantía', '')
                   , 'sin Garantía', '')
        ,   TT.PRECIO
        ,   AI.FECHA_REG -- VERIFICAR SI ES LA ÚLTIMA FECHA DE MODIFICACIÓN DEL REGISTRO PORQUE NACE EN ESTATUS 3
        ,   ST.DESCRIP_STATUS
        ,   TI.ID_STATUS_TRAM
        ,   G.ID_GARANTIA
        ,   G.DESC_GARANTIA
        ,   PP.NOMBRE
        ,   P.FOLIO_MERCANTIL
        ,   TI.ID_PERSONA --AI.ID_USUARIO
        ,   '/NULO' AS URL
        ,   0  AS ID_PASO
        ,   NULL AS ID_ACREEDOR
        ,   NULL AS ID_GARANTIA_MODIFICAR
        ,   'F' TRAMITE_REASIGNADO
        ,   NULL AS DESC_TRAM_FIRMA-- ESTO ES LA FIRMA
     FROM   RUG.RUG_ANOTACIONES_SEG_INC_CSG AI
    INNER JOIN RUG.TRAMITES_RUG_INCOMP TI
       ON   TI.ID_TRAMITE_TEMP = AI.ID_ANOTACION_TEMP
    INNER JOIN RUG.RUG_CAT_TIPO_TRAMITE TT
       ON   TT.ID_TIPO_TRAMITE = TI.ID_TIPO_TRAMITE
    INNER JOIN RUG.STATUS_TRAMITE ST
       ON   ST.ID_STATUS_TRAM = TI.ID_STATUS_TRAM-- .ID_STATUS
     LEFT JOIN RUG.RUG_GARANTIAS G          -- NO APLICA PORQUE LA GARANTIA NO ESTA PENDIENTE EL TRAMIITE PADRE FUE COMPLETADO
       ON   G.ID_GARANTIA = AI.ID_GARANTIA
     LEFT JOIN RUG.RUG_REL_TRAM_INC_PARTES TIP
       ON   TIP.ID_TRAMITE_TEMP = TI.ID_TRAMITE_TEMP
      AND   TIP.ID_PARTE = 5
     LEFT JOIN RUG.RUG_PERSONAS P
       ON   P.ID_PERSONA = TIP.ID_PERSONA
     LEFT JOIN RUG.RUG_REL_TRAM_INC_PARTES TIO
       ON   TIO.ID_TRAMITE_TEMP = TI.ID_TRAMITE_TEMP
      AND   TIO.ID_PARTE = 1
     LEFT JOIN ( SELECT PF.ID_PERSONA
                      , PF.NOMBRE_PERSONA ||' '|| PF.AP_PATERNO ||' '|| PF.AP_MATERNO AS NOMBRE
                   FROM RUG.RUG_PERSONAS_FISICAS PF
                 UNION ALL
                 SELECT PM.ID_PERSONA
                      , PM.RAZON_SOCIAL
                   FROM RUG.RUG_PERSONAS_MORALES PM 
               ) PP
       ON   PP.ID_PERSONA = TIO.ID_PERSONA
    WHERE   TI.ID_STATUS_TRAM <> 3
      AND   AI.STATUS_REG = 'AC'

    -- GGR 11042013 - MMESCN2013-81  /* FIN */
/

