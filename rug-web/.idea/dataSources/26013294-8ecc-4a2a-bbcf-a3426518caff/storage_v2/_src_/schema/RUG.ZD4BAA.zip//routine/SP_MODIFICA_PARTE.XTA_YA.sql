create PROCEDURE         SP_MODIFICA_PARTE
                                                     (
                                                         peIdPersonaModificar IN NUMBER
                                                       , --ID DE LA PERSONA QUE SE VA A MODIFICAR
                                                         peIdTramiteTemp IN NUMBER
                                                       , --ID TRAMITE DEL CUAL SE VA A MODIFICAR LA PARTE
                                                         peIdParteModificar IN NUMBER
                                                       , -- ID DE PARTE ANTERIOR DE LA PERSONA QUE SE VA A MODIFICAR
                                                         peIdParte IN NUMBER
                                                       , -- NUEVO ID DE PARTE DE LA PERSONA A MODIFICAR
                                                         peTipoPersona IN VARCHAR2
                                                       , -- Fisica (PF) o Moral(PM)
                                                         peRazonSocial IN VARCHAR2
                                                       , --Razon social (solo persona moral)
                                                         peNombre IN VARCHAR2
                                                       , --(solo persona fisica)
                                                         peApellidoP IN VARCHAR2
                                                       , --(solo persona fisica)
                                                         peApellidoM IN VARCHAR2
                                                       , --(solo persona fisica)
                                                         peFolioMercantil IN VARCHAR2
                                                       , peRFC            IN VARCHAR2
                                                       , peCURP           IN VARCHAR2
                                                       , peBDomicilio     IN CHAR
                                                       , --BANDERA QUE INDICA SI SE MANDA EL DOMICILIO LOS VALORES SON V o F
                                                         peCalle       IN VARCHAR2 --domicilio
                                                       , peNumExt      IN VARCHAR2
                                                       , peNumInt      IN VARCHAR2
                                                       , peIdColonia   IN NUMBER
                                                       , peIdLocalidad IN NUMBER --pais de residencia
                                                       , peIdUsuario   IN NUMBER
                                                       , --idPersona Usuario
                                                         peIdNacionalidad IN NUMBER
                                                       , peTelefono       IN VARCHAR2
                                                       , peExtension      IN VARCHAR2
                                                       , peEmail          IN VARCHAR2
													   , peInscrita		  IN VARCHAR2
													   , peFolio		  IN VARCHAR2
													   , peLibro		  IN VARCHAR2
													   , peUbicada		  IN VARCHAR2
													   , peEdad			  IN VARCHAR2
													   , peEstadoCivil	  IN VARCHAR2
													   , peProfesion	  IN VARCHAR2
                                                       , psResult OUT        INTEGER
                                                       , psTxResult OUT      VARCHAR2
                                                     )
IS
    
    vlCount              NUMBER;
    vlUltimaModif        NUMBER;
    vlIdPersona_h        NUMBER;
    vlIdDomicilio        NUMBER;
    vlBFirmado           CHAR(2);
    Ex_ErrParametro      EXCEPTION;
    vlIdPersonaModificar NUMBER;
    Ex_PersonaNoExiste   EXCEPTION;

    --VARIABLES VALIDACION RFC
    vlPsResultValRFC    NUMBER;
    vlPsTxtResultValRFC VARCHAR(4000);
    Ex_ErrRFC           EXCEPTION;


BEGIN

    BEGIN

        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peIdPersonaModificar', CAST(peIdPersonaModificar AS VARCHAR2), 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peIdTramiteTemp', CAST(peIdTramiteTemp AS           VARCHAR2), 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peIdParteModificar', CAST(peIdParteModificar AS     VARCHAR2), 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peIdParte', CAST(peIdParte AS                       VARCHAR2), 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peTipoPersona', peTipoPersona, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peRazonSocial', peRazonSocial, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peNombre', peNombre, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peApellidoP', peApellidoP, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peApellidoM', peApellidoM, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peFolioMercantil', peFolioMercantil, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peRFC', peRFC, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peCURP', peCURP, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peBDomicilio', peBDomicilio, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peCalle', peCalle, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peNumExt', peNumExt, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peNumInt', peNumInt, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peIdColonia', CAST(peIdColonia AS           VARCHAR2), 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peIdLocalidad', CAST(peIdLocalidad AS       VARCHAR2), 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peIdUsuario', CAST(peIdUsuario AS           VARCHAR2), 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peIdNacionalidad', CAST(peIdNacionalidad AS VARCHAR2), 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peTelefono', peTelefono, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peExtension', peExtension, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peEmail', peEmail, 'IN');
		REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peInscrita', peInscrita, 'IN');
		REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peFolio', peFolio, 'IN');
		REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peLibro', peLibro, 'IN');
		REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peUbicada', peUbicada, 'IN');
		REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peEdad', peEdad, 'IN');
		REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peEstadoCivil', peEstadoCivil, 'IN');
		REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'peProfesion', peProfesion, 'IN');
    END;

    --Esta validacion no aplica
    --RUG.SP_VALIDA_RFC(peIdNacionalidad, peRFC, peTipoPersona, vlPsResultValRFC, vlPsTxtResultValRFC);
    --IF vlPsResultValRFC <> 0 THEN
        --RAISE Ex_ErrRFC;
    --END IF;

    SELECT
           ID_DOMICILIO
    INTO   vlIdDomicilio
    FROM
           RUG_PERSONAS
    WHERE
           ID_PERSONA = peIdPersonaModificar
    ;


    UPDATE
           RUG_DOMICILIOS_EXT
    SET    UBICA_DOMICILIO_1 = NVL(peCalle, UBICA_DOMICILIO_1)
         , ID_PAIS_RESIDENCIA = DECODE(peIdLocalidad, NULL, ID_PAIS_RESIDENCIA, peIdLocalidad)
    WHERE
           ID_DOMICILIO = vlIdDomicilio
    ;



    UPDATE
           RUG_PERSONAS
    SET    RFC             = NVL(peRFC,RFC)
         , ID_NACIONALIDAD = NVL(peIdNacionalidad , ID_NACIONALIDAD)
         , FOLIO_MERCANTIL = NVL('', FOLIO_MERCANTIL)
         , E_MAIL          = NVL(peEmail, E_MAIL)
         , CURP_DOC        = peCURP
         , PER_JURIDICA    = NVL(peTipoPersona, PER_JURIDICA)
         , NIFP             = NVL('',NIFP)
    WHERE
           ID_PERSONA = peIdPersonaModificar
    ;



    IF(UPPER(peTipoPersona) = 'PM') THEN

        UPDATE
               RUG_PERSONAS_MORALES
        SET    RAZON_SOCIAL = NVL(peRazonSocial, RAZON_SOCIAL)
			 , NUM_INSCRITA = NVL(peInscrita, NUM_INSCRITA)
			 , FOLIO = NVL(peFolio, FOLIO)
			 , LIBRO = NVL(peLibro, LIBRO)
			 , UBICADA = NVL(peUbicada, UBICADA)
        WHERE
               ID_PERSONA = peIdPersonaModificar
        ;

    ELSIF (UPPER(peTipoPersona) = 'PF') THEN


        UPDATE
               RUG_PERSONAS_FISICAS
        SET    NOMBRE_PERSONA = NVL(peNombre, NOMBRE_PERSONA)
			 , ESTADO_CIVIL = NVL(peEstadoCivil, ESTADO_CIVIL)
			 , OCUPACION_ACTUAL = NVL(peProfesion, OCUPACION_ACTUAL)
			 , EDAD = NVL(peEdad, EDAD)
        WHERE
               ID_PERSONA = peIdPersonaModificar
        ;


    END IF;

    vlCount := 0;

    SELECT
           COUNT(*)
    INTO   vlCount
    FROM
           RUG_TELEFONOS
    Where
           ID_PERSONA = peIdPersonaModificar
    ;


    IF(vlCount != 0) THEN

        UPDATE
               RUG_TELEFONOS
        SET    TELEFONO  = NVL(peTelefono, TELEFONO)
             , EXTENSION = NVL( peExtension, EXTENSION)
        WHERE
               ID_PERSONA = peIdPersonaModificar
        ;

    END IF;



    COMMIT;

    psResult   :=0;
    psTxResult :='Actualizacion finalizada satisfactoriamente';

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'psTxResult', psTxResult, 'OUT');


EXCEPTION
WHEN Ex_ErrRFC THEN
    psResult   := vlPsResultValRFC;
    psTxResult := vlPsTxtResultValRFC;
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'psTxResult', psTxResult, 'OUT');
    ROLLBACK;
WHEN Ex_PersonaNoExiste THEN
    psResult   := 12;
    psTxResult := RUG.FN_MENSAJE_ERROR(psResult);
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'psTxResult', psTxResult, 'OUT');
    ROLLBACK;
WHEN Ex_ErrParametro THEN
    psTxResult:= substr(psResult,1,250);
    ROLLBACK;
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'psTxResult', psTxResult, 'OUT');
WHEN OTHERS THEN
    psResult  := 999;
    psTxResult:= substr(SQLCODE
    ||':'
    ||SQLERRM,1,250);
    ROLLBACK;
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_PARTE', 'psTxResult', psTxResult, 'OUT');


END SP_MODIFICA_PARTE;
/

