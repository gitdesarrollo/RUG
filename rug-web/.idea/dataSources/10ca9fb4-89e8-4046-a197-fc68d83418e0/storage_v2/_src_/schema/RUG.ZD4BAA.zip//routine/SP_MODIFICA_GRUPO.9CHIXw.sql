create PROCEDURE         SP_MODIFICA_GRUPO 
                            (
                                peIdAcreedor         IN  NUMBER,
                                peIdGrupoModificar   IN  NUMBER,
                                pePrivilegios        IN  VARCHAR2,
                                peIdPersonaModifica  IN  NUMBER, 
                                psResult            OUT  INTEGER,   
                                psTxResult          OUT  VARCHAR2                             
                            )
IS
                        

Ex_GrupoNoExiste    EXCEPTION;
Ex_PrivNoExiste     EXCEPTION;
Ex_UsuarioNoExiste  EXCEPTION;
Ex_GpoAdministrador EXCEPTION;
vlIdGrupo           NUMBER;
vlCount             NUMBER;
vlIdPrivilegio      NUMBER;
vlIdPersonaUsuario  NUMBER;
vlCountRelGrupo     NUMBER;
vlPrivilegio        VARCHAR2(4000);
vlResult            NUMBER;
vlTxtResult         VARCHAR2(4000);
--vlPrivilegios   INSTITUCIONAL.PKGSE_COMUN.T_PALABRAS;

BEGIN

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GRUPO', 'peIdAcreedor', peIdAcreedor, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GRUPO', 'peIdGrupoModificar', peIdGrupoModificar, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GRUPO', 'pePrivilegios', pePrivilegios, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GRUPO', 'peIdPersonaModifica', peIdPersonaModifica, 'IN');

    psResult := 0;   
    psTxResult := 'Modificaci?e grupo, completada correctamente';    
    vlPrivilegio := pePrivilegios  || '|5';
    vlPrivilegio := replace(vlPrivilegio, '||','|');  


        IF peIdGrupoModificar IS NOT NULL THEN
            BEGIN
                SELECT ID_GRUPO
                INTO vlIdGrupo
                FROM RUG.RUG_GRUPOS
                WHERE ID_GRUPO = peIdGrupoModificar;
            EXCEPTION
            WHEN NO_DATA_FOUND THEN 
                RAISE Ex_GrupoNoExiste;        
            END;
        ELSIF peIdGrupoModificar = 1 THEN
            RAISE Ex_GpoAdministrador;
        ELSE
            RAISE Ex_GrupoNoExiste;     
        END IF;

        IF pePrivilegios IS NOT NULL THEN
            BEGIN

                FOR I IN (
                          SELECT  COLUMN_VALUE VALOR 
                            FROM TABLE(
                                       SELECT SPLIT_TEM(vlPrivilegio,'|') 
                                         FROM DUAL)
                           ) 
                    LOOP

                        SELECT COUNT(*)
                          INTO vlCount
                          FROM RUG.RUG_PRIVILEGIOS
                         WHERE ID_PRIVILEGIO = I.VALOR; 

                        IF(vlCount = 0) THEN

                            BEGIN
                                RAISE Ex_PrivNoExiste;
                            END;

                        END IF; 

                    END LOOP;


            EXCEPTION
            WHEN NO_DATA_FOUND THEN
                RAISE Ex_PrivNoExiste;        
            END;
        ELSE
            RAISE Ex_PrivNoExiste;
        END IF;     

        IF peIdPersonaModifica IS NOT NULL THEN
            BEGIN
                SELECT ID_PERSONA
                INTO vlIdPersonaUsuario
                FROM RUG.RUG_SECU_USUARIOS
                WHERE ID_PERSONA = peIdPersonaModifica;
            EXCEPTION
            WHEN NO_DATA_FOUND THEN
                RAISE Ex_UsuarioNoExiste;    
            END;
        ELSE
            RAISE Ex_UsuarioNoExiste;
        END IF;

        vlPrivilegio := pePrivilegios || '|11|12|13|15|18|37';

        BEGIN
            SP_TRAMITES_REASIGNADOS(peIdAcreedor, NULL, NULL, peIdGrupoModificar, pePrivilegios, 1, vlResult, vlTxtResult);
        EXCEPTION
        WHEN OTHERS THEN    
            psResult  := vlResult;   
            psTxResult:= vlTxtResult;
        END;    

        --SE HABILITAN LOS NUEVOS PERMISOS
        BEGIN
            UPDATE RUG.RUG_REL_GRUPO_PRIVILEGIO
            SET SIT_RELACION = 'IN'
            WHERE ID_GRUPO = peIdGrupoModificar;

        --- SE DEJO AQUI PARA HABILITAR LOS PRIVILEGIOS A LOS USUARIOS QUE LES INHABILITO ESTOS EN UNA INCIDENCIA
            UPDATE RUG.RUG_REL_GRUPO_PRIVILEGIO
               SET SIT_RELACION = 'AC'
             WHERE ID_GRUPO = peIdGrupoModificar
               AND ID_PRIVILEGIO IN (12,13,15);

             FOR I IN (
                          SELECT  COLUMN_VALUE VALOR 
                            FROM TABLE(
                                       SELECT SPLIT_TEM(vlPrivilegio,'|') 
                                         FROM DUAL)
                           ) 
                    LOOP

                            SELECT COUNT(*)
                            INTO vlCountRelGrupo
                            FROM RUG.RUG_REL_GRUPO_PRIVILEGIO
                            WHERE ID_GRUPO = peIdGrupoModificar
                            AND ID_PRIVILEGIO = I.VALOR;

                            IF vlCountRelGrupo = 0 THEN
                                INSERT INTO RUG.RUG_REL_GRUPO_PRIVILEGIO
                                VALUES(SEQ_REL_GRUPO_PRIVILEGIO.NEXTVAL, peIdGrupoModificar, I.VALOR, 'AC');
                            ELSIF vlCountRelGrupo > 0 THEN
                                UPDATE RUG.RUG_REL_GRUPO_PRIVILEGIO
                                SET SIT_RELACION = 'AC'
                                WHERE ID_GRUPO = peIdGrupoModificar
                                AND ID_PRIVILEGIO = I.VALOR;
                            END IF;


                             vlCount := 0;


                            SELECT COUNT(*)
                              INTO vlCount 
                             FROM RUG_REL_GRUPO_PRIVILEGIO
                            WHERE ID_GRUPO = peIdGrupoModificar
                              AND ID_PRIVILEGIO = 23
                              AND SIT_RELACION = 'AC';

                            IF (vlCount = 0) THEN

                                SELECT COUNT(*)
                                  INTO vlCount
                                  FROM RUG_PRIVILEGIOS
                                 WHERE UPPER(DESC_PRIVILEGIO) LIKE '%M?TIPLE%'
                                   AND ID_PRIVILEGIO = I.VALOR
                                 ORDER BY 1;

                                IF (vlCount > 0) THEN

                                    INSERT INTO RUG_REL_GRUPO_PRIVILEGIO
                                    VALUES(SEQ_REL_GRUPO_PRIVILEGIO.NEXTVAL, peIdGrupoModificar,  23, 'AC');

                                END IF;

                            END IF;


                    END LOOP;


        END;

    COMMIT;

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GRUPO', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GRUPO', 'psTxResult', psTxResult, 'OUT');    

EXCEPTION
WHEN Ex_GrupoNoExiste THEN
  psResult := 25;
  psTxResult := RUG.FN_MENSAJE_ERROR(psResult);
  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GRUPO', 'psResult', psResult, 'OUT');
  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GRUPO', 'psTxResult', psTxResult, 'OUT');
WHEN Ex_PrivNoExiste THEN
  psResult := 26;
  psTxResult := RUG.FN_MENSAJE_ERROR(psResult);
  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GRUPO', 'psResult', psResult, 'OUT');
  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GRUPO', 'psTxResult', psTxResult, 'OUT');  
WHEN Ex_UsuarioNoExiste THEN
  psResult := 2;
  psTxResult := RUG.FN_MENSAJE_ERROR(psResult);
  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GRUPO', 'psResult', psResult, 'OUT');
  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GRUPO', 'psTxResult', psTxResult, 'OUT');
WHEN Ex_GpoAdministrador THEN
  psResult := 27;
  psTxResult := RUG.FN_MENSAJE_ERROR(psResult);
  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GRUPO', 'psResult', psResult, 'OUT');
  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GRUPO', 'psTxResult', psTxResult, 'OUT');  
WHEN OTHERS THEN
  psResult  := 999;   
  psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
  ROLLBACK;
  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GRUPO', 'psResult', psResult, 'OUT');
  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GRUPO', 'psTxResult', psTxResult, 'OUT');
END SP_MODIFICA_GRUPO;
/

