create PROCEDURE           SP_ALTA_CANCELACION_MASIVA 
(
    peIdPersona             IN  NUMBER,
    peIdGarantia            IN  NUMBER,
    peIdAcreedor            IN  NUMBER,
    peAnotacion_Juez        IN  VARCHAR2,
    peCveRastreo            IN  VARCHAR2,
    peIdArchivo             IN  NUMBER,
    peObservaciones         IN  VARCHAR,  --Informacion de la cancelacion
    psIdTramiteIncompleto  OUT  VARCHAR2,
    psResult               OUT  NUMBER,
    psTxResult             OUT  VARCHAR2
)
IS

vlIdGarantiaPend            NUMBER;
vlIdTramiteIncompleto       NUMBER;
vlAcreedor                  CHAR(2);
vlBandera                   CHAR(2);
vlIdTipoTramite             NUMBER;
vlPerJuridica               CHAR(2);
vlTipoGarantiaAnterior      NUMBER;

vlIdGarantiaPendAnterior    NUMBER;
vsIdUltimoTramite           NUMBER;
vsResult                    INTEGER;
vsTxResult                  VARCHAR(200);

Ex_ErrParametro             EXCEPTION;
Ex_Error                    EXCEPTION;


CURSOR cursPartes(cpeIdGarantia IN NUMBER) IS   
   SELECT RPP.ID_PERSONA, RPP.ID_PARTE, RGG.PER_JURIDICA
   FROM RUG_REL_GARANTIA_PARTES RPP
   INNER JOIN RUG_PERSONAS RGG
   ON RPP.ID_PERSONA = RGG.ID_PERSONA
   INNER JOIN RUG_GARANTIAS RGT
   ON RPP.ID_RELACION = RGT.ID_RELACION
   WHERE RPP.ID_GARANTIA = cpeIdGarantia
   AND RPP.ID_PARTE != 4;

cursPartes_Rec cursPartes%ROWTYPE;


BEGIN

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCELACION_MASIVA', 'INCIA', 'INICIA SP_ALTA_CANCELACION_MASIVA', 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCELACION_MASIVA', 'peIdPersona', peIdPersona, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCELACION_MASIVA', 'peIdGarantia', peIdGarantia, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCELACION_MASIVA', 'peIdAcreedor', peIdAcreedor, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCELACION_MASIVA', 'peAnotacion_Juez', peAnotacion_Juez, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCELACION_MASIVA', 'peCveRastreo', peCveRastreo, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCELACION_MASIVA', 'peIdArchivo', peIdArchivo, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCELACION_MASIVA', 'peObservaciones', peObservaciones, 'IN');


    BEGIN
        SELECT DECODE(ID_ACREEDOR, peIdAcreedor, 'V', 'F'), ID_TIPO_TRAMITE 
          INTO vlAcreedor, vlIdTipoTramite
          FROM (
                    SELECT ID_ACREEDOR, ID_TIPO_TRAMITE FROM V_TRAMITES_TERMINADOS
                     WHERE ID_GARANTIA = peIdGarantia
                     ORDER BY 1)
         WHERE ROWNUM < 2;

        EXCEPTION WHEN NO_DATA_FOUND THEN
            psResult := 14;
            RAISE Ex_Error;

    END;


    IF (vlIdTipoTramite = 4) THEN

        psResult := 59;
        RAISE Ex_Error;

    END IF;



    IF(vlAcreedor = 'V') THEN
        BEGIN


            SELECT PER_JURIDICA
              INTO vlPerJuridica
              FROM RUG_PERSONAS
             WHERE ID_PERSONA = peIdAcreedor;


            SELECT DECODE(CVE_PERFIL, 'AUTORIDAD', 'V', 'F')
              INTO vlBandera 
              FROM RUG_SECU_PERFILES_USUARIO
             WHERE ID_PERSONA = peIdPersona;

            SP_ALTA_TRAMITE_RASTREO(peIdPersona, 4, peIdAcreedor, vlPerJuridica, 0, NULL, SYSDATE, peCveRastreo, peIdArchivo, vlIdTramiteIncompleto, psResult, psTxResult);

            IF (psResult = 0) THEN

                -- SP_ALTA_CANCELACION(vlIdTramiteIncompleto, peIdGarantia, psResult, psTxResult);


                SELECT ID_TIPO_GARANTIA, ID_GARANTIA_PEND
                INTO vlTipoGarantiaAnterior,  vlIdGarantiaPendAnterior
                FROM RUG_GARANTIAS
                WHERE ID_GARANTIA = peIdGarantia;


                vlIdGarantiaPend := SEQ_GARANTIAS_TEMP.NEXTVAL; 

                INSERT INTO RUG_GARANTIAS_PENDIENTES(ID_GARANTIA_PEND, ID_TIPO_GARANTIA, GARANTIA_STATUS, ID_GARANTIA_MODIFICAR)
                VALUES(vlIdGarantiaPend, vlTipoGarantiaAnterior, 'CA', peIdGarantia);

                INSERT INTO RUG_REL_TRAM_INC_GARAN
                VALUES(vlIdGarantiaPend, vlIdTramiteIncompleto, 'AC', SYSDATE);

                SELECT MAX(ID_ULTIMO_TRAMITE)
                INTO vsIdUltimoTramite
                FROM RUG_GARANTIAS_H
                WHERE ID_GARANTIA = peIdGarantia;

                SP_ALTA_BIEN_INCOMPLETO(vlIdTramiteIncompleto,vsIdUltimoTramite,vsResult,vsTxResult);

                IF vsResult <> 0 THEN
                    psResult := 74;
                    RAISE Ex_ErrParametro;
                END IF;

                --INSERTO RELACION DE PARTES QUE TENIA LA GARANTIA A ESTE NUEVO TRAMITE 
                BEGIN
                FOR cursPartes_Rec IN cursPartes(peIdGarantia)
                    LOOP
                    INSERT INTO RUG_REL_TRAM_INC_PARTES
                    VALUES(vlIdTramiteIncompleto, cursPartes_Rec.ID_PERSONA, cursPartes_Rec.ID_PARTE, cursPartes_Rec.PER_JURIDICA, 'AC', SYSDATE);
                    END LOOP;
                END;


                -- INSERTO LOS CONTRATOS QUE TENIA ESTA GARANTIA PARA CONSISTENCIA EN DETALLE
                 INSERT INTO RUG_CONTRATO
                 SELECT SEQ_CONTRATO.NEXTVAL, vlIdGarantiaPend, CONTRATO_NUM, FECHA_INICIO, FECHA_FIN, OTROS_TERMINOS_CONTRATO, MONTO_LIMITE, peObservaciones, TIPO_CONTRATO, vlIdTramiteIncompleto, SYSDATE, 'AC', ID_USUARIO, CLASIF_CONTRATO
                 FROM RUG_CONTRATO
                 WHERE ID_GARANTIA_PEND = vlIdGarantiaPendAnterior;


                IF (psResult = 0) THEN


                    IF (vlBandera = 'V') THEN 

                        SP_ORDEN_AUTORIDAD(vlIdTramiteIncompleto, peAnotacion_Juez, psResult, psTxResult);

                    END IF;

                    IF (psResult = 0) THEN

                        SP_Alta_Bitacora_Tramite2(vlIdTramiteIncompleto, 5, 0, NULL, 'V', psResult, psTxResult);

                        IF (psResult = 0) THEN

                            psIdTramiteIncompleto := vlIdTramiteIncompleto;
                        END IF;

                    END IF;

                END IF;               

            END IF;

        END;

    ELSE 

        psResult := 60;        
        RAISE Ex_Error;

    END IF;



    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCELACION_MASIVA', 'TERMINA', psIdTramiteIncompleto, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCELACION_MASIVA', 'TERMINA', 'TERMINA SP_ALTA_CANCELACION_MASIVA', 'IN');


EXCEPTION


WHEN Ex_Error  THEN

      psTxResult := RUG.FN_MENSAJE_ERROR(psResult);

      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCELACION_MASIVA', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCELACION_MASIVA', 'psTxResult', psTxResult, 'OUT');
      ROLLBACK;

WHEN OTHERS THEN
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      ROLLBACK;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCELACION_MASIVA', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCELACION_MASIVA', 'psTxResult', psTxResult, 'OUT');

END;
/

