create PROCEDURE             EJECUTAPL 
AS
vlResult    NUMBER;
vlTxResult  VARCHAR2(500);
-- PROCEDURE DEPRECATED
vIdControlUnico number;
BEGIN
--vIdControlUnico :=8599;


Dbms_output.put_line(vIdControlUnico || ' - ' || vlResult || ' - ' || vlTxResult);


END;
/

