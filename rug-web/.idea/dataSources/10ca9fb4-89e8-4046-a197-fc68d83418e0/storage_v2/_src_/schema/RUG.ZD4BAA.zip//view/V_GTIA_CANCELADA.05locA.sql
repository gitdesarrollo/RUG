create view V_GTIA_CANCELADA as
SELECT   TRUNC (RBT.FECHA_STATUS) AS FECHA_CANCEL, T.ID_TRAMITE
     FROM   RUG.RUG_BITAC_TRAMITES RBT,
            RUG.TRAMITES T,
            RUG.RUG_REL_TRAM_PARTES RRT
    WHERE       RBT.ID_TRAMITE_TEMP = T.ID_TRAMITE_TEMP
            AND T.ID_TIPO_TRAMITE = 4
            AND RBT.ID_STATUS = 3
            AND RRT.ID_TRAMITE(+) = T.ID_TRAMITE
            AND RRT.ID_PARTE(+) = 4
            AND RBT.STATUS_REG = 'AC'
/

comment on table V_GTIA_CANCELADA is 'Vista utilizada por la aplicacion de reportes y muestra los tramites cancelados'
/

