create FUNCTION         FNOBTMSGERR (peIdCodigo     RUG_CAT_MENSAJES_ERRORES.Id_Codigo%TYPE                           
                          )
RETURN RUG_CAT_MENSAJES_ERRORES.Desc_Codigo%TYPE IS

vlDescError           RUG_CAT_MENSAJES_ERRORES.Desc_Codigo%TYPE;

BEGIN

   vlDescError       := NULL;

   BEGIN
      --select INITCAP(desc_codigo) into vlDescError
      SELECT desc_codigo
      INTO vlDescError
      FROM RUG_CAT_MENSAJES_ERRORES
      WHERE id_codigo = peIdCodigo;
      EXCEPTION WHEN NO_DATA_FOUND THEN
            vlDescError := 'No se encontro el mensaje seleccionado';
            SP_LOG('FunObtMsgErr',peIdCodigo||' - '||SUBSTR(SQLCODE||'-'||SQLERRM,1,1000));
   END;

   RETURN vlDescError;

EXCEPTION
   WHEN OTHERS THEN
      RETURN NULL;
      SP_LOG('FunObtMsgErr',SUBSTR(SQLCODE||'-'||SQLERRM,1,1000));

END;
/

