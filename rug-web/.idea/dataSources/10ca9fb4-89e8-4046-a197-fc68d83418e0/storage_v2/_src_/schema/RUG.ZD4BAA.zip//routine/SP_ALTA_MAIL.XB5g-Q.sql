create PROCEDURE     SP_ALTA_MAIL (
                                                peIdTipoCorreo          IN  NUMBER,
                                                peIdMailAccount         IN  NUMBER,
                                                peDestinatario          IN  VARCHAR2,
                                                peDestinatarioCC        IN  VARCHAR2,
                                                peDestinatarioCCO       IN  VARCHAR2,
                                                peAsunto                IN  VARCHAR2,
                                                peMensaje               IN  CLOB,
                                                psIdMail               OUT  NUMBER,                                                
                                                psResult               OUT  NUMBER,
                                                psTxResult             OUT  VARCHAR2
                                          )
IS

vlTipoCorreo        NUMBER;
vlMailAcc           NUMBER;
vlIdMail            NUMBER;
Ex_ErrParametro     EXCEPTION;


BEGIN

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_MAIL', 'peIdTipoCorreo', peIdTipoCorreo, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_MAIL', 'peIdMailAccount', peIdMailAccount, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_MAIL', 'peDestinatario', peDestinatario, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_MAIL', 'peDestinatarioCC', peDestinatarioCC, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_MAIL', 'peDestinatarioCCO', peDestinatarioCCO, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_MAIL', 'peAsunto', peAsunto, 'IN');


    IF(peDestinatario IS NULL AND peDestinatarioCC IS NULL AND peDestinatarioCCO IS NULL) THEN   

        psResult := -1;
        psTxResult:= 'Debe indicar al menos un destinatario.';
        RAISE Ex_ErrParametro;

    END IF;

    BEGIN

        SELECT  COUNT(*) 
          INTO  vlTipoCorreo
          FROM  RUG_CAT_TIPO_CORREO
         WHERE  ID_TIPO_CORREO = peIdTipoCorreo;

       EXCEPTION 
         WHEN NO_DATA_FOUND THEN
            psResult := -1;
            psTxResult:= 'El tipo de correo no existe en el sistema, favor de validar.';
            RAISE Ex_ErrParametro;
    END;


   BEGIN

           SELECT COUNT(*) 
             INTO vlMailAcc
             FROM RUG_MAIL_ACCOUNTS
            WHERE ID_MAIL_ACCOUNT = peIdMailAccount;
       EXCEPTION 
         WHEN NO_DATA_FOUND THEN
            psResult := -1;
            psTxResult:= 'Debe indicar la cuenta de correo del administrador.';
            RAISE Ex_ErrParametro;
   END;

    vlIdMail := SEQ_RUG_MAIL_POOL.NEXTVAL;

    INSERT INTO RUG_MAIL_POOL(ID_MAIL, ID_TIPO_CORREO, ID_MAIL_ACCOUNT, DESTINATARIO, DESTINATARIO_CC, DESTINATARIO_CCO,
                              ASUNTO, MENSAJE, ID_STATUS_MAIL)
    VALUES(vlIdMail, peIdTipoCorreo, peIdMailAccount, peDestinatario, peDestinatarioCC, peDestinatarioCCO,
           peAsunto, peMensaje, 1);

    psIdMail := vlIdMail;
    psResult  := 0;   
    psTxResult:= 'ALTA EXITOSA';


    COMMIT;


    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_MAIL', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_MAIL', 'psTxResult', psTxResult, 'OUT');

EXCEPTION

   WHEN Ex_ErrParametro  THEN      
      ROLLBACK;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_MAIL', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_MAIL', 'psTxResult', psTxResult, 'OUT');


  WHEN OTHERS THEN
     psResult  := 999;   
     psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
     ROLLBACK;
     REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_MAIL', 'psResult', psResult, 'OUT');
     REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_MAIL', 'psTxResult', psTxResult, 'OUT');


END;
/

