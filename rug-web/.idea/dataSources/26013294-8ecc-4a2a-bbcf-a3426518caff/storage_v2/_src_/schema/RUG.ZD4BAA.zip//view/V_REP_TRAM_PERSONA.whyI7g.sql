create view V_REP_TRAM_PERSONA as
SELECT   ID_PERSONA,
              --   ID_ACREEDOR,
              FECHA,
              SUM (DECODE (TIPO, 1, 1, 0)) TOTAL_TRAMITES,
              SUM (DECODE (TIPO, 2, 1, 0)) GARANTIAS_INSCRITAS,
              SUM (DECODE (TIPO, 3, 1, 0)) AVISOS_PREVENTIVOS,
              SUM (DECODE (TIPO, 4, 1, 0)) MODIFICACIONES,
              SUM (DECODE (TIPO, 5, 1, 0)) TRANSMISIONES,
              SUM (DECODE (TIPO, 6, 1, 0)) RECTIFICACION_POR_ERROR,
              SUM (DECODE (TIPO, 7, 1, 0)) RENOVACIONES,
              SUM (DECODE (TIPO, 8, 1, 0)) CANCELACIONES,
              SUM (DECODE (TIPO, 9, 1, 0)) ANOTACIONES,
              SUM (DECODE (TIPO, 10, 1, 0)) ALTA_ACREEDOR,
              SUM (DECODE (TIPO, 11, 1, 0)) CERTIFICACIONES
       FROM   (SELECT   1 TIPO, t.id_persona, TRUNC (RBT.FECHA_STATUS) FECHA -- SOLICITUDES
                 FROM   RUG.RUG_BITAC_TRAMITES RBT,
                        RUG.TRAMITES T,
                        RUG.RUG_REL_TRAM_PARTES RRT
                WHERE   T.ID_TIPO_TRAMITE IN
                              (1, 3, 7, 8, 6, 9, 4, 2, 10, 12, 5)
                        AND RBT.ID_TRAMITE_TEMP = T.ID_TRAMITE_TEMP
                        AND RBT.ID_STATUS = 3
                        AND RRT.ID_TRAMITE(+) = T.ID_TRAMITE
                        AND RRT.ID_PARTE(+) = 4
                        AND RBT.STATUS_REG = 'AC'
               UNION ALL
               SELECT   2 TIPO, t.id_persona, TRUNC (RBT.FECHA_STATUS) FECHA -- SOLICITUDES
                 FROM   RUG.RUG_BITAC_TRAMITES RBT,
                        RUG.TRAMITES T,
                        RUG.RUG_REL_TRAM_PARTES RRT
                WHERE       RBT.ID_TRAMITE_TEMP = T.ID_TRAMITE_TEMP
                        AND T.ID_TIPO_TRAMITE = 1
                        AND RBT.ID_STATUS = 3
                        AND RRT.ID_TRAMITE(+) = T.ID_TRAMITE
                        AND RRT.ID_PARTE(+) = 4
                        AND RBT.STATUS_REG = 'AC'
               UNION ALL
               SELECT   3 TIPO, t.id_persona, TRUNC (RBT.FECHA_STATUS) FECHA -- avisos
                 FROM   RUG.RUG_BITAC_TRAMITES RBT,
                        RUG.TRAMITES T,
                        RUG.RUG_REL_TRAM_PARTES RRT
                WHERE       RBT.ID_TRAMITE_TEMP = T.ID_TRAMITE_TEMP
                        AND T.ID_TIPO_TRAMITE = 3
                        AND RBT.ID_STATUS = 3
                        AND RRT.ID_TRAMITE(+) = T.ID_TRAMITE
                        AND RRT.ID_PARTE(+) = 4
                        AND RBT.STATUS_REG = 'AC'
               UNION ALL
               SELECT   4 TIPO, t.id_persona, TRUNC (RBT.FECHA_STATUS) FECHA -- avisos
                 FROM   RUG.RUG_BITAC_TRAMITES RBT,
                        RUG.TRAMITES T,
                        RUG.RUG_REL_TRAM_PARTES RRT
                WHERE       RBT.ID_TRAMITE_TEMP = T.ID_TRAMITE_TEMP
                        AND T.ID_TIPO_TRAMITE = 7
                        AND RBT.ID_STATUS = 3
                        AND RRT.ID_TRAMITE(+) = T.ID_TRAMITE
                        AND RRT.ID_PARTE(+) = 4
                        AND RBT.STATUS_REG = 'AC'
               UNION ALL
               SELECT   5 TIPO, t.id_persona, TRUNC (RBT.FECHA_STATUS) FECHA -- transmisiones
                 FROM   RUG.RUG_BITAC_TRAMITES RBT,
                        RUG.TRAMITES T,
                        RUG.RUG_REL_TRAM_PARTES RRT
                WHERE       RBT.ID_TRAMITE_TEMP = T.ID_TRAMITE_TEMP
                        AND T.ID_TIPO_TRAMITE = 8
                        AND RBT.ID_STATUS = 3
                        AND RRT.ID_TRAMITE(+) = T.ID_TRAMITE
                        AND RRT.ID_PARTE(+) = 4
                        AND RBT.STATUS_REG = 'AC'
               UNION ALL
               SELECT   6 TIPO, t.id_persona, TRUNC (RBT.FECHA_STATUS) FECHA -- rect x error
                 FROM   RUG.RUG_BITAC_TRAMITES RBT,
                        RUG.TRAMITES T,
                        RUG.RUG_REL_TRAM_PARTES RRT
                WHERE       RBT.ID_TRAMITE_TEMP = T.ID_TRAMITE_TEMP
                        AND T.ID_TIPO_TRAMITE = 6
                        AND RBT.ID_STATUS = 3
                        AND RRT.ID_TRAMITE(+) = T.ID_TRAMITE
                        AND RRT.ID_PARTE(+) = 4
                        AND RBT.STATUS_REG = 'AC'
               UNION ALL
               SELECT   7 TIPO, t.id_persona, TRUNC (RBT.FECHA_STATUS) FECHA -- renovaciones
                 FROM   RUG.RUG_BITAC_TRAMITES RBT,
                        RUG.TRAMITES T,
                        RUG.RUG_REL_TRAM_PARTES RRT
                WHERE       RBT.ID_TRAMITE_TEMP = T.ID_TRAMITE_TEMP
                        AND T.ID_TIPO_TRAMITE = 9
                        AND RBT.ID_STATUS = 3
                        AND RRT.ID_TRAMITE(+) = T.ID_TRAMITE
                        AND RRT.ID_PARTE(+) = 4
                        AND RBT.STATUS_REG = 'AC'
               UNION ALL
               SELECT   8 TIPO, t.id_persona, TRUNC (RBT.FECHA_STATUS) FECHA -- cancelaciones
                 FROM   RUG.RUG_BITAC_TRAMITES RBT,
                        RUG.TRAMITES T,
                        RUG.RUG_REL_TRAM_PARTES RRT
                WHERE       RBT.ID_TRAMITE_TEMP = T.ID_TRAMITE_TEMP
                        AND T.ID_TIPO_TRAMITE = 4
                        AND RBT.ID_STATUS = 3
                        AND RRT.ID_TRAMITE(+) = T.ID_TRAMITE
                        AND RRT.ID_PARTE(+) = 4
                        AND RBT.STATUS_REG = 'AC'
               UNION ALL
               SELECT   9 TIPO, t.id_persona, TRUNC (RBT.FECHA_STATUS) FECHA -- anotaciones
                 FROM   RUG.RUG_BITAC_TRAMITES RBT,
                        RUG.TRAMITES T,
                        RUG.RUG_REL_TRAM_PARTES RRT
                WHERE       RBT.ID_TRAMITE_TEMP = T.ID_TRAMITE_TEMP
                        AND T.ID_TIPO_TRAMITE IN (2, 10)
                        AND RBT.ID_STATUS = 3
                        AND RRT.ID_TRAMITE(+) = T.ID_TRAMITE
                        AND RRT.ID_PARTE(+) = 4
                        AND RBT.STATUS_REG = 'AC'
               UNION ALL
               SELECT   10 TIPO, t.id_persona, TRUNC (RBT.FECHA_STATUS) FECHA -- alta acreedor
                 FROM   RUG.RUG_BITAC_TRAMITES RBT,
                        RUG.TRAMITES T,
                        RUG.RUG_REL_TRAM_PARTES RRT
                WHERE       RBT.ID_TRAMITE_TEMP = T.ID_TRAMITE_TEMP
                        AND T.ID_TIPO_TRAMITE = 12
                        AND RBT.ID_STATUS = 3
                        AND RRT.ID_TRAMITE(+) = T.ID_TRAMITE
                        AND RRT.ID_PARTE(+) = 4
                        AND RBT.STATUS_REG = 'AC'
               UNION ALL
               SELECT   11 TIPO, t.id_persona, TRUNC (RBT.FECHA_STATUS) FECHA -- certificaciones
                 FROM   RUG.RUG_BITAC_TRAMITES RBT,
                        RUG.TRAMITES T,
                        RUG.RUG_REL_TRAM_PARTES RRT
                WHERE       RBT.ID_TRAMITE_TEMP = T.ID_TRAMITE_TEMP
                        AND T.ID_TIPO_TRAMITE = 5
                        AND RBT.ID_STATUS = 3
                        AND RRT.ID_TRAMITE(+) = T.ID_TRAMITE
                        AND RRT.ID_PARTE(+) = 4
                        AND RBT.STATUS_REG = 'AC')
   GROUP BY   ID_PERSONA, FECHA
/

comment on table V_REP_TRAM_PERSONA is 'Vista Utilizada por la aplicacion de reportes que obtiene por fecha y usuario el total de tramites realizados'
/

