create view V_DETALLE_TRAMITE_MASIVO as
SELECT   RFM.ID_FIRMA_MASIVA,
            RFM.ID_TRAMITE_TEMP,
            RTR.CVE_RASTREO,
            T.ID_TRAMITE,
            RG.ID_GARANTIA,
            RBT.FECHA_STATUS,
            T.ID_TIPO_TRAMITE,
            RG.VIGENCIA,
               RPF.NOMBRE_PERSONA
            || ' '
            || RPF.AP_PATERNO
            || ' '
            || RPF.AP_MATERNO
               NOMBRE_USUARIO
     FROM   RUG_FIRMA_MASIVA RFM,
            RUG_TRAMITE_RASTREO RTR,
            TRAMITES T,
            RUG_GARANTIAS_H RG,
            RUG_BITAC_TRAMITES RBT,
            RUG_PERSONAS_FISICAS RPF
    WHERE       RTR.ID_TRAMITE_TEMP = RFM.ID_TRAMITE_TEMP
            AND T.ID_TRAMITE_TEMP = RFM.ID_TRAMITE_TEMP
            AND RG.ID_ULTIMO_TRAMITE = T.ID_TRAMITE
            AND RBT.ID_TRAMITE_TEMP = RFM.ID_TRAMITE_TEMP
            AND RPF.ID_PERSONA = T.ID_PERSONA
            AND RBT.ID_STATUS = 3
            AND T.ID_TIPO_TRAMITE != 2
            AND RBT.STATUS_REG = 'AC'
   UNION ALL
   SELECT   RFM.ID_FIRMA_MASIVA,
            RFM.ID_TRAMITE_TEMP,
            RTR.CVE_RASTREO,
            T.ID_TRAMITE,
            0 ID_GARANTIA,
            RBT.FECHA_STATUS,
            T.ID_TIPO_TRAMITE,
            15 VIGENCIA,
               RPF.NOMBRE_PERSONA
            || ' '
            || RPF.AP_PATERNO
            || ' '
            || RPF.AP_MATERNO
               NOMBRE_USUARIO
     FROM   TRAMITES T,
            RUG_TRAMITE_RASTREO RTR,
            RUG_FIRMA_MASIVA RFM,
            RUG_BITAC_TRAMITES RBT,
            RUG_PERSONAS_FISICAS RPF,
            AVISOS_PREV AP
    WHERE       RFM.ID_TRAMITE_TEMP = RTR.ID_TRAMITE_TEMP
            AND RFM.ID_TRAMITE_TEMP = T.ID_TRAMITE_TEMP
            AND RBT.ID_TRAMITE_TEMP = RFM.ID_TRAMITE_TEMP
            AND RPF.ID_PERSONA = T.ID_PERSONA
            AND AP.ID_TRAMITE_TEMP = RFM.ID_TRAMITE_TEMP
            AND RBT.ID_STATUS = 3
            AND RBT.STATUS_REG = 'AC'
   UNION ALL
   SELECT   RFM.ID_FIRMA_MASIVA,
            RFM.ID_TRAMITE_TEMP,
            RTR.CVE_RASTREO,
            T.ID_TRAMITE,
            0 ID_GARANTIA,
            RBT.FECHA_STATUS,
            T.ID_TIPO_TRAMITE,
            ASG.VIGENCIA_ANOTACION VIGENCIA,
               RPF.NOMBRE_PERSONA
            || ' '
            || RPF.AP_PATERNO
            || ' '
            || RPF.AP_MATERNO
               NOMBRE_USUARIO
     FROM   TRAMITES T,
            RUG_TRAMITE_RASTREO RTR,
            RUG_FIRMA_MASIVA RFM,
            RUG_BITAC_TRAMITES RBT,
            RUG_PERSONAS_FISICAS RPF,
            RUG_ANOTACIONES_SIN_GARANTIA ASG
    WHERE       RFM.ID_TRAMITE_TEMP = RTR.ID_TRAMITE_TEMP
            AND RFM.ID_TRAMITE_TEMP = T.ID_TRAMITE_TEMP
            AND RBT.ID_TRAMITE_TEMP = RFM.ID_TRAMITE_TEMP
            AND RPF.ID_PERSONA = T.ID_PERSONA
            AND ASG.ID_TRAMITE_TEMP = RFM.ID_TRAMITE_TEMP
            AND RBT.ID_STATUS = 3
            AND RBT.STATUS_REG = 'AC'
   UNION ALL
   SELECT   RFM.ID_FIRMA_MASIVA,
            RFM.ID_TRAMITE_TEMP,
            RTR.CVE_RASTREO,
            T.ID_TRAMITE,
            RG.ID_GARANTIA,
            RBT.FECHA_STATUS,
            T.ID_TIPO_TRAMITE,
            RA.VIGENCIA_ANOTACION VIGENCIA,
               RPF.NOMBRE_PERSONA
            || ' '
            || RPF.AP_PATERNO
            || ' '
            || RPF.AP_MATERNO
               NOMBRE_USUARIO
     FROM   RUG_FIRMA_MASIVA RFM,
            RUG_TRAMITE_RASTREO RTR,
            TRAMITES T,
            RUG_GARANTIAS RG,
            RUG_BITAC_TRAMITES RBT,
            RUG_PERSONAS_FISICAS RPF,
            RUG_ANOTACIONES RA
    WHERE       RTR.ID_TRAMITE_TEMP = RFM.ID_TRAMITE_TEMP
            AND T.ID_TRAMITE_TEMP = RFM.ID_TRAMITE_TEMP
            AND RA.ID_TRAMITE_TEMP = T.ID_TRAMITE_TEMP
            AND RG.ID_ULTIMO_TRAMITE = T.ID_TRAMITE
            AND RBT.ID_TRAMITE_TEMP = RFM.ID_TRAMITE_TEMP
            AND RPF.ID_PERSONA = T.ID_PERSONA
            AND RBT.ID_STATUS = 3
            AND RBT.STATUS_REG = 'AC'
/

