create PROCEDURE         SP_PERS_DUP (psResult     OUT INTEGER,
                                             psTxResult   OUT VARCHAR2)
IS
   vlIdPersona     NUMBER;
   vlIdDomicilio   NUMBER;
BEGIN
   --------------------------------------------------------------------------------


   vlIdPersona := SEQ_RUG_ID_PERSONA.NEXTVAL;
   vlIdDomicilio := SEQ_RUG_ID_DOMICILIO.NEXTVAL;

   /*INSERT INTO RUG.RUG_PERSONAS
      SELECT   vlIdPersona,
               RFC,
               ID_NACIONALIDAD,
               PER_JURIDICA,
               FH_REGISTRO,
               PROCEDENCIA,
               SIT_PERSONA,
               CVE_NACIONALIDAD,
               vlIdDomicilio,
               NULL,
               NULL,
               'Y',
               NULL,
               NULL,
               NULL
        FROM   INSTITUCIONAL.SE_PERSONAS
       WHERE   ID_PERSONA = 54418;



   INSERT INTO RUG.RUG_PERSONAS_FISICAS
      SELECT   vlIdPersona,
               NOMBRE_PERSONA,
               AP_PATERNO,
               AP_MATERNO,
               CURP,
               ID_CALIDAD_MIGRAT,
               ID_PAIS_NACIM,
               F_NACIMIENTO,
               ESTADO_CIVIL,
               OCUPACION_ACTUAL,
               SEXO,
               CVE_PAIS_NACIM,
               CVE_ESTADO_NACIM,
               CVE_MUN_DEL_NACIM,
               LUGAR_NAC_PERS_EXT,
               FOLIO_DOCTO_MIGRAT,
               CVE_ESCOLARIDAD
        FROM   INSTITUCIONAL.SE_PERSONAS_FISICAS
       WHERE   ID_PERSONA = 54418;*/



   INSERT INTO RUG.RUG_DOMICILIOS
      SELECT   vlIdDomicilio,
               CALLE,
               NUM_EXTERIOR,
               NUM_INTERIOR,
               ID_COLONIA,
               CALLE_COLINDANTE_1,
               CALLE_COLINDANTE_2,
               CALLE_POSTERIOR,
               LOCALIDAD,
               ID_VIALIDAD,
               TX_REFER_ADICIONAL,
               NULL,
               ID_LOCALIDAD
        FROM   INSTITUCIONAL.SE_DOMICILIOS_NAL
       WHERE   ID_DOMICILIO = 25056;



   UPDATE   RUG.RUG_SECU_USUARIOS
      SET   ID_PERSONA = vlIdPersona
    WHERE   CVE_USUARIO = 'mariafernanda@notaria24qro.net';

   INSERT INTO RUG.RUG_SECU_PERFILES_USUARIO
     VALUES   ('SE',
               'mariafernanda@notaria24qro.net',
               'AUTORIDAD',
               'RugPortal',
               vlIdPersona,
               'F');

   COMMIT;

   psResult := 0;
   psTxResult := 'Inserci?inalizada satisfactoriamente';

   RUG.REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL,
                      'SP_PERS_DUP',
                      'psResult',
                      psResult,
                      'OUT');
   RUG.REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL,
                      'SP_PERS_DUP',
                      'psTxResult',
                      psTxResult,
                      'OUT');
EXCEPTION
   WHEN OTHERS
   THEN
      psResult := 999;
      psTxResult := SUBSTR (SQLCODE || ':' || SQLERRM, 1, 250);
      ROLLBACK;
      RUG.REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL,
                         'SP_PERS_DUP',
                         'psResult',
                         psResult,
                         'OUT');
      RUG.REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL,
                         'SP_PERS_DUP',
                         'psTxResult',
                         psTxResult,
                         'OUT');
END SP_PERS_DUP;
/

