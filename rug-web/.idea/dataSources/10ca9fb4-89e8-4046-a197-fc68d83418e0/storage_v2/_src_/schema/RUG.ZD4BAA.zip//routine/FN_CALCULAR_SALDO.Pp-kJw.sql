create FUNCTION     FN_CALCULAR_SALDO(pUserId IN VARCHAR2) RETURN NUMBER IS
l_saldo       NUMBER;
	v_usuario_maestro NUMBER;
	v_usuarios_cuentas VARCHAR(1000);
	v_tramites_vinculados VARCHAR(1000);
	vlDescMensajeError  VARCHAR(4000);
	v_sql varchar2(3000);
	CURSOR c_cuentas(userId VARCHAR2) IS
      SELECT id_persona  
        FROM rug_secu_usuarios  
        WHERE id_persona = userId
        UNION  
        SELECT id_persona  
        FROM rug_secu_usuarios  
        WHERE cve_usuario_padre = (  
            SELECT cve_usuario_padre  
            FROM rug_secu_usuarios  
            WHERE id_persona = userId
        )  
        UNION  
        SELECT id_persona  
        FROM rug_secu_usuarios  
        WHERE cve_usuario = (  
            SELECT cve_usuario_padre  
            FROM rug_secu_usuarios  
            WHERE id_persona = userId
        )  
        UNION  
        SELECT id_persona  
        FROM rug_secu_usuarios  
        WHERE cve_usuario_padre = (  
            SELECT cve_usuario  
            FROM rug_secu_usuarios  
            WHERE id_persona = userId
        );
    
    v_c_tramites_vinculados VARCHAR(1000) := '
		SELECT htf.id_tramite
		FROM homologado_tramite htf
		WHERE EXISTS (
			SELECT * FROM (
				SELECT htr.id_tramite, min(htr.HOMOLOGADO_ID) AS homologado_id
				FROM rug.homologado_tramite htr
				WHERE EXISTS (
					SELECT 1
					FROM HOMOLOGADO_TRAMITE ht
					WHERE ht.id_persona IN (#usuarios#)
					AND ht.id_tramite = htr.id_tramite
				)
				GROUP BY htr.id_tramite	
			) sub
			WHERE sub.id_tramite = htf.id_tramite
			AND sub.homologado_id = htf.homologado_id
		)
		AND htf.ID_PERSONA IN (#usuarios#)';
		
	c_tramites_vinculados SYS_REFCURSOR;
	TYPE MYREC IS RECORD (
		ID_TRAMITE VARCHAR(1000)
	);
	r_tramites MYREC;
BEGIN
	REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'FN_CALCULAR_SALDO', 'pUserId', pUserId, 'IN');
    -- obtener cuenta maestra
    SELECT id_persona 
    INTO v_usuario_maestro
    FROM rug_secu_usuarios 
    WHERE cve_usuario = (
        SELECT NVL(cve_usuario_padre, cve_usuario) AS cve_usuario_padre 
        FROM rug_secu_usuarios 
        WHERE id_persona = pUserId
    );
    -- obtener todas las cuentas
    v_usuarios_cuentas := '';
    FOR r_cuentas IN c_cuentas(pUserId)
    LOOP
        v_usuarios_cuentas := v_usuarios_cuentas || r_cuentas.id_persona || ',';
    END LOOP;
   	v_usuarios_cuentas := SUBSTR(v_usuarios_cuentas, 1, LENGTH(v_usuarios_cuentas) - 1);
   
   	-- obtener tramites vinculados
	v_tramites_vinculados := '';
    /*FOR r_tramites IN c_tramites_vinculados(pUserId)
    LOOP
        v_tramites_vinculados := v_tramites_vinculados || r_tramites.id_tramite || ',';
    END LOOP;*/
	v_c_tramites_vinculados := REPLACE(v_c_tramites_vinculados, '#usuarios#', v_usuarios_cuentas);
	OPEN c_tramites_vinculados FOR v_c_tramites_vinculados;
	LOOP
		FETCH c_tramites_vinculados INTO r_tramites;
		EXIT WHEN c_tramites_vinculados%NOTFOUND;
        v_tramites_vinculados := v_tramites_vinculados || r_tramites.id_tramite || ',';
    END LOOP;
   	v_tramites_vinculados := SUBSTR(v_tramites_vinculados, 1, LENGTH(v_tramites_vinculados) - 1);
    v_sql := 'SELECT NVL(SUM(CREDITOS) - SUM(DEBITOS),0) AS SALDO
    FROM (
    	SELECT SUM(PRECIO) DEBITOS, 0 as CREDITOS 
		FROM RUG.V_TRAMITES_PAGADOS TRA
        WHERE TRA.ID_PERSONA_LOGIN IN (
			'||v_usuarios_cuentas||'
		)
		AND NOT EXISTS (
			SELECT 1
			FROM homologado_tramite ht
			WHERE ht.id_tramite = tra.id_tramite
		)';
	IF LENGTH(v_tramites_vinculados) > 0 THEN
		v_sql := v_sql ||
		' UNION 
		SELECT SUM(PRECIO) DEBITOS, 0 as CREDITOS  
		FROM V_TRAMITES_PAGADOS TP 
		WHERE TP.ID_TRAMITE IN ( 
			'||v_tramites_vinculados||'
		)
		AND TP.ID_PERSONA_LOGIN NOT IN (
			'||v_usuarios_cuentas||'
		)';
	END IF;
		v_sql := v_sql ||
        ' UNION
        SELECT 0 as DEBITOS, SUM(MONTO) CREDITOS 
        FROM RUG_UTIL.BOLETA
        WHERE IDENTIFICADOR = '||v_usuario_maestro||' AND USADA = 1
        GROUP BY IDENTIFICADOR
    ) M';
   	dbms_output.put_line(v_sql);
	execute immediate v_sql into l_saldo;
	RETURN l_saldo;
EXCEPTION 
    WHEN OTHERS THEN
    	vlDescMensajeError := SUBSTR(SQLCODE||'-'||SQLERRM,1,1000);  
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'FN_CALCULAR_SALDO', 'error', vlDescMensajeError, 'OUT');
		dbms_output.put_line(vlDescMensajeError);
        RETURN NULL;
END;
/

