create FUNCTION         FN_BORRA_SIN_CON_GARANTIA (  
        P_DESCRIPCION   IN RUG.RUG_CAT_TIPO_TRAMITE.DESCRIPCION%TYPE
)
RETURN VARCHAR2
AS
    V_DESCRIPCION RUG.RUG_CAT_TIPO_TRAMITE.DESCRIPCION%TYPE;
BEGIN

 --   RUG.RUG_CAT_TIPO_TRAMITE

    V_DESCRIPCION := REPLACE( 
                        REPLACE(
                            REPLACE(
                              REPLACE(
                                 REPLACE(
                                    REPLACE(P_DESCRIPCION, 'CON GARANTÍA', '')
                                    , 'SIN GARANTÍA', '')
                                 , 'con garantía', '')
                              , 'sin garantía', '')
                            , 'con Garantía', '')
                         , 'sin Garantía', '');

    RETURN V_DESCRIPCION;                         


END;
/

