create PROCEDURE         SP_ELIMINA_GARANTIAS 
                            (                               
                                psResult            OUT  INTEGER,   
                                psTxResult          OUT  VARCHAR2                             
                            )
IS

/*
-------------------------------------------------------------------------------
OBJETIVO: ESTE PROCEDIMIENTO ELIMINA TODAS LAS GARANTIAS QUE SE HAYAN DADO 
          DE ALTA VIA CARGA MASIVA
AUTOR: ERNESTO DIAZ SANCHEZ DE TAGLE
FECHA:09/05/2011 12:12:00 PM
-------------------------------------------------------------------------------
*/

vlIdTramiteTemp         NUMBER;
vlIdTramiteComp         NUMBER;
vlIdGarantiaPend        NUMBER;
vlIdGarantiaComp        NUMBER;
vlIdArchivo             NUMBER;
vlCountGarEliminadas    NUMBER;
vlCountAutoridad        NUMBER;
vlCountTramitesComp     NUMBER;

   CURSOR CursTramitesFirma IS
   SELECT   RFM.ID_TRAMITE_TEMP,
         TRI.ID_TRAMITE,
         RRT.ID_GARANTIA_PEND,
         RGG.ID_GARANTIA, 
         RFM.ID_ARCHIVO
  FROM            RUG_FIRMA_MASIVA RFM
               LEFT JOIN
                  TRAMITES TRI
               ON RFM.ID_TRAMITE_TEMP = TRI.ID_TRAMITE_TEMP
            LEFT JOIN
               RUG_REL_TRAM_INC_GARAN RRT
            ON RFM.ID_TRAMITE_TEMP = RRT.ID_TRAMITE_TEMP
         LEFT JOIN
            RUG_GARANTIAS RGG
         ON RRT.ID_GARANTIA_PEND = RGG.ID_GARANTIA_PEND        
UNION
 SELECT   RFM.ID_TRAMITE_TEMP,
         TRI.ID_TRAMITE,
         RRT.ID_GARANTIA_PEND,
         RGG.ID_GARANTIA, 
         RFM.ID_ARCHIVO
  FROM            RUG_TRAMITE_RASTREO RFM
               LEFT JOIN
                  TRAMITES TRI
               ON RFM.ID_TRAMITE_TEMP = TRI.ID_TRAMITE_TEMP
            LEFT JOIN
               RUG_REL_TRAM_INC_GARAN RRT
            ON RFM.ID_TRAMITE_TEMP = RRT.ID_TRAMITE_TEMP
         LEFT JOIN
            RUG_GARANTIAS RGG
         ON RRT.ID_GARANTIA_PEND = RGG.ID_GARANTIA_PEND;           


  CURSOR CursArchivosCarga IS
  SELECT ID_ARCHIVO 
  FROM RUG_FIRMA_MASIVA
  GROUP BY ID_ARCHIVO;


BEGIN

vlCountGarEliminadas := 0;

  OPEN CursTramitesFirma;
        LOOP
            FETCH CursTramitesFirma INTO  vlIdTramiteTemp, vlIdTramiteComp, vlIdGarantiaPend, vlIdGarantiaComp, vlIdArchivo;
            EXIT WHEN CursTramitesFirma%NOTFOUND;

            --FLUJO EN COMUN PARA TRAMITES TEMPORALES DADOS DE ALTA VIA C.M.
            DELETE RUG_BITAC_TRAMITES
            WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;

            DELETE RUG_TRAMITE_RASTREO
            WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;

            DELETE RUG_TRAMITES_REASIGNADOS
            WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;

            DELETE FROM RUG_REL_MODIFICA_ACREEDOR
            WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;

            DELETE RUG_CONTRATO
            WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;

            DELETE RUG_REL_TRAM_INC_GARAN
            WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;

            DELETE RUG_REL_GAR_TIPO_BIEN
            WHERE ID_GARANTIA_PEND = vlIdGarantiaPend;

            DELETE RUG_GARANTIAS_PENDIENTES
            WHERE ID_GARANTIA_PEND = vlIdGarantiaPend;

            --LIMPIO VARIABLE
            vlCountAutoridad := 0;

            SELECT COUNT(*)
            INTO vlCountAutoridad
            FROM RUG_AUTORIDAD
            WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;

            IF vlCountAutoridad > 0 THEN
                DELETE RUG_AUTORIDAD 
                WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;
            END IF;

            DELETE RUG_REL_TRAM_INC_PARTES 
            WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;

            --FLUJO PARA TRAMITES TERMINADOS
            vlCountTramitesComp := 0;

            SELECT COUNT(*)
            INTO vlCountTramitesComp
            FROM TRAMITES
            WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;

            IF vlCountTramitesComp > 0 THEN

                DELETE RUG_REL_TRAM_PARTES
                WHERE ID_TRAMITE = vlIdTramiteComp;

                DELETE RUG_REL_GARANTIA_PARTES
                WHERE ID_GARANTIA = vlIdGarantiaComp;

                DELETE RUG_REL_TRAM_GARAN
                WHERE ID_GARANTIA = vlIdGarantiaComp;

                DELETE RUG_REL_TRAM_GARAN
                WHERE ID_TRAMITE = vlIdTramiteComp;

                DELETE RUG_GARANTIAS_H
                WHERE ID_GARANTIA = vlIdGarantiaComp;

                DELETE RUG_DOMICILIOS_EXT_H
                WHERE ID_TRAMITE = vlIdTramiteComp;

                DELETE RUG_DOMICILIOS_H
                WHERE ID_TRAMITE = vlIdTramiteComp;

                DELETE RUG_TELEFONOS_H
                WHERE ID_TRAMITE = vlIdTramiteComp;

                DELETE RUG_PERSONAS_H
                WHERE ID_TRAMITE = vlIdTramiteComp;

                DELETE RUG_GARANTIAS
                WHERE ID_GARANTIA = vlIdGarantiaComp;

                DELETE DOCTOS_TRAM_FIRMADOS_RUG
                WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;

                DELETE RUG_FIRMA_MASIVA
                WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;

                DELETE RUG_TBL_BUSQUEDA
                WHERE ID_TRAMITE = vlIdTramiteComp;

                DELETE RUG_CERTIFICACIONES
                WHERE ID_TRAMITE = vlIdTramiteComp;

                DELETE TRAMITES_RUG_INCOMP
                WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;

                DELETE TRAMITES
                WHERE ID_TRAMITE = vlIdTramiteComp;

            END IF;

            DELETE RUG_FIRMA_MASIVA
            WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;

            DELETE TRAMITES_RUG_INCOMP
            WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;

            COMMIT; 

            vlCountGarEliminadas := vlCountGarEliminadas +1; 

        END LOOP;
  CLOSE CursTramitesFirma;

  OPEN CursArchivosCarga;
    LOOP
        FETCH CursArchivosCarga INTO vlIdArchivo;
        EXIT WHEN  CursArchivosCarga%NOTFOUND;
            DELETE RUG_ARCHIVO
            WHERE ID_ARCHIVO = vlIdArchivo;
    END LOOP;
  CLOSE CursArchivosCarga;

  psResult   :=0;        
  psTxResult :='Se eliminaron correctamente: '||vlCountGarEliminadas||' Garant?';

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ELIMINA_GARANTIAS', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ELIMINA_GARANTIAS', 'psTxResult', psTxResult, 'OUT');    


EXCEPTION 
WHEN OTHERS THEN
ROLLBACK;
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250) || '|| Adicionalmente; Se eliminaron correctamente: '||vlCountGarEliminadas||' Garant?';
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ELIMINA_GARANTIAS', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ELIMINA_GARANTIAS', 'psTxResult', psTxResult, 'OUT');    

END SP_ELIMINA_GARANTIAS;
/

