create view V_USUARIO_ACREEDOR as
SELECT   RUA.ID_ACREEDOR,
            RUA.ID_USUARIO,
            RPF.NOMBRE_PERSONA,
            RPF.AP_PATERNO,
            RPF.AP_MATERNO,
            RP.RFC,
            RP.E_MAIL,
            RT.TELEFONO,
            RT.EXTENSION,
            RSU.SIT_USUARIO,
            RUA.B_FIRMADO
     FROM   REL_USU_ACREEDOR RUA,
            RUG_SECU_USUARIOS RSU,
            RUG_PERSONAS RP,
            RUG_PERSONAS_FISICAS RPF,
            RUG_TELEFONOS RT
    WHERE       RUA.ID_USUARIO = RSU.ID_PERSONA
            AND RP.ID_PERSONA = RSU.ID_PERSONA
            AND RPF.ID_PERSONA = RSU.ID_PERSONA
            AND RT.ID_PERSONA(+) = RSU.ID_PERSONA
            AND RP.SIT_PERSONA = 'AC'
            AND RSU.SIT_USUARIO = 'AC'
            AND RUA.STATUS_REG = 'AC'
/

