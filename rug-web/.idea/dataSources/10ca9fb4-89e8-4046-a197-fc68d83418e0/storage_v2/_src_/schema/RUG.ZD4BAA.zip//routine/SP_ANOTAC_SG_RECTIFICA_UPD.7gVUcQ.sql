create PROCEDURE         SP_ANOTAC_SG_RECTIFICA_UPD 
(
        P_ID_ANOTACION_TEMP         IN RUG.RUG_ANOTACIONES_SEG_INC_CSG.ID_ANOTACION_TEMP%TYPE
      , P_ID_TRAMITE_PADRE          IN RUG_ANOTACIONES_SEG_INC_CSG.ID_TRAMITE_PADRE %TYPE
      , P_ID_USUARIO                IN RUG.RUG_PERSONAS_FISICAS.ID_PERSONA%TYPE
      , P_AUTORIDAD_AUTORIZA        IN RUG.RUG_ANOTACIONES_SEG_INC_CSG.AUTORIDAD_AUTORIZA%TYPE
      , P_SOLICITANTE_RECTIFICA     IN RUG.RUG_ANOTACIONES_SEG_INC_CSG.SOLICITANTE_RECTIFICA%TYPE
     -- , P_ID_PERSONA_ANOTACION      IN RUG.RUG_PERSONAS.ID_PERSONA%TYPE
      , P_RESOLUCION                IN RUG.RUG_ANOTACIONES_SEG_INC_CSG.RESOLUCION%TYPE
      , psResult                    OUT   NUMBER
      , psTxResult                  OUT   VARCHAR2
)
AS
    V_ID_TIPO_TRAMITE               RUG.TRAMITES_RUG_INCOMP.ID_TIPO_TRAMITE%TYPE;
    V_ID_STATUS_TRAMITE             RUG.TRAMITES_RUG_INCOMP.ID_STATUS_TRAM%TYPE;
    V_PERS_JURIDICA                 RUG.RUG_PERSONAS.PER_JURIDICA%TYPE;
    V_CONT                          INT;
    EX_SIN_ANOTACION_PADRE          EXCEPTION;
    EX_USUARIO_INVALIDO             EXCEPTION;
    EX_TRAMITE_INVALIDO             EXCEPTION;
    EX_PERSONA_ANOTACION_INVALIDO   EXCEPTION;
    EX_SUB_EXCEPTION                EXCEPTION;

BEGIN

    REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ANOTAC_SG_RECTIFICA_UPD','P_ID_ANOTACION_TEMP'     ,P_ID_ANOTACION_TEMP,    'IN');
    REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ANOTAC_SG_RECTIFICA_UPD','P_ID_TRAMITE_PADRE'      ,P_ID_TRAMITE_PADRE,     'IN');
    REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ANOTAC_SG_RECTIFICA_UPD','P_ID_USUARIO'            ,P_ID_USUARIO,           'IN');
    REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ANOTAC_SG_RECTIFICA_UPD','P_AUTORIDAD_AUTORIZA'    ,P_AUTORIDAD_AUTORIZA,   'IN');
    REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ANOTAC_SG_RECTIFICA_UPD','P_SOLICITANTE_RECTIFICA' ,P_SOLICITANTE_RECTIFICA,'IN');
 --   REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ANOTAC_SG_RECTIFICA_UPD','P_ID_PERSONA_ANOTACION'  ,P_ID_PERSONA_ANOTACION, 'IN'); 
    REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ANOTAC_SG_RECTIFICA_UPD','P_RESOLUCION'            ,P_RESOLUCION,           'IN');


    -- Validar Usuario --
    IF FN_EXISTE_USUARIO(P_ID_USUARIO) = 0 THEN

        RAISE EX_USUARIO_INVALIDO;                    
    END IF;


--    -- Validar Otorgante --    
--    V_CONT := FN_VALIDA_PERSONA(P_ID_PERSONA_ANOTACION); 
--    
--    IF V_CONT = 0 THEN
--                    
--        RAISE EX_PERSONA_ANOTACION_INVALIDO;                    
--    
--    END IF;

--    -- Obtiene la personalidad jur?ca
--    SELECT UPPER(P.PER_JURIDICA)
--      INTO V_PERS_JURIDICA
--      FROM RUG_PERSONAS P
--     WHERE P.ID_PERSONA = P_ID_PERSONA_ANOTACION;    
--    
--    -- Validar si esta en el tramite correcto. --
--    V_ID_TIPO_TRAMITE := 29;
--    
--    IF NOT RUG.FN_VALIDA_TIPO_TRAMITE(P_ID_ANOTACION_TEMP, V_ID_TIPO_TRAMITE) THEN

--        RAISE EX_TRAMITE_INVALIDO;
--    END IF;

    -- Validar si es un registro nuevo para insertar, o ya existente para actualizar --
    SELECT I.ID_STATUS_TRAM
      INTO V_ID_STATUS_TRAMITE
      FROM RUG.TRAMITES_RUG_INCOMP I
     WHERE I.ID_TRAMITE_TEMP = P_ID_ANOTACION_TEMP;


     -- Pendiente de captura, insertar --
     IF V_ID_STATUS_TRAMITE = 0 THEN 

            --Se valida el tramite padre --
            IF RUG.FN_EXISTE_ANOTACION_SG_TERMINA(P_ID_TRAMITE_PADRE)  = 0 THEN

                RAISE EX_SIN_ANOTACION_PADRE;     
            END IF;

            -- ID_USUARIO --
            SP_REL_TRAM_INC_PARTES_INS(P_ID_ANOTACION_TEMP, P_ID_USUARIO, 5, 'PF', psResult, psTxResult);

            IF psResult >0 THEN

                RAISE EX_SUB_EXCEPTION;
            END IF;

--            -- OTORGANTE --
--            SP_REL_TRAM_INC_PARTES_INS(P_ID_ANOTACION_TEMP, P_ID_PERSONA_ANOTACION, 1, V_PERS_JURIDICA, psResult, psTxResult);

            IF psResult >0 THEN

                RAISE EX_SUB_EXCEPTION;
            END IF;

            UPDATE RUG_ANOTACIONES_SEG_INC_CSG 
               SET SOLICITANTE_RECTIFICA    = P_SOLICITANTE_RECTIFICA
                 , AUTORIDAD_AUTORIZA       = P_AUTORIDAD_AUTORIZA
                 , RESOLUCION               = P_RESOLUCION
             WHERE ID_ANOTACION_TEMP = P_ID_ANOTACION_TEMP;

            SP_ANOTAC_SEG_INC_CSG_INS_H(P_ID_ANOTACION_TEMP, psResult, psTxResult);

            IF psResult >0 THEN

                RAISE EX_SUB_EXCEPTION;
            END IF;

            -- CAMBIA EL ESTATUS A PENDIENTE DE FIRMA (5) en est?osici?orque hace un commit interno --
            SP_ALTA_BITACORA_TRAMITE2(P_ID_ANOTACION_TEMP, 5, 0, SYSDATE, 'V', psResult, psTxResult);

            IF psResult >0 THEN

                RAISE EX_SUB_EXCEPTION;
            END IF;


     -- Pendiente de firma, actualizar --
     ELSIF V_ID_STATUS_TRAMITE = 5 THEN 


            -- ID_USUARIO --
            SP_REL_TRAM_INC_PARTES_UPD(P_ID_ANOTACION_TEMP, P_ID_USUARIO, 5, 'PF', psResult, psTxResult);

            IF psResult >0 THEN

                RAISE EX_SUB_EXCEPTION;
            END IF;

--            -- OTORGANTE --
--            SP_REL_TRAM_INC_PARTES_UPD(P_ID_ANOTACION_TEMP, P_ID_PERSONA_ANOTACION, 1, V_PERS_JURIDICA, psResult, psTxResult);

            IF psResult >0 THEN

                RAISE EX_SUB_EXCEPTION;
            END IF;

            UPDATE RUG_ANOTACIONES_SEG_INC_CSG 
               SET SOLICITANTE_RECTIFICA    = P_SOLICITANTE_RECTIFICA
                 , AUTORIDAD_AUTORIZA       = P_AUTORIDAD_AUTORIZA
                 , RESOLUCION               = P_RESOLUCION
             WHERE ID_ANOTACION_TEMP = P_ID_ANOTACION_TEMP;

            SP_ANOTAC_SEG_INC_CSG_INS_H( P_ID_ANOTACION_TEMP, psResult, psTxResult);

            IF psResult >0 THEN

                RAISE EX_SUB_EXCEPTION;
            END IF;


     END IF;

    COMMIT;
    psResult := 0;
    psTxResult := RUG.FN_MENSAJE_ERROR (psResult);


    REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ANOTAC_SG_RECTIFICA_UPD','psResult',  psResult,  'OUT');
    REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ANOTAC_SG_RECTIFICA_UPD','psTxResult',psTxResult,'OUT');

EXCEPTION
    WHEN EX_SIN_ANOTACION_PADRE THEN

        psResult := 125;
        psTxResult := RUG.FN_MENSAJE_ERROR (psResult);
        psTxResult := REPLACE(psTxResult, '@id_tramite', P_ID_TRAMITE_PADRE);

        ROLLBACK;
        REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ANOTAC_SG_RECTIFICA_UPD','psResult',  psResult,  'OUT');
        REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ANOTAC_SG_RECTIFICA_UPD','psTxResult',psTxResult,'OUT');  

    WHEN EX_USUARIO_INVALIDO THEN

        psResult := 2;
        psTxResult := RUG.FN_MENSAJE_ERROR (psResult);

        ROLLBACK;
        REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ANOTAC_SG_RECTIFICA_UPD','psResult',  psResult,  'OUT');
        REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ANOTAC_SG_RECTIFICA_UPD','psTxResult',psTxResult,'OUT');

    WHEN EX_TRAMITE_INVALIDO THEN

        psResult := 127;
        psTxResult := RUG.FN_MENSAJE_ERROR (psResult);
        psTxResult := REPLACE(psTxResult, '@id_tipo_tramite', V_ID_TIPO_TRAMITE);
        psTxResult := REPLACE(psTxResult, '@operacion', 'Actualización rectificación');

        ROLLBACK;
        REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ANOTAC_SG_RECTIFICA_UPD','psResult',  psResult,  'OUT');
        REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ANOTAC_SG_RECTIFICA_UPD','psTxResult',psTxResult,'OUT');

    WHEN EX_PERSONA_ANOTACION_INVALIDO THEN

        psResult := 124;
        psTxResult := RUG.FN_MENSAJE_ERROR (psResult);

        ROLLBACK;
        REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ANOTAC_SG_RECTIFICA_UPD','psResult',  psResult,  'OUT');
        REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ANOTAC_SG_RECTIFICA_UPD','psTxResult',psTxResult,'OUT');

    WHEN EX_SUB_EXCEPTION THEN        

        ROLLBACK;
        REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ANOTAC_SG_RECTIFICA_UPD','psResult',  psResult,  'OUT');
        REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ANOTAC_SG_RECTIFICA_UPD','psTxResult',psTxResult,'OUT');

    WHEN OTHERS THEN

        psResult := 999;
        psTxResult := SUBSTR (SQLCODE || ':' || SQLERRM, 1, 250);

        ROLLBACK;
        REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ANOTAC_SG_RECTIFICA_UPD','psResult',  psResult,  'OUT');
        REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ANOTAC_SG_RECTIFICA_UPD','psTxResult',psTxResult,'OUT');     

END;
/

