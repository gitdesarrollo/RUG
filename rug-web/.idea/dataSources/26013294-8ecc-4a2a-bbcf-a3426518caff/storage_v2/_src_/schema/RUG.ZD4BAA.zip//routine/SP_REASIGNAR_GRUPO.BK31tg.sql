create PROCEDURE         SP_REASIGNAR_GRUPO (
                                                peIdAcreedor         IN    NUMBER,
                                                peIdSubUsuarios      IN    VARCHAR2,                                                
                                                peIdGrupoDestino     IN    NUMBER,
                                                peIdUsuario          IN    NUMBER,
                                                psResult            OUT    INTEGER,   
                                                psTxResult          OUT    VARCHAR2
                                              )
IS

vlCantidadGrupo     NUMBER;
vlCantidadUsuarios  NUMBER;
vlIdSubUsuario      NUMBER;
--vlIdSubUsuarios     PKGSE_COMUN.T_PALABRAS;
Ex_ErrParametro     EXCEPTION;

vlResult            NUMBER; 
vlTxtResult         VARCHAR2(4000);

BEGIN

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REASIGNAR_GRUPO', 'peIdAcreedor', peIdAcreedor, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REASIGNAR_GRUPO', 'peIdSubUsuarios', peIdSubUsuarios, 'IN');    
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REASIGNAR_GRUPO', 'peIdGrupoDestino', peIdGrupoDestino, 'IN');

    --vlIdSubUsuarios := INSTITUCIONAL.PKGSE_COMUN.SPLITCADENA(peIdSubUsuarios, '|');

    --vlCantidadUsuarios := vlIdSubUsuarios.COUNT;

    SELECT COUNT(*)
      INTO vlCantidadGrupo
      FROM RUG_REL_GRUPO_ACREEDOR
     WHERE ID_SUB_USUARIO IN (SELECT COLUMN_VALUE AS PRIVILEGIOS
                                    FROM TABLE (RUG.SPLIT_TEM (peIdSubUsuarios, '|')))
       AND ID_ACREEDOR = peIdAcreedor       
       AND STATUS_REG = 'AC'; 

    /*FOR i IN 1..vlIdSubUsuarios.COUNT LOOP        
       vlIdSubUsuario := vlIdSubUsuarios(i-1);
        BEGIN
                SP_TRAMITES_REASIGNADOS(peIdAcreedor, vlIdSubUsuario, peIdGrupoDestino, NULL, NULL, 2, vlResult, vlTxtResult);
        EXCEPTION
            WHEN OTHERS THEN    
                psResult  := vlResult;   
                psTxResult:= vlTxtResult;
        END;      
    END LOOP;*/

    IF(vlCantidadGrupo = vlCantidadUsuarios) THEN


        INSERT INTO RUG_USUARIOS_GPOS_H(ID_USUARIO, ID_GRUPO_ORIGEN, ID_GRUPO_DESTINO, ID_PERSONA_MODIFICA, STATUS_REG, FECHA_REG)        
        SELECT ID_SUB_USUARIO, ID_GRUPO, peIdGrupoDestino, peIdUsuario, 'AC', SYSDATE 
          FROM RUG_REL_GRUPO_ACREEDOR
         WHERE ID_SUB_USUARIO IN (SELECT COLUMN_VALUE AS PRIVILEGIOS
                                    FROM TABLE (RUG.SPLIT_TEM (peIdSubUsuarios, '|')))
           AND ID_ACREEDOR = peIdAcreedor       
           AND STATUS_REG = 'AC';    

        UPDATE RUG_REL_GRUPO_ACREEDOR
           SET ID_GRUPO = peIdGrupoDestino
         WHERE ID_SUB_USUARIO IN (SELECT COLUMN_VALUE AS PRIVILEGIOS
                                        FROM TABLE (RUG.SPLIT_TEM (peIdSubUsuarios, '|')))
           AND ID_ACREEDOR = peIdAcreedor       
           AND STATUS_REG = 'AC';  

    ELSE

        psResult  := -1;
        psTxResult:= 'Uno de los usuarios enviado no tiene relaci?ctiva con el acreedor';

        RAISE Ex_ErrParametro;


    END IF;

    psResult  := 0;
    psTxResult:= 'Modificacion con ?to';

    COMMIT;

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REASIGNAR_GRUPO', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REASIGNAR_GRUPO', 'psTxResult', psTxResult, 'OUT');

EXCEPTION 
  WHEN Ex_ErrParametro  THEN
        ROLLBACK;

        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REASIGNAR_GRUPO', 'psResult', psResult, 'OUT');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REASIGNAR_GRUPO', 'psTxResult', psTxResult, 'OUT');    

   WHEN OTHERS THEN
        psResult  := 999;   
        psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
        ROLLBACK;
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REASIGNAR_GRUPO', 'psResult', psResult, 'OUT');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REASIGNAR_GRUPO', 'psTxResult', psTxResult, 'OUT');    



END;
/

