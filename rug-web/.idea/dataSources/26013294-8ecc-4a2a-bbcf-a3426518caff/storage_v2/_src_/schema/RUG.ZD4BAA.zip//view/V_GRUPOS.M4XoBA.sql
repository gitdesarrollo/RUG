create view V_GRUPOS as
SELECT   RG.ID_ACREEDOR,
              RG.ID_PERSONA_CREA,
              RG.ID_GRUPO,
              RG.DESC_GRUPO,
              RP.ID_PRIVILEGIO,
              RP.DESC_PRIVILEGIO,
              RP.HTML,
              CASE
                 WHEN RP.ID_PRIVILEGIO IN (11, 12, 13, 15, 18) THEN 0
                 ELSE 1
              END
                 VISIBLES
       FROM   RUG_GRUPOS RG, RUG_PRIVILEGIOS RP, RUG_REL_GRUPO_PRIVILEGIO RRGP
      WHERE       RP.ID_PRIVILEGIO = RRGP.ID_PRIVILEGIO
              AND RRGP.ID_GRUPO = RG.ID_GRUPO
              AND RG.SIT_GRUPO = 'AC'
              AND RP.SIT_PRIVILEGIO = 'AC'
              AND RRGP.SIT_RELACION = 'AC'
   ORDER BY   RG.ID_GRUPO, RP.ID_PRIVILEGIO
/

