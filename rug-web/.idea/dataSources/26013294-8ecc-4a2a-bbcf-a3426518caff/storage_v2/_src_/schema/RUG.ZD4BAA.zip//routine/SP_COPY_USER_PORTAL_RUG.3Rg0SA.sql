create PROCEDURE sp_copy_user_portal_rug (
    psresult     OUT NUMBER,
    pstxresult   OUT VARCHAR2
) IS

  --Variables

    vlnumeroinserts   NUMBER;
    vlcoderesp        NUMBER;
    vldescresp        VARCHAR2(4000);
--/VAR
    ex_errparametro EXCEPTION;

--Cursor
    CURSOR curspartes (
        cdato NUMBER
    ) IS SELECT
        isu.id_persona,
        isu.sit_usuario,
        isu.cve_institucion,
        isu.cve_usuario AS cve_usuario,
        isu.password AS password,
        isu.preg_recupera_psw AS preg_recupera_psw,
        isu.resp_recupera_psw AS resp_recupera_psw,
        isu.cve_usuario_padre,
        ispu.CVE_ACREEDOR,
        ispf.nombre_persona AS nombre,
        ispf.ap_paterno AS apaterno,
        ispf.ap_materno AS amaterno,
        ispf.curp AS curp,
        ispf.sexo AS sexo,
        ispf.id_pais_nacim AS idnacionalidad,
        ivdn.calle AS calle,
        ivdn.codigo_postal,
        ivdn.id_colonia AS idcolonia,
        ivdn.id_localidad AS idlocalidad,
        ivdn.num_exterior AS exterior,
        ivdn.num_interior AS interior,
        ivf.rfc_fedatario AS rfc,
        ivf.telefono AS telefono
         FROM
        infra.secu_usuarios isu
        INNER JOIN RUG_SECU_USUARIOS ispu ON isu.cve_usuario = ispu.cve_usuario
        INNER JOIN institucional.se_personas ise ON isu.id_persona = ise.id_persona
        INNER JOIN institucional.se_personas_fisicas ispf ON isu.id_persona = ispf.id_persona
        INNER JOIN institucional.v_dom_nal_per_fis ivdn ON isu.id_persona = ivdn.id_persona
        INNER JOIN institucional.v_fedatarios ivf ON isu.id_persona = ivf.id_fedatario
        LEFT JOIN rug.rug_secu_usuarios rsu ON isu.cve_usuario = rsu.cve_usuario
         WHERE
        isu.cve_usuario <> rsu.cve_usuario
        OR   rsu.cve_usuario IS NULL;

    curspartes_rec    curspartes%rowtype;
--/Cursor
BEGIN
    vlnumeroinserts := 0;
    FOR curspartes_rec IN curspartes(2) LOOP
        rug.sp_alta_usuario_domicilio('I',curspartes_rec.nombre,curspartes_rec.apaterno,curspartes_rec.amaterno,curspartes_rec.idnacionalidad
,curspartes_rec.sexo,curspartes_rec.rfc,curspartes_rec.curp,curspartes_rec.cve_usuario,curspartes_rec.cve_usuario,curspartes_rec.
password,curspartes_rec.preg_recupera_psw,curspartes_rec.resp_recupera_psw,'SE','AUTORIDAD','RugPortal',11,curspartes_rec.calle,curspartes_rec
.exterior,curspartes_rec.interior,curspartes_rec.idcolonia,curspartes_rec.idlocalidad,curspartes_rec.telefono,NULL,vlcoderesp,vldescresp
);

        vlnumeroinserts := 1 + vlnumeroinserts;
    END LOOP;

    psresult := 0;
    pstxresult := 'Se insertaron '
    || vlnumeroinserts
    || 'Usarios';
    reg_param_pls(seq_rug_param_pls.nextval,'SP_COPY_USER_PORTAL_RUG','psResult',psresult,'OUT');
    reg_param_pls(seq_rug_param_pls.nextval,'SP_COPY_USER_PORTAL_RUG','psTxResult',pstxresult,'OUT');
EXCEPTION
    WHEN ex_errparametro THEN
        ROLLBACK;
        psresult := 999;
        pstxresult := 'Error en el proceso Ex_ErrParametro ';
        reg_param_pls(seq_rug_param_pls.nextval,'SP_COPY_USER_PORTAL_RUG','psResult',psresult,'OUT');
        reg_param_pls(seq_rug_param_pls.nextval,'SP_COPY_USER_PORTAL_RUG','psTxResult',pstxresult,'OUT');
    WHEN OTHERS THEN
        psresult := 999;
        pstxresult := 'Error en el proceso '
        || sqlerrm;
        ROLLBACK;
        reg_param_pls(seq_rug_param_pls.nextval,'SP_COPY_USER_PORTAL_RUG','psResult',psresult,'OUT');
        reg_param_pls(seq_rug_param_pls.nextval,'SP_COPY_USER_PORTAL_RUG','psTxResult',pstxresult,'OUT');
END sp_copy_user_portal_rug;
/

